#pragma once

#include <strmif.h>
#include <uuids.h>

#include <string>

enum ViterbiRate
{
    VRATE_1_2     = 0x10, // 1/2
    VRATE_2_3     = 0x40, // 2/3
    VRATE_3_4     = 0x80, // etc.
    VRATE_5_6     = 0x200,
    VRATE_7_8     = 0x800,
    VRATE_UNKNOWN = 0x2000 // get: uuups, set: auto
};

enum SamplingFreq
{
    SFREQ_45_MHZ  = 45499,	// Symbol rate <= 22000 KBit/s
    SFREQ_61_MHZ  = 60666,	// Symbol rate <= 30000 KBit/s
    SFREQ_81_MHZ  = 80888,	// Symbol rate <= 40000 KBit/s, not usual
    SFREQ_UNKNOWN = 1UL
};

class CPctvSat
{
public:
	CPctvSat(void);
	~CPctvSat(void);

	bool Init(void);
	
	bool SetRelais(bool on);
	bool SetChannel(unsigned long channel, unsigned long afc);
	bool GetChannel(unsigned long* pChannel, unsigned long* pSignalLevel = 0, unsigned long* pSymbolRate = 0, unsigned long* pSampleFrequency = 0, unsigned long* pViterbi = 0);
	bool GetSatNameCount(long* pCount);
	bool GetSatName(unsigned char* pszName, long entryNumber);


private:
	CComPtr<IBaseFilter> m_pTsFilter;
	CComPtr<IBaseFilter> m_pAnalogFilter;
	CComPtr<IKsPropertySet> m_ksProperties;

	bool FindCaptureDevice(const std::string& name, REFCLSID clsid, IBaseFilter **pF);

};
