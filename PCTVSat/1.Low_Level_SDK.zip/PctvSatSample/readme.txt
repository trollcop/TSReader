PCTV Sat Sample 1.0 Readme
==========================

This sample demonstrates how to connect to the PCTV SAT driver and switch the relais on and off.

This sample does not come with an executable binary on purpose to prevent inexperienced users
from damaging their system.

To compile this sample you will need:
1) Visual Studio .Net C++
2) Windows Template Library WTL7, which is available at http://www.microsoft.com/downloads/release.asp?releaseid=37728
3) DirectX8.1 SDK, which is available at http://msdn.microsoft.com/downloads/default.asp?url=/downloads/sample.asp?url=/msdn-files/027/001/771/msdncompositedoc.xml
4) Windows 2000 DDK, which is available at http://www.microsoft.com/ddk/W2kDDK.asp


WARNING
-------

Under no circumstances is this software fully tested. No guarantee can be given that the software 
will work in your system or that it will not destroy some of your installed software or drivers.
It is highly recommended that you backup all important data. This sample is used entirely at your 
own risk. There will be no support for any functionality of your system connected with this sample 
software.

Use this software only if you are a very experienced user of our products.


WARRANTY DISCLAIMER AND COPYRIGHT NOTICE
----------------------------------------

PINNACLE SYSTEMS MAKES NO REPRESENTATION ABOUT THE SUITABILITY OR ACCURACY OF THIS SOFTWARE 
OR DATA FOR ANY PURPOSE, AND MAKES NO WARRANTIES, EITHER EXPRESS OR IMPLIED, INCLUDING
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE OR THAT THE USE OF THIS SOFTWARE
OR DATA WILL NOT INFRINGE ANY THIRD PARTY PATENTS, COPYRIGHTS, TRADEMARKS, OR OTHER RIGHTS. 
THE SOFTWARE AND DATA ARE PROVIDED "AS IS". 

This software and data are provided to enhance knowledge and encourage progress in the
scientific community and are to be used only for research and educational purposes.
Any reproduction or use for commercial purpose is prohibited without the prior express
written permission of Pinnacle Systems. 






