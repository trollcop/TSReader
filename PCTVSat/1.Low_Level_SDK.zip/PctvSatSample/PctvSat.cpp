#include "StdAfx.h"
#include "pctvsat.h"

#include <initguid.h>
#include "pctvsatguid.h"
#include "pctvsatprop.h"

CPctvSat::CPctvSat(void)
{
}

CPctvSat::~CPctvSat(void)
{
}

bool CPctvSat::Init(void)
{
	if (!FindCaptureDevice("Pinnacle PCTV Sat TS", AM_KSCATEGORY_CAPTURE, &m_pTsFilter))
		return false;
	if (!FindCaptureDevice("Pinnacle PCTV Sat Analog", CLSID_VideoInputDeviceCategory, &m_pAnalogFilter))
		return false;
	if (FAILED(m_pAnalogFilter->QueryInterface(&m_ksProperties)))
		return false;
	return true;
}

bool CPctvSat::FindCaptureDevice(const std::string& name, REFCLSID clsid, IBaseFilter **pF)
{
    CComPtr<ICreateDevEnum> pSysDevEnum;
    pSysDevEnum.CoCreateInstance(CLSID_SystemDeviceEnum);
    
	CComPtr<IEnumMoniker> pEnumCat;
	pSysDevEnum->CreateClassEnumerator(clsid , &pEnumCat, 0);
    
	CComPtr<IMoniker> pMoniker;
    ULONG cFetched = 0;
    while(pEnumCat->Next(1, &pMoniker, &cFetched) == S_OK) {
        CComPtr<IPropertyBag> pProp;
        pMoniker->BindToStorage(0, 0, IID_IPropertyBag, (void **)&pProp);
        VARIANT varName;
        VariantInit(&varName); // Try to match the friendly name.
        pProp->Read(L"FriendlyName", &varName, 0); 
		CComPtr<IBaseFilter> pFilter;
		if (SUCCEEDED(pProp->Read(L"FriendlyName", &varName, 0)) 
			&& wcscmp(CComBSTR(name.c_str()), varName.bstrVal) == 0
			&& SUCCEEDED(pMoniker->BindToObject(0, 0, IID_IBaseFilter, (void**)&pFilter))) {
			(*pF = pFilter)->AddRef(); // Add ref on the way out.
			return true;
		}
        VariantClear(&varName);
        pMoniker = 0; // Release for the next loop.
    }
    return false;
}

bool CPctvSat::SetRelais(bool on)
{
	KSPROPERTY_CUSTOMBT848_SAT_S Sat_S;
    memset(&Sat_S, 0, sizeof(Sat_S));
	
	Sat_S.dwOperation = BT848_CUSTPROP_SAT_OPERATION_SET_RELAIS;
	Sat_S.ulData[0] = (unsigned long) on; // 1 - on, 0 - off
    HRESULT hr = m_ksProperties->Set(PROPSETID_VIDCAP_CUSTOMBT848, 
		KSPROPERTY_CUSTOMBT848_SAT, 
		&Sat_S, 
		sizeof(Sat_S), 
		&Sat_S, 
		sizeof(Sat_S));
	return SUCCEEDED(hr);
}

bool CPctvSat::SetChannel(unsigned long channel, unsigned long afc)
{
	// channel coding
	//	BIT26 .. BIT31 Satellite number (in dignames)
	//	BIT25 .. BIT15 Frequency, (10700MHz .. 12750MHz -> values 0 .. 2047)
	//	BIT14 Band. 0 = low band (< 11900MHz), 1 = high band (> 11500Mhz)
	//	BIT13 Polarization, 0 = 13V (vertical), 1 = 17V (horizontal)

	KSPROPERTY_CUSTOMBT848_SAT_S Sat_S;
    memset(&Sat_S, 0, sizeof(Sat_S));
	Sat_S.dwOperation = BT848_CUSTPROP_SAT_OPERATION_SET_CHANNEL;
	Sat_S.ulData[0] = channel; //
    Sat_S.ulData[1] = afc;	// autoscan on ( > 0), f + - 5MHz scan
							// off (= 0)
    HRESULT hr = m_ksProperties->Set(PROPSETID_VIDCAP_CUSTOMBT848, 
		KSPROPERTY_CUSTOMBT848_SAT,
		&Sat_S, 
		sizeof(Sat_S), 
		&Sat_S, 
		sizeof(Sat_S));
	
	return SUCCEEDED(hr);
}

bool CPctvSat::GetChannel(unsigned long* pChannel, unsigned long* pSignalLevel, unsigned long* pSymbolRate, unsigned long* pSampleFrequency, unsigned long* pViterbi)
{
    KSPROPERTY_CUSTOMBT848_SAT_S Sat_S;
    memset(&Sat_S, 0, sizeof(Sat_S));
    Sat_S.dwOperation = BT848_CUSTPROP_SAT_OPERATION_GET_SCAN;
    DWORD cbReturned = 0;
    
	HRESULT hr = m_ksProperties->Get(PROPSETID_VIDCAP_CUSTOMBT848, 
		KSPROPERTY_CUSTOMBT848_SAT,
		&Sat_S, 
		sizeof(Sat_S), 
		&Sat_S, 
		sizeof(Sat_S), 
		&cbReturned);
    
	if (FAILED(hr))
		return false;
	
	if (pChannel) *pChannel = Sat_S.ulVirtualChannel; // see SetChannel
	if (pSymbolRate) *pSymbolRate = Sat_S.ulSymbol;	// 1000 .. 30000 KBit/s
	if (pSampleFrequency) *pSampleFrequency = Sat_S.ulSampling; // see enum SampleFreq
	if (pViterbi) *pViterbi = Sat_S.ulViterbi; // see enum ViterbiRate
	
	// signal strength is only valid if Sat_S.ulData[1] != STATUS_PENDING
	if (pSignalLevel) *pSignalLevel = Sat_S.ulData[1] != 0x103 ? Sat_S.ulData[0] : 0;  
	
	return true;
}

bool CPctvSat::GetSatNameCount(long* pCount)
{
	KSPROPERTY_CUSTOMBT848_SAT_S Sat_S;
    memset(&Sat_S, 0, sizeof(Sat_S));
	Sat_S.dwOperation = BT848_CUSTPROP_SAT_OPERATION_GET_NAMECOUNT;
	DWORD cbReturned = 0;
    
	HRESULT hr = m_ksProperties->Get(PROPSETID_VIDCAP_CUSTOMBT848, 
		KSPROPERTY_CUSTOMBT848_SAT,
		&Sat_S, 
		sizeof(Sat_S), 
		&Sat_S, 
		sizeof(Sat_S), 
		&cbReturned);
	
	if (FAILED(hr))
		return false;
	*pCount = Sat_S.ulData[0]; // number of sat names in dignames.lst
	return true;
}

bool CPctvSat::GetSatName(unsigned char* pszName, long entryNumber)
{
	KSPROPERTY_CUSTOMBT848_SAT_S Sat_S;
    memset(&Sat_S, 0, sizeof(Sat_S));
	Sat_S.dwOperation = BT848_CUSTPROP_SAT_OPERATION_GET_SATNAME;
	Sat_S.ulData[0] = entryNumber; // see SetChannel sattelite number
	Sat_S.ulData[1] = 64; // max. name size
	Sat_S.pszName= (unsigned char *) pszName;
	DWORD cbReturned = 0;
    
	HRESULT hr = m_ksProperties->Get(PROPSETID_VIDCAP_CUSTOMBT848, 
		KSPROPERTY_CUSTOMBT848_SAT,
		&Sat_S, 
		sizeof(Sat_S), 
		&Sat_S, 
		sizeof(Sat_S), 
		&cbReturned);
	
	return SUCCEEDED(hr);
}
