#ifndef MPDEMUX_IF_H
#define MPDEMUX_IF_H

typedef enum 
{
   ST_Reserved,
   ST_Digital_TV_Service,
   ST_Digital_Radio_Service,
   ST_Teletext_Service,
   ST_NVOD_Reference_Service,
   ST_NVOD_TimeShifted_Service,
   ST_Mosaic_Service,
   ST_PAL_Coded_Signal,
   ST_SECAM_Coded_Signal,
   ST_D_D2_MAC,
   ST_FM_Radio,
   ST_NTSC_Coded_Signal,
   ST_Data_Broadcast_Service,
   ST_User_Defined
} SERVICE_TYPE;


typedef enum 
{ 
    ES_RESERVED, 
    ES_ISO_11172_2_VIDEO, 
    ES_ISO_13818_2_VIDEO, 
    ES_ISO_11172_3_AUDIO, 
    ES_ISO_13818_3_AUDIO,
    ES_ISO_13818_1_PRIVATE,
    ES_ISO_13818_1_PES_PRIVATE,
    ES_ISO_13522_MHEG,
    ES_DSM_CC,
    ES_ITU_H222_1,
    ES_ISO_13818_6_TYPE_A,
    ES_ISO_13818_6_TYPE_B,
    ES_ISO_13818_6_TYPE_C,
    ES_ISO_13818_6_TYPE_D,
    ES_ISO_13818_1_AUX,
    ES_ISO_13818_1_RESERVED_FIRST,
    ES_ISO_13818_1_RESERVED_LAST=0x7F,
    ES_USER_PRIVATE_FIRST,
    ES_AC3_AUDIO = 0x81,
    ES_LPCM_AUDIO = 0x83,
    ES_USER_PRIVATE_LAST=0xFF
} E_STREAMTYPE;


#define     MAX_VID_STREAMS     16
#define     MAX_AUD_STREAMS     32
#define     MAX_DATA_STREAMS    32
#define     MAX_SERVICES        256

#define     ANY_SERVICE         -1l
#define     ANY_TV_SERVICE      -2l
#define     ANY_RADIO_SERVICE   -3l
#define     ANY_PID             -1l


typedef struct _tag_ServiceInfo
{
    int             ProgramNumber;
    SERVICE_TYPE    ServiceType;
    TCHAR           ServiceName[256];
    BOOL            Scrambled;
    BOOL            Running;
    int             VideoStreams[MAX_VID_STREAMS+1];
    int             AudioStreams[MAX_AUD_STREAMS+1];
    int             DataStreams[MAX_DATA_STREAMS+1];
    DWORD           NetworkID;
    DWORD           TransportStreamID;
} SERVICEINFO;


typedef enum {
   STREAM_TYPE_AUDIO,
   STREAM_TYPE_VIDEO,
   STREAM_TYPE_PRIVATE,
   STREAM_TYPE_TELETEXT,
   STREAM_TYPE_EPG,
   STREAM_TYPE_SYSTEM,
   STREAM_TYPE_TRANSPORT,
   STREAM_TYPE_PROGRAM,
   STREAM_TYPE_STILLIMAGE,
   STREAM_TYPE_TRANSPORT_DOWNMIX,
   STREAM_TYPE_LAST
} STREAMTYPE;


typedef enum {
   COMPRESSION_MPEG1,
   COMPRESSION_MPEG2,
   COMPRESSION_AC3,
   COMPRESSION_UNKNOWN
} COMPRESSIONTYPE;


//    Transport Stream: Program Information
//       - List all elementary streams of a program 
DECLARE_INTERFACE_(IProgramInfo,IUnknown)
{
   STDMETHOD(GetCount)  (THIS_ ULONG* pulCount) PURE;
   STDMETHOD(GetStreamTypeID)  (THIS_ ULONG ulStreamIndex, DWORD* pdwStreamType, DWORD* pdwStreamPID) PURE;
};


// {0C3B51F9-7D47-4d7f-A4FD-B06766CC703E}
DEFINE_GUID(IID_IProgramInfo2, 0xc3b51f9, 0x7d47, 0x4d7f, 0xa4, 0xfd, 0xb0, 0x67, 0x66, 0xcc, 0x70, 0x3e);

DECLARE_INTERFACE_(IProgramInfo2, IUnknown)
{
   STDMETHOD(GetDetails) (THIS_ SERVICEINFO* pSvcInfo) PURE;
};


//    Transport Stream: Program List
//       - List all programs
DEFINE_GUID(IID_IProgramList, 
0x1781ae6, 0xf8f3, 0x4fc2, 0xb1, 0x80, 0x40, 0xf3, 0xbf, 0xef, 0xfa, 0xfd);

DECLARE_INTERFACE_(IProgramList, IUnknown)
{
   STDMETHOD(GetProgramCount)    (THIS_ ULONG* pulCount) PURE;
   STDMETHOD(GetProgramInfo)     (THIS_ ULONG ulPrgIndex, LPLONG plPrgPID, IProgramInfo** pIProgInfo) PURE;
   STDMETHOD(SetCurrentProgram)  (THIS_ LONG lPrgPID, LONG lVideoPID, LONG lAudioPID) PURE;
   STDMETHOD(GetCurrentProgram)  (THIS_ LPLONG plPrgPID, LPLONG plVideoPID, LPLONG plAudioPID, LPDWORD pdwFlags) PURE;
   STDMETHOD(GetProgramFlags)    (THIS_ ULONG ulPrgPID, DWORD* pdwFlags) PURE;
   // new: PCTV Sat > 2.5
   STDMETHOD(SetCurrentProgramAnyway)  (THIS_ LONG lPrgPID, LONG lVideoPID, LONG lAudioPID) PURE;
};

#define  F_SCRAMBLED    0x00000001ul

// {D9FB2240-687A-11d4-BFB1-00105AA805C4}
DEFINE_GUID(IID_IPCLECommands, 
0xd9fb2240, 0x687a, 0x11d4, 0xbf, 0xb1, 0x0, 0x10, 0x5a, 0xa8, 0x5, 0xc4);

typedef enum 
{
   Cmd_GetVersion,
   Cmd_SetGrabFrame,
   Cmd_GetGrabFrame, 
   Cmd_EnableAdvancedFeatures,
   // Enable additional output pins.
   // Parameter:
   //       lparam1: BOOL bEnable
   //       lparam2: -
   //       pllparam3: -
   Cmd_GetPosition,
   // Set available seek range (needed for timeshift).
   // Parameter:
   //       lparam1: -
   //       lparam2: -
   //       pllparam3:  struct { LONGLONG llTimeStart, llTimeEnd; }
   Cmd_SetAvailable,
   // Set first available input file offset 
   // Parameter:
   //       pllparam3:  LONGLONG offset
   Cmd_SetFileStart,
   Cmd_SetSCRCorrection,
   Cmd_DebugOut,
   Cmd_GetPTSLateness,
   Cmd_SetNotifyThreadId,
   Cmd_TSSelectServiceType,
   Cmd_TSResetProgramInfo,
   Cmd_TSEnableTSOutput,
   Cmd_TSEnableMpegPSOutput,
   Cmd_GetOutputQueueLevels,
   Cmd_EnableGOPTimeFixNTSC,
   Cmd_SetDefaultAudioSampleFrequency,
   Cmd_GetDefaultAudioSampleFrequency,
} ECommand;


DECLARE_INTERFACE_(IPCLECommands, IUnknown)
{
   STDMETHOD(Command)  (ECommand cmd, LPARAM lParam1, LPARAM lParam2, LONGLONG* param3) PURE;     
};

#endif