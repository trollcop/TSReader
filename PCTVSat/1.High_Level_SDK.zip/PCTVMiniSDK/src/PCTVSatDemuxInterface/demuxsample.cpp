// Pseudo Code...

StopPreviewGraph();
// clear program information tables from previous transponder
pICmd->Command (Cmd_TSResetProgramInfo, 0, 0, NULL);
RunPreviewGraph();

// Channel settle time
Sleep(5000);

pIProgramList->GetProgramCount(&ProgramCount);
for (ULONG i = 0 ; i < ProgramCount; i++)
{
    LONG lPrgNum = 0;
    pIProgramList->GetProgramInfo(i,&lPrgNum,(struct IProgramInfo **)&pIProgramInfo);
    if (pIProgramInfo != NULL)
    {
        ULONG n_vid = 0, n_aud = 0, n_data = 0;

        pIProgramInfo->QueryInterface(IID_IProgramInfo2, (LPVOID*) &pIPrgInfo2);
        if (pIPrgInfo2 != NULL)
        {
            SERVICEINFO SvcInfo;
            pIPrgInfo2->GetDetails(&SvcInfo);

            MultiByteToWideChar(CP_ACP, 0, SvcInfo.ServiceName, lstrlen(SvcInfo.ServiceName), 
                wszName, sizeof(wszName)/sizeof(WCHAR));

            for (n_vid = 0; n_vid < MAX_PIDCOUNT && SvcInfo.VideoStreams[n_vid]; n_vid++)
            {
                lVideoPID[n_vid][0] = SvcInfo.VideoStreams[n_vid];
                lVideoPID[n_vid][1] = ES_ISO_13818_2_VIDEO;
            }

            for (n_aud = 0; n_aud < MAX_PIDCOUNT && SvcInfo.AudioStreams[n_aud]; n_aud++)
            {
                lAudioPID[n_aud][0] = SvcInfo.AudioStreams[n_aud];
                lAudioPID[n_aud][1] = ES_ISO_13818_3_AUDIO;
            }

            for (n_data = 0; n_data < MAX_PIDCOUNT && SvcInfo.DataStreams[n_data]; n_data++)
            {
                lDataPID[n_data][0] = SvcInfo.DataStreams[n_data];
                lDataPID[n_data][1] = ES_ISO_13818_1_PES_PRIVATE;
            }
        }
    }
}
