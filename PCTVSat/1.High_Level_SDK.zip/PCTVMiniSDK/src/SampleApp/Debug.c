// ****************************************************************************
// 
//  DEBUG.C
//
//  General Debug module. Be aware that floating point variables are not
//  supported (Thanx Microsoft for wsprintf/wvsprintf limitations !)
//
//  (c) 1997-2001 Bernd Scharping
//
// ****************************************************************************

#include "debug.h"

#if (defined DEBUG) || (defined _DEBUG)

void cdecl dprintf(LPSTR szFormat, ...)
{
    char ach[128];

    static BOOL fDebug = -1;

    lstrcpy(ach, "SDKSampleApp: ");
    wvsprintf(ach+lstrlen(ach),szFormat,(LPVOID)(&szFormat+1));
    lstrcat(ach, "\r\n");

    OutputDebugString(ach);
}

#endif 

