#include "stdafx.h"
#include "resource.h"

#include "streams.h"
#include "..\\..\\include\\ctrlvideo.h"
#include "..\\..\\include\\uuidvideo.h"
#include "..\\..\\include\\ifacvideo.h"
#include "..\\..\\include\\guiddll.h"
#include "PCLEVideo.h"

#include "aboutdlg.h"
#include "maindlg.h"
#include "debug.h"


BOOL CVideoWindow::PreTranslateMessage(MSG* pMsg)
{
	return IsDialogMessage(pMsg);
}

BOOL CVideoWindow::OnIdle()
{
	return FALSE;
}

LRESULT CVideoWindow::OnVideoWindowClose(UINT /*uMsg*/, WPARAM /*wParam*/, LPARAM /*lParam*/, BOOL& /*bHandled*/)
{
    return(0);
}

LRESULT CVideoWindow::OnFilterGraphMessage(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
{
    bHandled=true;
    //!!BS simply forward this message to our maindlg ...
    return(::SendMessage(GetParent(), uMsg, wParam, lParam));    
}
