#include "stdafx.h"
#include "resource.h"

#include "streams.h"
#include <initguid.h>
#include "..\\..\\include\\ctrlvideo.h"
#include "..\\..\\include\\uuidvideo.h"
#include "..\\..\\include\\ifacvideo.h"
#include "..\\..\\include\\guiddll.h"
#include "PCLEVideo.h"

#include "aboutdlg.h"
#include "maindlg.h"
#include "debug.h"

CPCLEVideo::CPCLEVideo()
{    
    m_pAXTunerFilter  = NULL;
    m_pAXVideoProcAmp = NULL;
    m_pAXTVTuner      = NULL;
    m_pAXCrossbar     = NULL;
    m_pAXVideo		  = NULL;
    m_pAXVideoCap	  = NULL;
    m_pAXPcleTV	      = NULL;   

    m_isInitialized   = FALSE;

    m_ChannelEntry = new(TVCHANNELINFO[MAX_CHANNELS]);
}

CPCLEVideo::~CPCLEVideo()
{
    if (m_ChannelEntry!=NULL)
        delete(m_ChannelEntry);
    m_ChannelEntry=NULL;
}

HRESULT CPCLEVideo::InitializeCOMInterface(int HardwareID)
{
    HRESULT hr=NOERROR;
    HMODULE hLib;
    GUID g_guid;
    BOOL (WINAPI *getGuid) (DWORD dwId, DWORD hwType, GUID* pCLSID);

    m_HardwareID=HardwareID;

    hLib=LoadLibrary("PCLEGetGuid.dll");
    if (hLib!=NULL)
		{
		getGuid = (BOOL (WINAPI *)(DWORD, DWORD, GUID*  ))GetProcAddress(hLib, "GetCOMHelperGuid");
	    if (getGuid==NULL)
			{
			FreeLibrary (hLib);
			return(E_FAIL);
			}
		}
    else
		return(E_FAIL);

	getGuid(ID_PCLE_VIDEO,HardwareID, &g_guid);
	hr = CoCreateInstance(g_guid, NULL, CLSCTX_INPROC_SERVER,IID_IBaseFilter, (void **)&m_pAXTunerFilter);

	FreeLibrary (hLib);


	if (!SUCCEEDED(hr))
		return(hr);
	hr=m_pAXTunerFilter->QueryInterface(IID_PCLE_VIDEO, (void **)&m_pAXVideo);
	if (!SUCCEEDED(hr))
		return(hr);
	hr=m_pAXTunerFilter->QueryInterface(IID_PCLE_VIDEOCAP, (void **)&m_pAXVideoCap);
	if (!SUCCEEDED(hr))
		return(hr);
	hr=m_pAXTunerFilter->QueryInterface(IID_IAMVideoProcAmp, (void **)&m_pAXVideoProcAmp);
	if (!SUCCEEDED(hr))
		return(hr);
	hr=m_pAXTunerFilter->QueryInterface(IID_IAMCrossbar, (void **)&m_pAXCrossbar);
	if (!SUCCEEDED(hr))
		return(hr);
	hr=m_pAXTunerFilter->QueryInterface(IID_IAMTVTuner, (void **)&m_pAXTVTuner);
	//if (!SUCCEEDED(hr))
	//	return(hr);
	hr=m_pAXTunerFilter->QueryInterface(IID_PCLE_TVTUNER, (void **)&m_pAXPcleTV);
	if (!SUCCEEDED(hr))
		return(hr);

    hr=m_pAXVideo->set_HardwareType(HardwareID|HWIO_OPENTYPE_AMCAP|HWIO_OPENTYPE_TVTUNER);

	if (!SUCCEEDED(hr))
		return(hr);

	return(NOERROR);
}


HRESULT CPCLEVideo::DeInitializeCOMInterface(void)
{
	RELEASE(m_pAXVideo);
	RELEASE(m_pAXVideoCap);
	RELEASE(m_pAXVideoProcAmp);
	RELEASE(m_pAXCrossbar);
	RELEASE(m_pAXTVTuner);
	RELEASE(m_pAXTunerFilter);
	RELEASE(m_pAXPcleTV);

	return(NOERROR);
}

HRESULT CPCLEVideo::InitHardware(HWND hWndCap)
{
    HRESULT hr=NOERROR;
    RECT rc;

	if (m_pAXVideo==NULL)
		return(E_POINTER);

	hr=m_pAXVideo->Init_Hardware(hWndCap, _Module.GetModuleInstance(), PCLE_DSHOW_MESSAGE, HWIO_DRIVER_MODE_PRIMARY);
	if (!SUCCEEDED(hr))
		return(E_FAIL);

	m_isInitialized=TRUE;

    GetClientRect(hWndCap,&rc);

    SetPreviewWindow(hWndCap, &rc);

	return(hr);
}

HRESULT CPCLEVideo::DeInitHardware(HWND hWndCap)
{
    HRESULT hr=NOERROR;

	if (m_pAXVideo==NULL)
		return(E_POINTER);
	hr=m_pAXVideo->DeInit_Hardware(hWndCap, HWIO_DRIVER_MODE_PRIMARY, HWIO_DEINIT_COMPLETE_SHUTDOWN);
	
    m_isInitialized=FALSE;

	return(hr);
}

HRESULT CPCLEVideo::SetPreviewWindow(HWND hWndPrevWindow, RECT *rc)
{
    HRESULT hr=NOERROR;

	if (m_pAXVideoCap==NULL)
		return(E_POINTER);

	if (!m_isInitialized) 
		return(E_UNEXPECTED);

	hr=m_pAXVideoCap->set_PreviewParams(hWndPrevWindow, rc);
    hr=m_pAXVideoCap->set_PlaybackParams(hWndPrevWindow, rc);

    m_pAXVideoCap->set_ZoomedPreviewParams(hWndPrevWindow, rc, rc);
    m_pAXVideoCap->set_ZoomedPlaybackParams(hWndPrevWindow, rc, rc);


	return(hr);
}

HRESULT CPCLEVideo::SetVideoParams(int nVideoStandard, int nVideoSize, int nBitRate, int nCompressionType, int nTimeshiftSize, int nMediaSize, int nCaptureQuality, int nInterlace, int bTimeshift, int bNoiseFilter)
{
    HRESULT hr=NOERROR;

    //!!BS don�t setup parameters while in running state ! 

    if (!m_pAXVideoCap) 
        return(E_POINTER);

	if (!m_isInitialized) 
		return(E_UNEXPECTED);

    m_pAXVideoCap->SetParameter(PC_VIDEOCAPTURESIZE, HWIO_VIDEO_SIZE_352x288, NULL, FALSE);
    m_pAXVideoCap->SetParameter(PC_VIDEOBITRATE, 1150000, NULL, FALSE);
    m_pAXVideoCap->SetParameter(PC_VIDEOCAPTURECOLORFORMAT, HWIO_VIDEO_CAPTURE_COLORFMT_DONT_CARE, NULL, FALSE);
    m_pAXVideoCap->SetParameter(PC_VIDEOCAPTURECOMPRESSOR, HWIO_VIDEO_CAPTURE_COMPRESSOR_MPG1RT, NULL, FALSE);
    m_pAXVideoCap->SetParameter(PC_VIDEOMPEGMODE, 1, NULL, FALSE);

    m_pAXVideoCap->SetParameter(PC_AUDIOMODE, HWIO_AUDIO_MODE_STEREO, NULL, FALSE);
    m_pAXVideoCap->SetParameter(PC_AUDIOWAVRESOLUTION, 16, NULL, FALSE);
    m_pAXVideoCap->SetParameter(PC_AUDIOSAMPLEFREQUENCY, 44100, NULL, FALSE);

    hr=m_pAXVideoCap->ExecuteParameter(0);

    return(hr);
}

HRESULT CPCLEVideo::SetRouting(long input)
{
	long inPins=0,outPins=0;
	long relatedPinIndex=0;
	long physType=0;
	long in=-1;
	int  i=0;
	HRESULT hr=NOERROR;

	if (m_pAXCrossbar==NULL)
		return(E_POINTER);

	if (!m_isInitialized) 
		return(E_UNEXPECTED);

	hr=m_pAXCrossbar->get_PinCounts(&outPins, &inPins);

	for(i=0;i<inPins;i++)
		{
		hr=m_pAXCrossbar->get_CrossbarPinInfo(TRUE, i, &relatedPinIndex, &physType);
		if (input==physType)
			in=i;
		}

	for(i=0;i<outPins;i++)
		{
		hr=m_pAXCrossbar->get_CrossbarPinInfo(FALSE, i, &relatedPinIndex, &physType);
		switch(physType)
			{
			case PhysConn_Video_VideoDecoder:
				if (in>=0)
					{
					hr=m_pAXCrossbar->Route(i, in);
					return(hr);
					}
				break;
			case PhysConn_Audio_AudioDecoder:
				break;
			}
		}

	return(E_FAIL);
}


HRESULT CPCLEVideo::GetRouting(long *input)
{
	long inPins=0,outPins=0;
	long relatedPinIndex=0;
	long physType=0;
	long in=-1;
	int  i=0;
	HRESULT hr=NOERROR;

	if (m_pAXCrossbar==NULL)
		return(E_POINTER);

	if (!m_isInitialized) 
		return(E_UNEXPECTED);

	hr=m_pAXCrossbar->get_PinCounts(&outPins, &inPins);

	for(i=0;i<outPins;i++)
		{
		hr=m_pAXCrossbar->get_CrossbarPinInfo(FALSE, i, &relatedPinIndex, &physType);
		switch(physType)
			{
			case PhysConn_Video_VideoDecoder:
				hr=m_pAXCrossbar->get_IsRoutedTo(i, &in);
				if (SUCCEEDED(hr))
					{
					hr=m_pAXCrossbar->get_CrossbarPinInfo(TRUE, in, &relatedPinIndex, input);
					return(hr);
					}
				break;
			default:
				break;
			}
		}

	return(E_FAIL);
}

HRESULT CPCLEVideo::GetChannelList(void)
{
    HRESULT hr=NOERROR;

    if (m_pAXPcleTV==NULL)
        return(E_POINTER);

	if (!m_isInitialized) 
		return(E_UNEXPECTED);

    m_CurrentChannel=0;
    m_NumChannels   =0;

    hr=m_pAXPcleTV->get_ChannelList_TV (&m_NumChannels, NULL);
    if (SUCCEEDED(hr))
        {
        if (m_NumChannels > MAX_CHANNELS)
        m_NumChannels = MAX_CHANNELS; 

        if (m_NumChannels)
            {
            int i;
            int iLastChannel;
            m_pAXPcleTV->get_ChannelList_TV (&m_NumChannels, m_ChannelEntry);
            iLastChannel=m_ChannelEntry[0].lLastChannel;
            m_pAXPcleTV->set_CurrentChannel_TV (iLastChannel, NULL);
            for(i=0;i<m_NumChannels;i++)
                {
                if (iLastChannel==m_ChannelEntry[i].lChannel)
                    m_CurrentChannel=i;
                }
            }
        }

    return(NOERROR);
}