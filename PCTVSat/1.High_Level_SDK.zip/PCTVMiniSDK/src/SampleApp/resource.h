//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by SampleApp.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDD_MAINDLG                     129
#define IDD_VIDEOWINDOW                 130
#define IDB_BITMAP_PCLE_LOGO            201
#define IDC_EXIT                        1000
#define IDC_VIDEOFRAME                  1001
#define IDC_COMBO1                      1002
#define IDC_CHANNEL                     1002
#define IDC_PREVIEW                     1005
#define IDC_RECORD                      1006
#define IDC_PLAY                        1007
#define IDC_STOP                        1008
#define IDC_CREDIT                      1014

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        203
#define _APS_NEXT_COMMAND_VALUE         32772
#define _APS_NEXT_CONTROL_VALUE         1007
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
