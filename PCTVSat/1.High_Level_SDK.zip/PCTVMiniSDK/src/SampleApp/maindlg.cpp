// maindlg.cpp : implementation of the CMainDlg class
//
/////////////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "resource.h"

#include "streams.h"
#include "..\\..\\include\\ctrlvideo.h"
#include "..\\..\\include\\uuidvideo.h"
#include "..\\..\\include\\ifacvideo.h"
#include "..\\..\\include\\guiddll.h"
#include "PCLEVideo.h"

#include "aboutdlg.h"
#include "maindlg.h"
#include "debug.h"

BOOL CMainDlg::PreTranslateMessage(MSG* pMsg)
{
	return IsDialogMessage(pMsg);
}

BOOL CMainDlg::OnIdle()
{
	return FALSE;
}

LRESULT CMainDlg::OnInitDialog(UINT /*uMsg*/, WPARAM /*wParam*/, LPARAM /*lParam*/, BOOL& bHandled)
{
    HRESULT hr=NOERROR;
	// center the dialog on the screen
	CenterWindow();

	// set icons
	HICON hIcon = (HICON)::LoadImage(_Module.GetResourceInstance(), MAKEINTRESOURCE(IDR_MAINFRAME), 
		IMAGE_ICON, ::GetSystemMetrics(SM_CXICON), ::GetSystemMetrics(SM_CYICON), LR_DEFAULTCOLOR);
	SetIcon(hIcon, TRUE);
	HICON hIconSmall = (HICON)::LoadImage(_Module.GetResourceInstance(), MAKEINTRESOURCE(IDR_MAINFRAME), 
		IMAGE_ICON, ::GetSystemMetrics(SM_CXSMICON), ::GetSystemMetrics(SM_CYSMICON), LR_DEFAULTCOLOR);
	SetIcon(hIconSmall, FALSE);

	// register object for message filtering and idle updates
	CMessageLoop* pLoop = _Module.GetMessageLoop();
	ATLASSERT(pLoop != NULL);
	pLoop->AddMessageFilter(this);
	pLoop->AddIdleHandler(this);

	UIAddChildWindowContainer(m_hWnd);

    ((CWindow)GetDlgItem(IDC_STOP)).EnableWindow(FALSE);

    if (NULL!=CreateVideoWindow(IDC_VIDEOFRAME))
        {
        //!!BS This is the point where you select the hardware you would like to use !
        //!!BS A complete selection of different supported hardware types can be found
        //!!BS in ctrlvideo.h
        hr=m_PCLEVideo.InitializeCOMInterface(HWIO_HARDWARE_PROTEUS);
        //!!BS This is the point where you select the hardware you would like to use !
        if (SUCCEEDED(hr))
            hr=m_PCLEVideo.InitHardware(m_VideoWindow.m_hWnd);

        //!!BS set countrycode for germany to switch to sprecific frequency table for the tuner
        //!!BS this might fail if we simply have no (analog)tuner ...
        if (SUCCEEDED(hr)&&(m_PCLEVideo.m_pAXTVTuner!=NULL))
    	    m_PCLEVideo.m_pAXTVTuner->put_CountryCode(49);

        //!!BS setup videostandard before we switch on preview ! This is needed because PAL/NTSC might
        //!!BS require different default setup of the capture size within PCLEVideoXX object.
        if (SUCCEEDED(hr)&&(m_PCLEVideo.m_pAXVideoCap!=NULL))
            m_PCLEVideo.m_pAXVideoCap->SetParameter(PC_VIDEOFORMAT, HWIO_VIDEO_FORMAT_PAL, NULL, TRUE );

        //!!BS You can�t expect the driver to remember it�s input :), so select the required crossbar routing
        m_PCLEVideo.SetRouting(PhysConn_Video_Tuner);
        //m_PCLEVideo.SetRouting(PhysConn_Video_Composite);
        //m_PCLEVideo.SetRouting(PhysConn_Video_SVideo);
        
        //!!BS Grab the current channellist. This might also fail in case we have no tuner, or simply no
        //!!BS previous scanning was performed.
        m_PCLEVideo.GetChannelList();
        CreateChannelList();

        m_graphmode=0;

        if (SUCCEEDED(hr))
            {
            OnPreview(0,0,0, bHandled);
            }
        }

	return TRUE;
}

HWND CMainDlg::CreateVideoWindow(UINT frameID)
{
	int retval=0;
    RECT rect;

	((CWindow)GetDlgItem(frameID)).GetWindowRect(&rect);
    rect.top=16;
    rect.left=12;
    rect.right=352+rect.left;
    rect.bottom=288+rect.top;
    m_VideoWindow.Create(m_hWnd,rect,"",WS_CHILD);
    m_VideoWindow.ShowWindow(SW_SHOW);
    return(m_VideoWindow.m_hWnd);
}


LRESULT CMainDlg::OnAppAbout(WORD /*wNotifyCode*/, WORD /*wID*/, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
{
	CAboutDlg dlg;
	dlg.DoModal();
	return 0;
}

LRESULT CMainDlg::OnClose(UINT /*uMsg*/, WPARAM /*wParam*/, LPARAM /*lParam*/, BOOL& /*bHandled*/)
{
    BOOL handled=TRUE;
    OnExit(0,0,0,handled);
    return(0);
}

LRESULT CMainDlg::OnExit(WORD /*wNotifyCode*/, WORD wID, HWND /*hWndCtl*/, BOOL& /*bHandled*/)
{
    m_PCLEVideo.DeInitHardware(m_VideoWindow.m_hWnd);
    m_PCLEVideo.DeInitializeCOMInterface();
	CloseDialog(wID);
	return 0;
}

void CMainDlg::CloseDialog(int nVal)
{
	DestroyWindow();
	::PostQuitMessage(nVal);
}


HRESULT CMainDlg::CreateChannelList()
{
    int i=0;
    int index=0;
    int nc=0;
    int nLastVirtChannel=m_PCLEVideo.m_ChannelEntry[m_PCLEVideo.m_CurrentChannel].lChannel;

    SendMessage( (CWindow)GetDlgItem(IDC_CHANNEL), CB_RESETCONTENT , 0, 0 );

    for(i=0;i<m_PCLEVideo.m_NumChannels;i++)
	    {
	    char buf[264];
	    int buflen=264;
	    WideCharToMultiByte (CP_ACP, 0, 
				       m_PCLEVideo.m_ChannelEntry[i].wszName, 
				       wcslen (m_PCLEVideo.m_ChannelEntry[i].wszName)+1,
				       buf,  
				       buflen,
				       NULL, NULL);
        //!!BS: only for sattelite channels the scrambled flag might be set
        if (m_PCLEVideo.m_ChannelEntry[i].lScrambled)
            {
    	    char sbuf[264];
            lstrcpy(sbuf,"* ");
            lstrcat(sbuf,buf);
            lstrcpy(buf,sbuf);
            }

        index=SendMessage( (CWindow)GetDlgItem(IDC_CHANNEL), CB_ADDSTRING, 0, (LONG)(LPSTR)(buf) );
	    SendMessage( (CWindow)GetDlgItem(IDC_CHANNEL), CB_SETITEMDATA, index, m_PCLEVideo.m_ChannelEntry[i].lChannel );
		if (m_PCLEVideo.m_ChannelEntry[i].lChannel == nLastVirtChannel)
            m_PCLEVideo.m_CurrentChannel=nc;
        nc++;
        }

    SendMessage( (CWindow)GetDlgItem(IDC_CHANNEL), CB_SETCURSEL, m_PCLEVideo.m_CurrentChannel, 0 );

    return(NOERROR);
}


LRESULT CMainDlg::OnPreview(WORD /*wNotifyCode*/, WORD wID, HWND /*hWndCtl*/, BOOL& bHandled)
{
    OnStop(0,0,0,bHandled);
    HRESULT hr=m_PCLEVideo.m_pAXVideoCap->GraphCreate(GM_PREVIEW | GM_GRABFRAME | GM_GRABVBI | GC_RUN, NULL);
    if (SUCCEEDED(hr))
        {
        ((CWindow)GetDlgItem(IDC_PREVIEW)).EnableWindow(FALSE);
        ((CWindow)GetDlgItem(IDC_STOP)).EnableWindow(TRUE);
        ((CWindow)GetDlgItem(IDC_RECORD)).EnableWindow(FALSE);
        ((CWindow)GetDlgItem(IDC_PLAY)).EnableWindow(FALSE);
        }
    dprintf("OnPreview");
    m_graphmode=GM_PREVIEW;
	return 0;
}

LRESULT CMainDlg::OnStop(WORD /*wNotifyCode*/, WORD wID, HWND /*hWndCtl*/, BOOL& bHandled)
{
    HRESULT hr=NOERROR;
    m_PCLEVideo.m_pAXVideoCap->GraphCommand(GM_ALL | GC_STOP, NULL, NULL);
    m_PCLEVideo.m_pAXVideoCap->GraphCommand(GM_ALL | GC_NUKE, NULL, NULL);
    m_PCLEVideo.m_pAXVideoCap->GraphCommand(GM_PLAYBACK | GC_DESTROY, NULL, NULL);
    if (SUCCEEDED(hr))
        {
        ((CWindow)GetDlgItem(IDC_PREVIEW)).EnableWindow(TRUE);
        ((CWindow)GetDlgItem(IDC_STOP)).EnableWindow(FALSE);
        ((CWindow)GetDlgItem(IDC_RECORD)).EnableWindow(TRUE);
        ((CWindow)GetDlgItem(IDC_PLAY)).EnableWindow(TRUE);
        }
    dprintf("OnStop");
	return 0;
}

LRESULT CMainDlg::OnRecord(WORD /*wNotifyCode*/, WORD wID, HWND /*hWndCtl*/, BOOL& bHandled)
{
    OnStop(0,0,0,bHandled);
    m_PCLEVideo.SetVideoParams(-1, -1, -1, -1, -1, -1, -1, -1, -1, -1);

    int nGraphMode = GM_PLAYBACK | GM_RECORD | GM_GRABFRAME | GM_GRABVBI;
    HRESULT hr=m_PCLEVideo.m_pAXVideoCap->GraphCreate(nGraphMode, "C:\\TEST.MPG");
    m_PCLEVideo.m_pAXVideoCap->GraphCommand( nGraphMode | GC_RUN, NULL, NULL);
    if (SUCCEEDED(hr))
        {
        ((CWindow)GetDlgItem(IDC_PREVIEW)).EnableWindow(FALSE);
        ((CWindow)GetDlgItem(IDC_STOP)).EnableWindow(TRUE);
        ((CWindow)GetDlgItem(IDC_RECORD)).EnableWindow(FALSE);
        ((CWindow)GetDlgItem(IDC_PLAY)).EnableWindow(FALSE);
        }
    dprintf("OnRecord");
    m_graphmode=GM_RECORD;
	return 0;
}

LRESULT CMainDlg::OnPlay(WORD /*wNotifyCode*/, WORD wID, HWND /*hWndCtl*/, BOOL& bHandled)
{
    OnStop(0,0,0,bHandled);
    int nGraphMode = GM_PLAYBACK | GM_GRABFRAME;
    HRESULT hr=m_PCLEVideo.m_pAXVideoCap->GraphCreate(nGraphMode, "C:\\TEST.MPG");
    m_PCLEVideo.m_pAXVideoCap->GraphCommand( nGraphMode | GC_RUN, NULL, NULL);
    if (SUCCEEDED(hr))
        {
        ((CWindow)GetDlgItem(IDC_PREVIEW)).EnableWindow(FALSE);
        ((CWindow)GetDlgItem(IDC_STOP)).EnableWindow(TRUE);
        ((CWindow)GetDlgItem(IDC_RECORD)).EnableWindow(FALSE);
        ((CWindow)GetDlgItem(IDC_PLAY)).EnableWindow(FALSE);
        }
    dprintf("OnPlay");
    m_graphmode=GM_PLAYBACK;
	return 0;
}


LRESULT CMainDlg::OnFilterGraphMessage(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
{
    bHandled=TRUE;

    HRESULT hr=NOERROR;
    IGraphBuilder *pGraphBuilder=NULL;
	IMediaEvent   *pMediaEvent=NULL;

    //!!BS: Ohhh, look what we have here ! With this shy little PCLEFindInterface you can grab an interface
    //!!BS: from a priviously built graph. This gives you the chance to reconstruct/manipulate the graph
    //!!BS: in a way you want it. Of course this is just an idea ... In this case we simply grab the
    //!!BS: GraphBuilderInterface to query it for IMediaEvent.
    if(m_PCLEVideo.m_pAXVideoCap!=NULL)
        hr=m_PCLEVideo.m_pAXVideoCap->PCLEFindInterface(m_graphmode, IID_IGraphBuilder, (void **)&pGraphBuilder);

	if (SUCCEEDED(hr) && (pGraphBuilder!=NULL))
		{
		HRESULT hr;
        BOOL graphStoppedMsg=FALSE;
		hr = pGraphBuilder->QueryInterface(IID_IMediaEvent, (void**) &pMediaEvent);
		if (SUCCEEDED(hr)&&(pMediaEvent!=NULL))
			{
			long lEventCode,  lParam1,  lParam2;  
			pMediaEvent->GetEvent(&lEventCode,&lParam1,&lParam2,1000);
			dprintf("Graph signaled event. EventCode:%lx, Param1:%lx, Param2:%lx",lEventCode,lParam1,lParam2);
			pMediaEvent->FreeEventParams(lEventCode,lParam1,lParam2);
			RELEASE(pMediaEvent);
			}
    	RELEASE(pGraphBuilder);
		}
    
    return(0);
}

LRESULT CMainDlg::OnChannel(WORD wNotifyCode, WORD wID, HWND hWndCtl, BOOL& bHandled)
{
    HRESULT hr=NOERROR;
	if (wNotifyCode==CBN_SELCHANGE)
		{
		unsigned long channel=0;
		int sel=0;
		sel=SendMessage( (CWindow)GetDlgItem(IDC_CHANNEL), CB_GETCURSEL, 0, 0 );
		channel=SendMessage( (CWindow)GetDlgItem(IDC_CHANNEL), CB_GETITEMDATA, sel, 0 );
        
        //if (m_PCLEVideo.m_pAXTVTuner!=NULL)
        //    hr=m_PCLEVideo.m_pAXTVTuner->put_Channel(channel,0,0);
        //!!BS: better use our comfort interface here ...
        if (m_PCLEVideo.m_pAXPcleTV!=NULL)
            m_PCLEVideo.m_pAXPcleTV->set_CurrentChannel_TV(channel, NULL);

		m_PCLEVideo.m_CurrentChannel=sel;
    	}
    return(0);
}