#define RELEASE(x) { if (x) x->Release(); x = NULL; }

//!!BS: oops, please don�t change this define, otherwise message forwarding fails ...
#define PCLE_DSHOW_MESSAGE  (WM_USER + 1024)
//!!BS: oops, please don�t change this define, otherwise message forwarding fails ...

#define MAX_CHANNELS    2048

class CPCLEVideo
{
public:
    CPCLEVideo();
   ~CPCLEVideo();

    HRESULT InitializeCOMInterface(int HardwareID);
    HRESULT DeInitializeCOMInterface(void);
    HRESULT InitHardware(HWND hWndCap);
    HRESULT DeInitHardware(HWND hWndCap);

    HRESULT SetPreviewWindow(HWND hWndPrevWindow, RECT *rc);
    HRESULT SetVideoParams(int nVideoStandard, int nVideoSize, int nBitRate, int nCompressionType, int nTimeshiftSize, int nMediaSize, int nCaptureQuality, int nInterlace, int bTimeshift, int bNoiseFilter);

    HRESULT SetRouting(long input);
    HRESULT GetRouting(long *input);
    
    HRESULT GetChannelList(void);

    IBaseFilter         *m_pAXTunerFilter;
    IAMVideoProcAmp     *m_pAXVideoProcAmp;
    IAMTVTuner          *m_pAXTVTuner;
    IAMCrossbar         *m_pAXCrossbar;
    IAM_PCLE_VIDEO      *m_pAXVideo;
    IAM_PCLE_VIDEOCAP   *m_pAXVideoCap;
    IAM_PCLE_TVTUNER    *m_pAXPcleTV;     

    int                 m_HardwareID;
    BOOL                m_isInitialized;

    long                m_NumChannels;
    long                m_CurrentChannel;
    LPTVCHANNELINFO     m_ChannelEntry;

};