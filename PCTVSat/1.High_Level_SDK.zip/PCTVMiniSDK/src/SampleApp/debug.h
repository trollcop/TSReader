/*===========================================================================*
 *                                                                           *
 *  Copyright (C) 1997 Pinnacle System GmbH                                  *
 *                                                                           *
 *  File:      debug.h                                                       *
 *                                                                           *
 *  Content:   Header file for debug functions                               *
 *                                                                           *
 *  Author:    Michael Externbrink                                           *
 *                                                                           *
 ============================================================================*/

#ifdef __cplusplus              //
extern "C" {                    // Assume C declarations for C++
#endif                          //

#include <windows.h>

#if defined(DEBUG) || defined(_DEBUG)
  extern void FAR CDECL dprintf(LPSTR, ...);
  extern void Dump(void *pMem, size_t nSize);

#else
    #define dprintf / ## /
    #define Dump / ## /
#endif


#ifdef __cplusplus          //
        }                   // End of assume C declarations for C++
#endif                      //

