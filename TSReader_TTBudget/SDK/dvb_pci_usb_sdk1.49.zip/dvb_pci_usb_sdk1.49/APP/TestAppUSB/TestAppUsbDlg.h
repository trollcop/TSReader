// TestAppUsbDlg.h : header file
//

#if !defined(AFX_TESTAPPLCDDLG_H__13AF57D3_120E_11D4_B83C_00105A22770E__INCLUDED_)
#define AFX_TESTAPPLCDDLG_H__13AF57D3_120E_11D4_B83C_00105A22770E__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


#include <DVBCommon.h>
#include <DVBBoardControl.h>
#include <DVBFrontend.h>
#include <DVBTSFilter.h>
#include <DVBFilterToFile.h>
#include <DVBTeleText.h>

/////////////////////////////////////////////////////////////////////////////
// CTestAppUsbDlg dialog

class CTestAppUsbDlg;

class CMyFlt : public CDVBTSFilter
{
public:
	CTestAppUsbDlg* m_pTestAppUsbDlg;

private:
	void OnDataArrival(BYTE* Buff, int len);
	CString s;
};

class CMyTeleText : public CDVBTeletext
{
public:
	CMyTeleText();
	virtual ~CMyTeleText();

	void OnTTXPage(BYTE* TTXPage, int len);
};



class CTestAppUsbDlg : public CDialog
{
// Construction
public:
	CTestAppUsbDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CTestAppUsbDlg)
	enum { IDD = IDD_TESTAPPLCD_DIALOG };
	CString	m_strOutput;
	CString	m_strFEStatus;
	CString	m_strPID;
	CString	m_strDevNr;
	BOOL	m_LNBPower;
	BOOL	m_Diseqc;
	CString	m_strFreq;
	CString	m_strSymb;
	int		m_iPol;
	CString	m_strRdLen;
	CString	m_strWrLen;
	CString	m_strI2cWrite;
	CString	m_strIP;
	CString	m_strPort;
	CString	m_strFID;
	CString	m_strAddr;
	CString	m_strWert;
	BOOL	m_Position;
	CString	m_strIsoBandWidth;
	CString	m_strTTPID;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTestAppUsbDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	virtual LRESULT WindowProc(UINT message, WPARAM wParam, LPARAM lParam);
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	afx_msg BOOL OnDeviceChange(UINT nEventType, DWORD dwData);

	// Generated message map functions
	//{{AFX_MSG(CTestAppUsbDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnDestroy();
	afx_msg void OnSetFrontend();
	afx_msg void OnGetFEStatus();
	afx_msg void OnEnableDMA();
	afx_msg void OnDisableDMA();
	afx_msg void OnGetMAC();
	afx_msg void OnSetFilterMPE();
	afx_msg void OnDelFilterMPE();
	afx_msg void OnGetByteCount();
	afx_msg void OnGetMCList();
	afx_msg void OnSetFilterPES();
	afx_msg void OnDelFilterPES();
	afx_msg void OnOpenDevice();
	afx_msg void OnCloseDevice();
	afx_msg void OnDevicesInfo();
	afx_msg void OnInitFrontend();
	afx_msg void OnSetFilterSEC();
	afx_msg void OnDelFilterSEC();
	afx_msg void OnGetIP();
	afx_msg void OnReset();
	afx_msg void OnStartSectoFile();
	afx_msg void OnStopSectoFile();
	afx_msg void OnStartPEStoFile();
	afx_msg void OnStopPEStoFile();
	afx_msg void OnButtonBoot();
	afx_msg void OnButtonSetPidFilter();
	afx_msg void OnButtonDelPidFilter();
	afx_msg void OnButtonSetEs();
	afx_msg void OnButtonDelEs();
	afx_msg void OnButtonSetEsFile();
	afx_msg void OnButtonDelEsFile();
	afx_msg void OnButtonPidCnt();
	afx_msg void OnButtonCloseCurrApp();
	afx_msg void OnButtonWSTestAn();
	afx_msg void OnButtonWSTestAus();
	afx_msg void OnButtonInstanz();
	afx_msg void OnButtonLED();
	afx_msg void OnButtonScrambled();
	afx_msg void OnButtonIFrame();
	afx_msg void OnUsbBandwidth();
	afx_msg void OnButtonDevId();
	afx_msg void OnButtonEon();
	afx_msg void OnButtonTTXon();
	afx_msg void OnButtonTTXoff();
	afx_msg void OnButtonStress();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

private:
	CDVBBoardControl m_BoardControl;
	CDVBFrontend  m_FE;
	
	CDVBTSFilter m_MPEFilter;
	CDVBTSFilter m_SecFilter;
	CDVBTSFilter m_PESFilter;
	CDVBTSFilter m_PIDFilter;
	CDVBTSFilter m_ESFilter;

	CDVBTSFilter m_SecFilter1;
	CDVBTSFilter m_SecFilter2;
	CDVBTSFilter m_SecFilter3;
	CDVBTSFilter m_SecFilter4;
	CDVBTSFilter m_SecFilter5;
	CDVBTSFilter m_SecFilter6;
	CDVBTSFilter m_SecFilter7;
	CDVBTSFilter m_SecFilter8;
	CDVBTSFilter m_SecFilter9;
	CDVBTSFilter m_SecFilter10;
	CDVBTSFilter m_SecFilter11;
	CDVBTSFilter m_SecFilter12;
	CDVBTSFilter m_SecFilter13;
	CDVBTSFilter m_SecFilter14;
	CDVBTSFilter m_SecFilter15;
	CDVBTSFilter m_SecFilter16;
	CDVBTSFilter m_SecFilter17;
	CDVBTSFilter m_SecFilter18;


	CDVBFilterToFile m_SecFilterToFile;
	CDVBFilterToFile m_PESFilterToFile;
	CDVBFilterToFile m_ESFilterToFile;

	WORD IP_CSum(WORD* addr, WORD count);
	void Make_IP_UDP_Header(BYTE* pIP, WORD wTotalLength, BYTE bFilterID, DWORD dwDestIP, WORD wBasePort);
	void GetExePath(CString& ExePath);

	BOOL HandleDeviceChange(DWORD evtype, PDEV_BROADCAST_HANDLE dhp);
	HDEVNOTIFY m_hHandleNotification;
	HANDLE m_hDevice;
	BOOL win98;

	UINT m_Msg;
	CMyFlt m_MyFlt;
	CMyTeleText m_Teletext;
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TESTAPPLCDDLG_H__13AF57D3_120E_11D4_B83C_00105A22770E__INCLUDED_)
