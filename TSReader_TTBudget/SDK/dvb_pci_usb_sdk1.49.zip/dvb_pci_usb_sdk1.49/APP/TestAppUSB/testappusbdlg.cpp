// TestAppUsbDlg.cpp : implementation file
//

#include "stdafx.h"
#include "TestAppUsb.h"
#include "TestAppUsbDlg.h"

#include <direct.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTestAppUsbDlg dialog

CTestAppUsbDlg::CTestAppUsbDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CTestAppUsbDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CTestAppUsbDlg)
	m_strOutput = _T("");
	m_strFEStatus = _T("");
	m_strPID = _T("289");
	m_strDevNr = _T("0");
	m_LNBPower = TRUE;
	m_Diseqc = TRUE;
	m_strFreq = _T("12051000");
	m_strSymb = _T("27500000");
	m_iPol = 1;
	m_strRdLen = _T("64");
	m_strWrLen = _T("64");
	m_strI2cWrite = _T("");
	m_strIP = _T("192.168.1.84");
	m_strPort = _T("5555");
	m_strFID = _T("1");
	m_strAddr = _T("");
	m_strWert = _T("");
	m_Position = FALSE;
	m_strIsoBandWidth = _T("1");
	m_strTTPID = _T("");
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CTestAppUsbDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CTestAppUsbDlg)
	DDX_Text(pDX, IDC_EDIT1, m_strOutput);
	DDX_Text(pDX, IDC_EDIT2, m_strFEStatus);
	DDX_Text(pDX, IDC_EDIT3, m_strPID);
	DDX_Text(pDX, IDC_EDIT4, m_strDevNr);
	DDX_Check(pDX, IDC_CHECK1, m_LNBPower);
	DDX_Check(pDX, IDC_CHECK2, m_Diseqc);
	DDX_Text(pDX, IDC_EDIT5, m_strFreq);
	DDX_Text(pDX, IDC_EDIT6, m_strSymb);
	DDX_Radio(pDX, IDC_RADIO1, m_iPol);
	DDX_Text(pDX, IDC_EDIT_READ_LEN, m_strRdLen);
	DDX_Text(pDX, IDC_EDIT_WRITE_LEN, m_strWrLen);
	DDX_Text(pDX, IDC_EDIT_I2C_WRITE, m_strI2cWrite);
	DDX_Text(pDX, IDC_EDIT_IP, m_strIP);
	DDX_Text(pDX, IDC_EDIT_PORT, m_strPort);
	DDX_Text(pDX, IDC_EDIT_FID, m_strFID);
	DDX_Text(pDX, IDC_EDIT_ADDR, m_strAddr);
	DDX_Text(pDX, IDC_EDIT_WERT, m_strWert);
	DDX_Check(pDX, IDC_CHECK_POS_A_B, m_Position);
	DDX_Text(pDX, IDC_EDIT8, m_strIsoBandWidth);
	DDX_Text(pDX, IDC_EDIT_TTPID, m_strTTPID);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CTestAppUsbDlg, CDialog)
	ON_WM_DEVICECHANGE()
	//{{AFX_MSG_MAP(CTestAppUsbDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_WM_DESTROY()
	ON_BN_CLICKED(IDC_BUTTON7, OnSetFrontend)
	ON_BN_CLICKED(IDC_BUTTON8, OnGetFEStatus)
	ON_BN_CLICKED(IDC_BUTTON1, OnEnableDMA)
	ON_BN_CLICKED(IDC_BUTTON2, OnDisableDMA)
	ON_BN_CLICKED(IDC_BUTTON9, OnGetMAC)
	ON_BN_CLICKED(IDC_BUTTON10, OnSetFilterMPE)
	ON_BN_CLICKED(IDC_BUTTON11, OnDelFilterMPE)
	ON_BN_CLICKED(IDC_BUTTON12, OnGetByteCount)
	ON_BN_CLICKED(IDC_BUTTON13, OnGetMCList)
	ON_BN_CLICKED(IDC_BUTTON15, OnSetFilterPES)
	ON_BN_CLICKED(IDC_BUTTON16, OnDelFilterPES)
	ON_BN_CLICKED(IDC_BUTTON14, OnOpenDevice)
	ON_BN_CLICKED(IDC_BUTTON17, OnCloseDevice)
	ON_BN_CLICKED(IDC_BUTTON19, OnDevicesInfo)
	ON_BN_CLICKED(IDC_BUTTON18, OnInitFrontend)
	ON_BN_CLICKED(IDC_BUTTON4, OnSetFilterSEC)
	ON_BN_CLICKED(IDC_BUTTON20, OnDelFilterSEC)
	ON_BN_CLICKED(IDC_BUTTON21, OnGetIP)
	ON_BN_CLICKED(IDC_BUTTON22, OnReset)
	ON_BN_CLICKED(IDC_BUTTON30, OnStartSectoFile)
	ON_BN_CLICKED(IDC_BUTTON31, OnStopSectoFile)
	ON_BN_CLICKED(IDC_BUTTON24, OnStartPEStoFile)
	ON_BN_CLICKED(IDC_BUTTON25, OnStopPEStoFile)
	ON_BN_CLICKED(IDC_BUTTON_BOOT, OnButtonBoot)
	ON_BN_CLICKED(IDC_BUTTON_SET_PID_FILTER, OnButtonSetPidFilter)
	ON_BN_CLICKED(IDC_BUTTON_DEL_PID_FILTER, OnButtonDelPidFilter)
	ON_BN_CLICKED(IDC_BUTTON_SET_ES, OnButtonSetEs)
	ON_BN_CLICKED(IDC_BUTTON_DEL_ES, OnButtonDelEs)
	ON_BN_CLICKED(IDC_BUTTON_SET_ES_FILE, OnButtonSetEsFile)
	ON_BN_CLICKED(IDC_BUTTON_DEL_ES_FILE, OnButtonDelEsFile)
	ON_BN_CLICKED(IDC_BUTTON_PID_CNT, OnButtonPidCnt)
	ON_BN_CLICKED(IDC_BUTTON_CLOSE_CURR_APP, OnButtonCloseCurrApp)
	ON_BN_CLICKED(IDC_WS_TEST_AN, OnButtonWSTestAn)
	ON_BN_CLICKED(IDC_WS_TEST_AUS, OnButtonWSTestAus)
	ON_BN_CLICKED(IDC_BUTTON_INSTANZ, OnButtonInstanz)
	ON_BN_CLICKED(IDC_BUTTON_LED, OnButtonLED)
	ON_BN_CLICKED(IDC_BUTTON_SCR, OnButtonScrambled)
	ON_BN_CLICKED(IDC_BUTTON_I_FRAME, OnButtonIFrame)
	ON_BN_CLICKED(IDC_USB_BANDWIDTH, OnUsbBandwidth)
	ON_BN_CLICKED(IDC_BUTTON_DEV_ID, OnButtonDevId)
	ON_BN_CLICKED(IDC_BUTTON_EON, OnButtonEon)
	ON_BN_CLICKED(IDC_BUTTON_TTON, OnButtonTTXon)
	ON_BN_CLICKED(IDC_BUTTON_TTOFF, OnButtonTTXoff)
	ON_BN_CLICKED(IDC_BUTTON_STRESS, OnButtonStress)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTestAppUsbDlg message handlers

BOOL CTestAppUsbDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
	
	_mkdir("c:\\filter\\");

	
	m_hDevice = INVALID_HANDLE_VALUE;
	m_hHandleNotification = NULL;
	OSVERSIONINFO vi = {sizeof(OSVERSIONINFO)};
	GetVersionEx(&vi);
	win98 = vi.dwPlatformId == VER_PLATFORM_WIN32_WINDOWS;


	m_Msg = RegisterWindowMessage(CDVBCommon::GetAppCloseMessage());

	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CTestAppUsbDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CTestAppUsbDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CTestAppUsbDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CTestAppUsbDlg::OnDestroy() 
{
	CDialog::OnDestroy();
	
	// TODO: Add your message handler code here

	m_MPEFilter.ResetFilter();
	m_PESFilter.ResetFilter();
	m_SecFilter.ResetFilter();
	
	CDVBBoardControl::BANDWIDTH got;
	
	m_BoardControl.EnableIsoStream(got, CDVBBoardControl::BANDWIDTH_NONE);

//	if (m_hHandleNotification && !win98)
//		UnregisterDeviceNotification(m_hHandleNotification);
//	CDVBCommon::CloseDevice();

	OnCloseDevice();
}


#define DISEQC_HIGH_NIBLE	0xF0
#define DISEQC_LOW_BAND		0x00
#define DISEQC_HIGH_BAND	0x01
#define DISEQC_VERTICAL		0x00
#define DISEQC_HORIZONTAL	0x02
#define DISEQC_POSITION_A	0x00
#define DISEQC_POSITION_B	0x04
#define DISEQC_OPTION_A		0x00
#define DISEQC_OPTION_B		0x08

void CTestAppUsbDlg::OnSetFrontend() 
{
	UpdateData(TRUE);
	
	if(m_FE.GetType() == CDVBFrontend::FE_SATELLITE)
	{
		DWORD dwFrequenz = strtoul(m_strFreq, NULL, 10);
		DWORD dwSymbolrate = strtoul(m_strSymb, NULL, 10);

		if(m_Diseqc)
		{
			BYTE DiPar[4];
			
			DiPar[0] = 0xE0; DiPar[1] = 0x10; DiPar[2] = 0x38;
			DiPar[3] = DISEQC_HIGH_NIBLE;
			if(!m_iPol) // H
				DiPar[3] |= DISEQC_HORIZONTAL;
			else // V
				DiPar[3] |= DISEQC_VERTICAL;
			if(dwFrequenz > 11700000)
				DiPar[3] |= DISEQC_HIGH_BAND;
			else
				DiPar[3] |= DISEQC_LOW_BAND;

			if(m_Position)
			{
				DiPar[3] |= DISEQC_POSITION_B;
				DiPar[3] |= DISEQC_OPTION_A;
			}
			else
			{
				DiPar[3] |= DISEQC_POSITION_A;
				DiPar[3] |= DISEQC_OPTION_A;
			}

			for(int i=0; i<3; i++)
			{
				m_FE.SendDiSEqCMsg(DiPar, 4, 0xff);
				DiPar[0] = 0xE1; // Wiederholung
				Sleep(120); // Wartezeit zwischen Diseqc-Sequenzen
			}
		}
		
		CDVBFrontend::CHANNEL_TYPE ch;

		ch.dvb_s.dwFreq = dwFrequenz;
		ch.dvb_s.dwLOF = (dwFrequenz > 11700000) ? 10600000 : 9750000;
		ch.dvb_s.bF22kHz = (dwFrequenz > 11700000) ? TRUE : FALSE;
		ch.dvb_s.LNB_Power = (! m_LNBPower) ? CDVBFrontend::POWER_OFF : (! m_iPol) ? CDVBFrontend::POL_HORZ : CDVBFrontend::POL_VERT;
		ch.dvb_s.dwSymbRate = dwSymbolrate;
		ch.dvb_s.Inversion = CDVBFrontend::SI_AUTO;
		ch.dvb_s.Viterbi = CDVBFrontend::VR_AUTO;
		
		m_FE.SetChannel(ch);
	}
	else if(m_FE.GetType() == CDVBFrontend::FE_CABLE)
	{
		DWORD dwFrequenz = strtoul(m_strFreq, NULL, 10);
		DWORD dwSymbolrate = strtoul(m_strSymb, NULL, 10);

		CDVBFrontend::CHANNEL_TYPE ch;

		ch.dvb_c.dwFreq = dwFrequenz;
		ch.dvb_c.dwSymbRate = dwSymbolrate;
		ch.dvb_c.Inversion = CDVBFrontend::SI_AUTO;
		ch.dvb_c.Qam = CDVBFrontend::QAM_64;

		m_FE.SetChannel(ch);
	}
	else if(m_FE.GetType() == CDVBFrontend::FE_TERRESTRIAL)
	{
		DWORD dwFrequenz = strtoul(m_strFreq, NULL, 10);
		DWORD dwSymbolrate = strtoul(m_strSymb, NULL, 10);

		CDVBFrontend::CHANNEL_TYPE ch;

		ch.dvb_t.dwFreq = dwFrequenz;
		ch.dvb_t.Inversion = CDVBFrontend::SI_AUTO;

		m_FE.SetChannel(ch);
	}
	else
		MessageBox("falscher Frontendtyp!");
}

void CTestAppUsbDlg::OnGetFEStatus() 
{
	//LOCKSTATE_OLD lock;
	BOOL lock = FALSE;
	CDVBFrontend::SIGNAL_TYPE Signal;
	BYTE quality = 0;

	UpdateData(TRUE);

	if(m_FE.GetState(lock, &Signal) == DVB_ERR_NONE)
	{
		if(lock)
			m_strFEStatus = "Locked!";
		else
			m_strFEStatus = "Not locked!";

		if(Signal.BER < 10e-4)
			quality = 75; // 75%
		else if(Signal.BER < 10e-3)
			quality = 50; // 50%
		else if(Signal.BER < 10e-2)
			quality = 25; // 25%
		else // (Signal.BER >= 10e-2)
			quality = 0; // 0%

		if(lock)
			quality += 25;

		m_strOutput.Format("Signal.BER: %f (%e), Quality: %u%%, Level: %u%%", Signal.BER, Signal.BER, quality, Signal.SNR100);
	}

	UpdateData(FALSE);
}

void CTestAppUsbDlg::OnEnableDMA() 
{
	UpdateData(TRUE);
	CString s;

	CDVBBoardControl::BANDWIDTH got, req;
	//CDVBBoardControl::min;

	req = (CDVBBoardControl::BANDWIDTH)strtoul(m_strIsoBandWidth, NULL, 10);

	DVB_ERROR err = m_BoardControl.EnableIsoStream(got, req);
	if(err != DVB_ERR_NONE)
	{
		s.Format("Could not enable Iso (req:%u, got:%u)!", req, got);
		MessageBox(s);
	}
	else
	{
		m_strOutput.Format("Iso enabled (req:%u, got:%u)!", req, got);
		UpdateData(FALSE);
	}
}

void CTestAppUsbDlg::OnDisableDMA() 
{
	CDVBBoardControl::BANDWIDTH got;
	m_BoardControl.EnableIsoStream(got, CDVBBoardControl::BANDWIDTH_NONE);
}

void CTestAppUsbDlg::OnUsbBandwidth() 
{
	DWORD dwTotalBW, dwConsumedBW;
	CDVBBoardControl::BANDWIDTH UsableBW;
	
	if(m_BoardControl.GetUsbBandWidth(dwTotalBW, dwConsumedBW, UsableBW) != DVB_ERR_NONE)
		MessageBox("Could not get UsbBandWidth!");
	else
	{
		CString s;
		switch(UsableBW)
		{
		case CDVBBoardControl::BANDWIDTH_NONE: s = "NONE (0 MBit/s)"; break;
		case CDVBBoardControl::BANDWIDTH_FULL: s = "FULL (7.30 MBit/s)"; break;
		case CDVBBoardControl::BANDWIDTH_6_91: s = "6.91 MBit/s"; break;
		case CDVBBoardControl::BANDWIDTH_6_59: s = "6.59 MBit/s"; break;
		case CDVBBoardControl::BANDWIDTH_5_82: s = "5.82 MBit/s"; break;
		case CDVBBoardControl::BANDWIDTH_5_06: s = "5.06 MBit/s"; break;
		case CDVBBoardControl::BANDWIDTH_4_35: s = "4.35 MBit/s"; break;
		case CDVBBoardControl::BANDWIDTH_3_59: s = "3.59 MBit/s"; break;
		case CDVBBoardControl::BANDWIDTH_2_82: s = "2.82 MBit/s"; break;
//		case CDVBBoardControl::BANDWIDTH_2_05: s = "2.05 MBit/s"; break;
//		case CDVBBoardControl::BANDWIDTH_1_54: s = "1.54 MBit/s"; break;
//		case CDVBBoardControl::BANDWIDTH_1_02: s = "1.02 MBit/s"; break;
//		case CDVBBoardControl::BANDWIDTH_0_51: s = "0.51 MBit/s"; break;
		}

		m_strOutput.Format("TotalBW:%u, ConsumedBW:%u, UsableBW:%s", dwTotalBW, dwConsumedBW, s);
		UpdateData(FALSE);
	}
	
}

void CTestAppUsbDlg::OnGetMAC() 
{
	DWORD oid, snr;
	
	UpdateData(TRUE);

	if(m_BoardControl.GetMACAddress(oid, snr) != DVB_ERR_NONE)
		MessageBox("Could not get MAC!");
	else
	{
		m_strOutput.Format("MAC: %06x%06x", oid, snr);
		UpdateData(FALSE);
	}
}

void CTestAppUsbDlg::OnButtonScrambled()
{
	UpdateData(TRUE);
	m_strOutput.Format("Scrambled: (MPE)%u, (PES)%u, (SEC)%u", m_MPEFilter.GetScrambleFlags(),m_PESFilter.GetScrambleFlags(),m_SecFilter.GetScrambleFlags());
	UpdateData(FALSE);
}

void CTestAppUsbDlg::OnGetByteCount() 
{
	UpdateData(TRUE);
	m_strOutput.Format("ByteCount: (MPE)%u, (PES)%u, (SEC)%u", m_MPEFilter.GetByteCount(),m_PESFilter.GetByteCount(),m_SecFilter.GetByteCount());
	UpdateData(FALSE);
}

void CTestAppUsbDlg::OnGetMCList() 
{
	CString strA, strB;
	CDVBBoardControl::MULTICAST_LIST mcl;
	char pf[33];
	UINT i;

	if(m_BoardControl.GetMulticastList(mcl) == DVB_ERR_NONE)
	{
		strB.Format("Multicast-List Eintrage: %u\n\r", mcl.MulticastListInUse);
		for(i=0; i<mcl.MulticastListInUse; i++)
		{
			strA.Format("MC-MAC: %02x%02x%02x%02x%02x%02x\n\r", mcl.AddressList[i][0],mcl.AddressList[i][1],mcl.AddressList[i][2],mcl.AddressList[i][3],mcl.AddressList[i][4],mcl.AddressList[i][5]);
			strB += strA;
		}
		strA.Format("Packet-Filter: %u\n\r", mcl.PacketFilter);
		strB += strA;
		for(i=0; i<32; i++)
			pf[31-i] = ((mcl.PacketFilter>>i)&0x01) + 0x30;
		pf[32] = 0;
		strB += pf;
		MessageBox(strB);
	}
	else
	{
		MessageBox("Fehler beim Lesen der Mulicast-Liste!");
	}

}

void CTestAppUsbDlg::OnOpenDevice() 
{
	UpdateData(TRUE);

	WORD wDev = (WORD)strtoul(m_strDevNr, NULL, 10);
	
	if(! CDVBCommon::OpenDevice(wDev, "Testapplikation"))
		MessageBox("Konnte Device nicht �ffnen!");
	else
	{
		SetDlgItemText(IDC_EDIT1, "Open device success!");
		m_hDevice = CDVBCommon::GetActDeviceHandle();
		if(m_hDevice != INVALID_HANDLE_VALUE)
		{
			DEV_BROADCAST_HANDLE filter = {0};
			filter.dbch_size = sizeof(filter);
			filter.dbch_devicetype = DBT_DEVTYP_HANDLE;
			filter.dbch_handle = m_hDevice;
			m_hHandleNotification = RegisterDeviceNotification(m_hWnd, &filter, 0);
		}
	}
}

void CTestAppUsbDlg::OnCloseDevice() 
{
	if(m_hHandleNotification && !win98)
		UnregisterDeviceNotification(m_hHandleNotification);
	m_hHandleNotification = NULL;
	
	CDVBCommon::CloseDevice();
	m_hDevice = INVALID_HANDLE_VALUE;
}

void CTestAppUsbDlg::OnDevicesInfo() 
{
	CString s, t, Name, MAC, IP;
	WORD w = CDVBCommon::GetNumberOfDevices();
	
	s.Format("Number of Devices: %u\n", w);
	for(WORD i=0; i<w; i++)
	{
		CDVBCommon::GetDeviceInfo(i, Name, MAC, IP);
		t.Format("Nr: %u, Name: %s, MAC: %s, IP: %s\n", i, Name, MAC, IP);
		s += t;
	}

	MessageBox(s);
}

void CTestAppUsbDlg::OnInitFrontend() 
{
	// Frontend aus Reset nehmen und Frontend initialisieren
	if(DVB_ERR_NONE != m_FE.Init())
	{
		MessageBox("Konnte Frontend nicht initialisieren!");
	}
	else
	{
		switch(m_FE.GetType())
		{
		case CDVBFrontend::FE_SATELLITE:
			SetDlgItemText(IDC_EDIT1, "Frontend initialize success (SATELLITE)!");
			break;
		case CDVBFrontend::FE_CABLE:
			SetDlgItemText(IDC_EDIT1, "Frontend initialize success (FE_CABLE)!");
			break;
		case CDVBFrontend::FE_TERRESTRIAL:
			SetDlgItemText(IDC_EDIT1, "Frontend initialize success (FE_TERRESTRIAL)!");
			break;
		default:			
			SetDlgItemText(IDC_EDIT1, "Frontend initialize success???");
			break;
		}
	}
}

void CTestAppUsbDlg::OnGetIP() 
{
	DWORD _ip, _sm;
	WORD bp;
	BYTE ip[4], sm[4];

	UpdateData(TRUE);

	if(m_BoardControl.Get_IP_SM_BP(_ip, _sm, bp) != DVB_ERR_NONE)
		MessageBox("Could not get IP!");
	else
	{
		*(DWORD*)ip = _ip;
		*(DWORD*)sm = _sm;
		m_strOutput.Format("IP-Address: %u.%u.%u.%u, SubnetMask: %u.%u.%u.%u, BasePort: %u", ip[0],ip[1],ip[2],ip[3], sm[0],sm[1],sm[2],sm[3], bp);
		UpdateData(FALSE);
	}

}

void CTestAppUsbDlg::OnReset() 
{
	m_BoardControl.ResetInit();
}

void CTestAppUsbDlg::OnSetFilterMPE() 
{
	UpdateData(TRUE);

	BYTE fd[1] = {0x3e};
	BYTE fm[1] = {0xff};

	WORD wPID = (WORD)strtoul(m_strPID, NULL, 10);
	
	if(m_MPEFilter.SetFilter(CDVBTSFilter::MPE_SECTION_FILTER, wPID, fd, fm, 1) != DVB_ERR_NONE)
		MessageBox("Could not set Filter!");
	else
		SetDlgItemText(IDC_EDIT1, "Set Filter MPE success!");
}

void CTestAppUsbDlg::OnDelFilterMPE() 
{
	if(m_MPEFilter.ResetFilter() != DVB_ERR_NONE)
		MessageBox("Could not delete Filter!");
	else
		SetDlgItemText(IDC_EDIT1, "Del Filter MPE success!");
}

void CTestAppUsbDlg::OnSetFilterSEC() 
{
	UpdateData(TRUE);

	WORD wPID = (WORD)strtoul(m_strPID, NULL, 10);
	if(m_SecFilter.SetFilter(CDVBTSFilter::SECTION_FILTER, wPID, NULL, NULL, 0) != DVB_ERR_NONE)
		MessageBox("Could not set Section Filter!");
	else
		SetDlgItemText(IDC_EDIT1, "Set Filter SEC success!");
}

void CTestAppUsbDlg::OnDelFilterSEC() 
{
	if(m_SecFilter.ResetFilter() != DVB_ERR_NONE)
		MessageBox("Could not delete Section Filter!");
	else
		SetDlgItemText(IDC_EDIT1, "Del Filter SEC success!");
}

void CTestAppUsbDlg::OnSetFilterPES() 
{
	UpdateData(TRUE);

	WORD wPID = (WORD)strtoul(m_strPID, NULL, 10);
	if(m_PESFilter.SetFilter(CDVBTSFilter::PES_FILTER, wPID, NULL, NULL, 0) != DVB_ERR_NONE)
		MessageBox("Could not set Filter!");
	else
		SetDlgItemText(IDC_EDIT1, "Set Filter PES success!");
}

void CTestAppUsbDlg::OnDelFilterPES() 
{
	if(m_PESFilter.ResetFilter() != DVB_ERR_NONE)
		MessageBox("Could not delete Filter!");
	else
		SetDlgItemText(IDC_EDIT1, "Del Filter PES success!");
}

void CTestAppUsbDlg::OnButtonSetEs() 
{
	UpdateData(TRUE);

	WORD wPID = (WORD)strtoul(m_strPID, NULL, 10);
	if(m_ESFilter.SetFilter(CDVBTSFilter::ES_FILTER, wPID, NULL, NULL, 0) != DVB_ERR_NONE)
		MessageBox("Could not set Filter!");
	else
		SetDlgItemText(IDC_EDIT1, "Set Filter ES success!");

}

void CTestAppUsbDlg::OnButtonDelEs() 
{
	if(m_ESFilter.ResetFilter() != DVB_ERR_NONE)
		MessageBox("Could not delete Filter!");
	else
		SetDlgItemText(IDC_EDIT1, "Del Filter ES success!");
}


void CTestAppUsbDlg::OnButtonSetPidFilter() 
{
	UpdateData(TRUE);

	WORD wPID = (WORD)strtoul(m_strPID, NULL, 10);
	if(m_PIDFilter.SetFilter(CDVBTSFilter::PID_FILTER, wPID, NULL, NULL, 0) != DVB_ERR_NONE)
		MessageBox("Could not set Filter!");
	else
		SetDlgItemText(IDC_EDIT1, "Set Filter PID success!");
}

void CTestAppUsbDlg::OnButtonDelPidFilter() 
{
	if(m_PIDFilter.ResetFilter() != DVB_ERR_NONE)
		MessageBox("Could not delete Filter!");
	else
		SetDlgItemText(IDC_EDIT1, "Del Filter PID success!");
	
}

void CTestAppUsbDlg::OnStartSectoFile() 
{
	UpdateData(TRUE);

	WORD wPID = (WORD)strtoul(m_strPID, NULL, 10);

	m_SecFilterToFile.SetFileParams("c:\\filter\\dvbusb.sec");
	
	if(m_SecFilterToFile.StartFilter(CDVBTSFilter::SECTION_FILTER, wPID, NULL, NULL, 0) != DVB_ERR_NONE)
		MessageBox("Could not start FilterToFile!");
	else
		SetDlgItemText(IDC_EDIT1, "Set FilterToFile SEC success!");
}

void CTestAppUsbDlg::OnStopSectoFile() 
{
	if(m_SecFilterToFile.StopFilter() == DVB_ERR_NONE)
		SetDlgItemText(IDC_EDIT1, "Del FilterToFile SEC success!");
}

void CTestAppUsbDlg::OnButtonSetEsFile() 
{
	UpdateData(TRUE);

	WORD wPID = (WORD)strtoul(m_strPID, NULL, 10);

	m_ESFilterToFile.SetFileParams("c:\\filter\\dvbusb.es");
	
	if(m_ESFilterToFile.StartFilter(CDVBTSFilter::ES_FILTER, wPID, NULL, NULL, 0) != DVB_ERR_NONE)
		MessageBox("Could not start FilterToFile!");
	else
		SetDlgItemText(IDC_EDIT1, "Set FilterToFile ES success!");
}

void CTestAppUsbDlg::OnButtonDelEsFile() 
{
	if(m_ESFilterToFile.StopFilter() == DVB_ERR_NONE)
		SetDlgItemText(IDC_EDIT1, "Del FilterToFile ES success!");
}

void CTestAppUsbDlg::OnStartPEStoFile() 
{
	UpdateData(TRUE);

	WORD wPID = (WORD)strtoul(m_strPID, NULL, 10);

	m_PESFilterToFile.SetFileParams("c:\\filter\\dvbusb.pes");
	
	if(m_PESFilterToFile.StartFilter(CDVBTSFilter::PES_FILTER, wPID, NULL, NULL, 0) != DVB_ERR_NONE)
		MessageBox("Could not start FilterToFile!");
	else
		SetDlgItemText(IDC_EDIT1, "Set FilterToFile PES success!");
}

void CTestAppUsbDlg::OnStopPEStoFile() 
{
	if(m_PESFilterToFile.StopFilter() == DVB_ERR_NONE)
		SetDlgItemText(IDC_EDIT1, "Del FilterToFile PES success!");
}
/*
void CTestAppUsbDlg::OnButtonI2cRw() 
{
	int slave = 0xA0 >> 1;
	int SeqWr[3] = {0x1f, 0, 0};

	UpdateData(TRUE);

	BYTE wr = (BYTE)strtol(m_strI2cWrite, NULL, 0);
	SeqWr[2] = wr;
	m_BoardControl.CombinedSeq(slave, SeqWr, 3, NULL, 0);
}

void CTestAppUsbDlg::OnButtonI2cRead() 
{
	int slave = 0xA0 >> 1;
	int SeqWr[2] = {0x1f, 0};
	int Rd[40];
	int i;
	CString s, t;

	for(i=0; i<40; i++)
		Rd[i]=0;

	m_BoardControl.CombinedSeq(slave, SeqWr, 2, Rd, 40);

	for(i=0; i<8; i++)
	{
		t.Format("%02X %02X %02X %02X %02X\n", Rd[0+i*5], Rd[1+i*5], Rd[2+i*5], Rd[3+i*5], Rd[4+i*5]);
		s += t;
	}
	MessageBox(s);
}

void CTestAppUsbDlg::OnButtonBulkWrite() 
{
	BYTE	OutBuffer[64] = {	0x00, 0x11, 0x22, 0x33, 0x44, 0x55, 0x66, 0x77,
								0x88, 0x99, 0xAA, 0xBB, 0xCC, 0xDD, 0xEE, 0xFF,
								0x00, 0x11, 0x22, 0x33, 0x44, 0x55, 0x66, 0x77,
								0x88, 0x99, 0xAA, 0xBB, 0xCC, 0xDD, 0xEE, 0xFF,
								0x00, 0x11, 0x22, 0x33, 0x44, 0x55, 0x66, 0x77,
								0x88, 0x99, 0xAA, 0xBB, 0xCC, 0xDD, 0xEE, 0xFF,
								0x00, 0x11, 0x22, 0x33, 0x44, 0x55, 0x66, 0x77,
								0x88, 0x99, 0xAA, 0xBB, 0xCC, 0xDD, 0xEE, 0xFF};
	DWORD	WLen;

	UpdateData();
	WLen = strtol(m_strWrLen, NULL, 0);
	if (WLen > 64)
	{
		MessageBox("Block zu gro�!");
		return;
	}

	WLen = m_BoardControl.BulkWrite(OutBuffer, (BYTE)WLen);
	if (WLen == 0xff)
	{
		MessageBox("Fehler bei USB-Transfer (BulkWrite)!");
	}
}

void CTestAppUsbDlg::OnButtonBulkRead() 
{
	BYTE	InBuffer[64];
	BYTE	RLen;
	CString	TempStr;
	CString	DumpStr;
	int		i;

	UpdateData();
	RLen = (BYTE)strtol(m_strRdLen, NULL, 0);
	if (RLen > 64)
	{
		MessageBox("Block zu gro�!");
		return;
	}

	RLen = m_BoardControl.BulkRead(InBuffer, RLen);
	if (RLen == 0xff)
	{
		MessageBox("Fehler bei USB-Transfer (BulkRead)!");
	}
	else
	{
		for (i=0; i<(int)RLen; i++)
		{
			if (!(i & 0x0F))
				DumpStr += "\n";
			else if (!(i & 0x07))
				DumpStr += " ";
			TempStr.Format("%02X ", InBuffer[i]);
			DumpStr += TempStr;
		}
		//MessageBox(DumpStr);
		TRACE(DumpStr);
		m_strRdLen.Format("%2d", RLen);
		UpdateData(FALSE);
	}
}

void CTestAppUsbDlg::OnButtonLoopData() 
{
	UpdateData(TRUE);

	BYTE FID = (BYTE)strtoul(m_strFID, NULL, 10);
	
// 10*100 Zeichen
CString s  = "Das ist ein Loop-Test!!!!Das ist ein Loop-Test!!!!Das ist ein Loop-Test!!!!Das ist ein Loop-Test!!! \
Das ist ein Loop-Test!!!!Das ist ein Loop-Test!!!!Das ist ein Loop-Test!!!!Das ist ein Loop-Test!!! \
Das ist ein Loop-Test!!!!Das ist ein Loop-Test!!!!Das ist ein Loop-Test!!!!Das ist ein Loop-Test!!! \
Das ist ein Loop-Test!!!!Das ist ein Loop-Test!!!!Das ist ein Loop-Test!!!!Das ist ein Loop-Test!!! \
Das ist ein Loop-Test!!!!Das ist ein Loop-Test!!!!Das ist ein Loop-Test!!!!Das ist ein Loop-Test!!! \
Das ist ein Loop-Test!!!!Das ist ein Loop-Test!!!!Das ist ein Loop-Test!!!!Das ist ein Loop-Test!!! \
Das ist ein Loop-Test!!!!Das ist ein Loop-Test!!!!Das ist ein Loop-Test!!!!Das ist ein Loop-Test!!! \
Das ist ein Loop-Test!!!!Das ist ein Loop-Test!!!!Das ist ein Loop-Test!!!!Das ist ein Loop-Test!!! \
Das ist ein Loop-Test!!!!Das ist ein Loop-Test!!!!Das ist ein Loop-Test!!!!Das ist ein Loop-Test!!! \
Das ist ein Loop-Test!!!!Das ist ein Loop-Test!!!!Das ist ein Loop-Test!!!!Das ist ein Loop-Test!! ";
	
	int err = 0;
	DWORD ms = GetTickCount();

	for(int i=0; i<100; i++)
	{
		if(DVB_ERR_NONE != m_BoardControl.LoopData((BYTE*)(LPCSTR)s, s.GetLength()+1, FID))
			err++;
	}
	TRACE("ben�tigte Zeit(ms): %u\n", GetTickCount()-ms);

	if(err)
	{
		s.Format("Fehler bei LoopData: %u", err);
		MessageBox(s);
	}
}

void CTestAppUsbDlg::OnButtonLoopMpe() 
{
	// DVB-Sec/IP-Paket zusammensetzen...
	BYTE data[1516] = {0x3e, 0x75, 0xe9, 0xec, 0xbc, 0xc1, 0x00, 0x00, 0x00, 0x5c, 0xd0, 0x00};

	// Sec-Len = 1516; IP-Len = 1500;

	UpdateData(TRUE);

	WORD Port = (WORD)strtoul(m_strPort, NULL, 10);
	DWORD IP = inet_addr(m_strIP);
	int err = 0;
	CString s;

	data[40] = 0x55; data[41] = 0x77; data[42] = 0x99;
	data[1509] = 0x99; data[1510] = 0x77; data[1511] = 0x55;
	
	Make_IP_UDP_Header(data+12, 1500, 0, IP, Port);

	DWORD ms = GetTickCount();

	for(int i=0; i<100; i++)
	{
		if(DVB_ERR_NONE != m_BoardControl.LoopMPE(data, 1516))
			err++;
	}
	TRACE("ben�tigte Zeit(ms): %u\n", GetTickCount()-ms);
	
	if(err)
	{
		s.Format("Fehler bei LoopMPE: %u", err);
		MessageBox(s);
	}
}
*/
// Size of the IP header
#define IP_HEADER_SIZE 20

void CTestAppUsbDlg::Make_IP_UDP_Header(BYTE* pIP, WORD wTotalLength, BYTE bFilterID, DWORD dwDestIP, WORD wBasePort)
{
//IP-HEADER (20 Bytes)
	pIP[0] = 0x45; //Version+InternetHeaderLength
	pIP[1] = 0x00; //Service
	pIP[2] = (wTotalLength)>>8; //Total Length (IPHeader+Daten)
	pIP[3] = (wTotalLength) & 0xff; //Total Length (IPHeader+Daten)
	pIP[4] = 0; pIP[5] = 0; //Identification
	pIP[6] = 0; pIP[7] = 0; //Flags+FragmentOffset
	pIP[8] = 0x20; //TTL
	pIP[9] = 0x11; //Protocol (0x11 = UDP)
	pIP[10] = 0x00; pIP[11] = 0x00; //IP-Header-CRC; muss f�r die Berechnung der CRC Null sein!
	//Source IP Address
	*((DWORD*)(pIP+12)) = dwDestIP;
	//Destination IP Address
	*((DWORD*)(pIP+16)) = dwDestIP;
	//IP-Header-CRC berechnen und eintragen
	*((WORD*)(pIP+10)) = IP_CSum((WORD*)pIP, IP_HEADER_SIZE);

//UDP-HEADER (8 Bytes)
	//QuellPort (aus Registry)
	pIP[20] = (BYTE)((wBasePort+bFilterID)>>8);
	pIP[21] = (BYTE)((wBasePort+bFilterID)&0xff);
	//ZielPort  (aus Registry)
	pIP[22] = (BYTE)((wBasePort+bFilterID)>>8);
	pIP[23] = (BYTE)((wBasePort+bFilterID)&0xff);
	//L�nge (UDP-Header + UDP-Daten)
	pIP[24] = (BYTE)((wTotalLength-IP_HEADER_SIZE)>>8);
	pIP[25] = (BYTE)((wTotalLength-IP_HEADER_SIZE) & 0xff);
	//CRC (ist 0, wenn nicht verwendet)
	pIP[26] = 0; pIP[27] = 0;

//UDP-DATEN
	//bereits enthalten
}

// -------------------------------------------------------------------
// Hilfsfunktion zur IP-Pr�fsummenberechnung
WORD CTestAppUsbDlg::IP_CSum(WORD* addr, WORD count)
{
//   The following "C" code algorithm computes the checksum with an inner
//   loop that sums 16-bits at a time in a 32-bit accumulator.
//Compute Internet Checksum for "count" BYTES beginning at location "addr"
	register long sum = 0;
	WORD checksum;

	while(count > 1) //  This is the inner loop
	{	sum += *addr;
		addr++;
		count -= 2;
	}
	if(count > 0) sum += *((BYTE*)addr); // Add left-over byte, if any
	
	// Fold 32-bit sum to 16 bits
	while (sum>>16) sum = (sum & 0xffff) + (sum >> 16);

	checksum = (WORD)(~sum);

	return (checksum);
}

void CTestAppUsbDlg::OnButtonLED()
{
	UpdateData(TRUE);
	BYTE freq = (BYTE)strtoul(m_strPort, NULL, 10);

	DVB_ERROR err = m_BoardControl.SetBusyLEDFreq(freq);
	
	if(err != DVB_ERR_NONE)
		MessageBox("SetBusyLEDFreq failed!");
	else
		SetDlgItemText(IDC_EDIT1, "SetBusyLEDFreq success!");


}

void CTestAppUsbDlg::OnButtonInstanz()
{
	UpdateData(TRUE);

	WORD wDev = (WORD)strtoul(m_strDevNr, NULL, 10);
	LPCTSTR pActAppPath = NULL;
	//LPCTSTR pPrevAppPath = NULL;
	LPCTSTR pActAppName = NULL;
	//LPCTSTR pPrevAppName = NULL;

	CDVBCommon::GetCurrentDevApp (wDev, pActAppPath, pActAppName);
	//CDVBCommon::GetPreviousDevApp(wDev, pPrevAppPath, pPrevAppName);

/*	if(! CDVBCommon::GetDeviceInstanceApps(wDev, pActApp, pPrevApp))
	{
		MessageBox("CDVBCommon::GetDeviceInstanceApps nicht erfolgreich!");
	}
	else
*/	{
		CString s;
		s = pActAppPath;
		s += pActAppName;
//		s += " | ";
//		s += pPrevAppPath;
//		s += pPrevAppName;
		SetDlgItemText(IDC_EDIT1, s);
	}
}
/*
void CTestAppUsbDlg::OnButtonUpdateSTC()
{
	CString path;

	GetExePath(path);
	
	if((path.Right(1) == '\\') || (path.Right(1) == '/'))
		path += "boot\\USB3200 with header.bin";
	else
		path += "\\boot\\USB3200 with header.bin";

	CString s = "Update STC file: ";
	s += path;
	
	SetDlgItemText(IDC_EDIT1, s);
	
	if(DVB_ERR_NONE != m_BoardControl.UpdateSTC(path))
		MessageBox("Update STC failed!");
	else
	{
		SetDlgItemText(IDC_EDIT1, "Update STC success!");
	}
}
*/
void CTestAppUsbDlg::OnButtonBoot() 
{
	CString path;
	CFile	BootFile;
	FILETIME CreationTime, LastAccessTime, LastWriteTime;

	GetExePath(path);
	
	if((path.Right(1) == '\\') || (path.Right(1) == '/'))
		path += "boot\\dsp_usb.bin";
	else
		path += "\\boot\\dsp_usb.bin";


	DWORD Time = GetTickCount();

	
	if(DVB_ERR_NONE != m_BoardControl.BootDSP(path))
	{
		MessageBox("Boot DSP failed!");
	}
	else
	{
		Time = GetTickCount() - Time;
		TRACE("Bootzeit: %d ms\n", Time);

		if(! BootFile.Open(path, CFile::modeRead))
		{
			MessageBox("Open Boot File failed!");
			return;
		}

		GetFileTime((HANDLE)BootFile.m_hFile, &CreationTime, &LastAccessTime, &LastWriteTime);
		CTime cctt(LastWriteTime);

		BootFile.Close();

		SetDlgItemText(IDC_EDIT1, cctt.Format("Boot DSP success! - Compiled: %d. %B %Y - %H:%M:%S"));
	}
}

void CTestAppUsbDlg::GetExePath(CString& ExePath)
{

	char path[_MAX_PATH];
	char drive[_MAX_DRIVE];
	char dir[_MAX_DIR];
	char name[_MAX_FNAME];

	if(GetModuleFileName(NULL, path, _MAX_PATH) > 0)
	{
		_splitpath( path, drive, dir, name, NULL );

		ExePath = drive;
		ExePath += dir;
		//ExeName = name;
	}
	else
	{
		ExePath = "C:\\";
		//ExeName = "";
	}	
}
/*
void CTestAppUsbDlg::OnButtonWriteMac() 
{
	DWORD dwOID = 0x0000d05c;
	DWORD dwL3B = 0x00ffff88;

	if(! m_BoardControl.WriteMac(dwOID, dwL3B))
		MessageBox("Write MAC to EEPROM failed!");
	else
		SetDlgItemText(IDC_EDIT1, "Write MAC success!");

}

void CTestAppUsbDlg::OnButtonGetVer() 
{
//	if(! m_BoardControl.WriteMac(dwOID, dwL3B))
//		MessageBox("Write MAC to EEPROM failed!");
}


void CTestAppUsbDlg::OnButtonIsoBytes() 
{
	DWORD isobytes = m_BoardControl.GetIsoBytes();
	CString s;
	s.Format("IsoBytes: %u", isobytes);
	SetDlgItemText(IDC_EDIT1, s);
}
*/
void CTestAppUsbDlg::OnButtonIFrame()
{
	UpdateData(TRUE);

	WORD wPID = (WORD)strtoul(m_strPID, NULL, 10);
	
	if(m_BoardControl.SetVideoIFrame(wPID) != DVB_ERR_NONE)
		MessageBox("Could not set I-Frame-Filter-Mode!");
	else
		SetDlgItemText(IDC_EDIT1, "Set I-Frame-Filter-Mode success!");

}

void CTestAppUsbDlg::OnButtonPidCnt() 
{
	char DB[4096];
	int i, k;
	DWORD FilterPacketCounter = 0;
	DWORD DisContCounter = 0;
	
	DWORD arr[24];

	for(k=0; k<24; k++)
		arr[k] = 0;

	i=sprintf(DB, "DriverStatus:\r\n");
	if(m_BoardControl.GetDriverStatus(arr, 24))
	{
		i+=sprintf(DB+i, "Iso Irp Errors: %u\r\n", arr[0]);
		i+=sprintf(DB+i, "Iso Usbd Errors: %u\r\n", arr[1]);
		i+=sprintf(DB+i, "Iso Packet Errors: %u\r\n", arr[2]);
		i+=sprintf(DB+i, "Iso Irps/Urbs Success: %u\r\n", arr[3]);
		i+=sprintf(DB+i, "Iso Packets Success: %u\r\n", arr[4]);
		i+=sprintf(DB+i, "Iso Bytes Success: %u\r\n", arr[5]);
		i+=sprintf(DB+i, "Iso Empty Packets: %u\r\n", arr[6]);
		i+=sprintf(DB+i, "Iso Not Empty Packets: %u\r\n", arr[7]);
		
		i+=sprintf(DB+i, "M-BlockFifo Usage %%: %u\r\n", arr[8]);
		
		i+=sprintf(DB+i, "Anzahl der Filter: %u\r\n", arr[9]);
		i+=sprintf(DB+i, "ung�ltige TS-Pakete: %u\r\n", arr[10]);
		i+=sprintf(DB+i, "TS-Kontinuit�tsfehler: %u\r\n", arr[11]);
		i+=sprintf(DB+i, "Anzahl der TS-Pakete: %u\r\n", arr[12]);
		i+=sprintf(DB+i, "fehlende Stuffing-Words: %u\r\n", arr[13]);
		i+=sprintf(DB+i, "Stuffing-Pakete: %u\r\n", arr[14]);
		i+=sprintf(DB+i, "LastDiff: %u\r\n", arr[15]);
		i+=sprintf(DB+i, "MuxCheckSumErr: %u\r\n", arr[16]);
		i+=sprintf(DB+i, "MuxDiscontError: %u\r\n", arr[17]);
		i+=sprintf(DB+i, "RetransFailCnt: %u\r\n", arr[18]);
		i+=sprintf(DB+i, "ReRequestedCnt: %u\r\n", arr[19]);
		i+=sprintf(DB+i, "SecCount: %u\r\n", arr[20]);
		i+=sprintf(DB+i, "BadSecCRC: %u\r\n", arr[21]);
		i+=sprintf(DB+i, "NoSecCSum: %u\r\n", arr[22]);
		i+=sprintf(DB+i, "BadSecCSum: %u\r\n", arr[23]);
	}
	i+=sprintf(DB+i, "Ende\r\n");

	for(k=0; k<7; k++)
		arr[k] = 0;
	
	i+=sprintf(DB+i, "DSPStatus:\r\n");
	if(m_BoardControl.GetDSPStatus(arr, 7))
	{
/*		for(k=0; k<7; k++)
		{
			i+=sprintf(DB+i, "(%u): %u dez, %x hex\r\n", k, arr[k], arr[k]);
		}
*/
		i+=sprintf(DB+i, "DataBandWidth: %u dez, %x hex\r\n", arr[0], arr[0]);
		i+=sprintf(DB+i, "DisContCounter: %u dez, %x hex\r\n", arr[1], arr[1]);
		i+=sprintf(DB+i, "FilterPacketCounter: %u dez, %x hex\r\n", arr[2], arr[2]);
		i+=sprintf(DB+i, "MemLevel: %u dez, %x hex\r\n", arr[3], arr[3]);
		i+=sprintf(DB+i, "ReducePID: %u dez, %x hex\r\n", arr[4], arr[4]);
		i+=sprintf(DB+i, "MemFullFlag: %u dez, %x hex\r\n", arr[5], arr[5]);
		i+=sprintf(DB+i, "unused: %u dez, %x hex\r\n", arr[6], arr[6]);
	}
	i+=sprintf(DB+i, "Ende\r\n");

	MessageBox(DB);
}

LRESULT CTestAppUsbDlg::WindowProc(UINT message, WPARAM wParam, LPARAM lParam)
{
	// TODO: Speziellen Code hier einf�gen und/oder Basisklasse aufrufen
	if((m_Msg != 0) && (m_Msg == message))
	{
		MessageBox("Close angefordert");
	}

	return CDialog::WindowProc(message, wParam, lParam);
}

void CTestAppUsbDlg::OnButtonCloseCurrApp() 
{
	UpdateData(TRUE);

	WORD wDev = (WORD)strtoul(m_strDevNr, NULL, 10);

	if(CDVBCommon::CloseCurrentApp(wDev))
		SetDlgItemText(IDC_EDIT1, "Current App closed");
	else
		SetDlgItemText(IDC_EDIT1, "Current App not closed");
}
/*
void CTestAppUsbDlg::OnButtonStcGetReg() 
{
	UpdateData(TRUE);
	WORD wAddr = (WORD)strtoul(m_strAddr, NULL, 0);

	m_strWert.Format("0x%02x", m_BoardControl.STC_GetReg(wAddr));
	UpdateData(FALSE);
}

void CTestAppUsbDlg::OnButtonStcSetReg() 
{
	UpdateData(TRUE);
	WORD wAddr = (WORD)strtoul(m_strAddr, NULL, 0);
	BYTE bData = (BYTE)strtoul(m_strWert, NULL, 0);

	m_BoardControl.STC_SetReg(wAddr, bData);
	
}

void CTestAppUsbDlg::OnButtonStcGetGpio() 
{
	UpdateData(TRUE);
	BYTE bAddr = (BYTE)strtoul(m_strAddr, NULL, 0);
	
	m_strWert.Format("0x%02x", m_BoardControl.STC_GetGPIO(bAddr));
	UpdateData(FALSE);
}

void CTestAppUsbDlg::OnButtonStcSetGpio() 
{
	UpdateData(TRUE);
	BYTE bAddr = (BYTE)strtoul(m_strAddr, NULL, 0);
	BYTE bData = (BYTE)strtoul(m_strWert, NULL, 0);
	
	m_BoardControl.STC_SetGPIO(bAddr, bData);
}
*/

//DEL BOOL CTestAppUsbDlg::OnDeviceChange(UINT nEventType, DWORD dwData)
//DEL {							// CTestDlg::OnDeviceChange
//DEL 	if (!dwData)
//DEL 		return TRUE;
//DEL 
//DEL 	_DEV_BROADCAST_HEADER* p = (_DEV_BROADCAST_HEADER*) dwData;
//DEL 
//DEL 	/*if (p->dbcd_devicetype == DBT_DEVTYP_DEVICEINTERFACE)
//DEL 		return HandleDeviceChange(nEventType, (PDEV_BROADCAST_DEVICEINTERFACE) p);
//DEL 	else*/ if (p->dbcd_devicetype == DBT_DEVTYP_HANDLE)
//DEL 		return HandleDeviceChange(nEventType, (PDEV_BROADCAST_HANDLE) p);
//DEL 	else
//DEL 		return TRUE;
//DEL }							// CTestDlg::OnDeviceChange

/*
BOOL CTestAppUsbDlg::HandleDeviceChange(DWORD evtype, PDEV_BROADCAST_HANDLE dhp)
{							// CTestDlg::HandleDeviceChange

	if (dhp->dbch_handle != m_hDevice)
		return TRUE;			// notification for some other handle

	switch (evtype)
	{						// process handle notification

	case DBT_DEVICEQUERYREMOVE:
		//if (MessageBox(_T("Okay to remove the device?"), _T("Removal Query"), MB_YESNO) != IDYES)
		//	return BROADCAST_QUERY_DENY;
		MessageBox("DBT_DEVICEQUERYREMOVE");
		break;

	case DBT_DEVICEREMOVECOMPLETE:
	case DBT_DEVICEREMOVEPENDING:
		MessageBox(_T("Closing Handle"));

		if(m_hHandleNotification && !win98)
			UnregisterDeviceNotification(m_hHandleNotification);
		m_hHandleNotification = NULL;

		if(m_hDevice != INVALID_HANDLE_VALUE)
			CDVBCommon::CloseDevice();
		m_hDevice = INVALID_HANDLE_VALUE;
		
		//m_ctlSendevent.EnableWindow(FALSE);

		break;
		
	}						// process handle notification

	return TRUE;
}
*/							// CTestDlg::HandleDeviceChange
/*
BOOL CTestAppUsbDlg::HandleDeviceChange(DWORD evtype, PDEV_BROADCAST_DEVICEINTERFACE dip)
{							// CTestDlg::HandleDeviceChange
	CString devname = dip->dbcc_name;

	switch (evtype)
		{						// process device interface notification

	case DBT_DEVICEARRIVAL:
		OnNewDevice(devname, &dip->dbcc_classguid);
		break;

	case DBT_DEVICEREMOVECOMPLETE:
		{						// DBT_DEVICEREMOVECOMPLETE
		CString msg;
		msg.Format(_T("Device %s removed"), (LPCTSTR) devname);
		m_ctlEvents.AddString(msg);
		break;
		}						// DBT_DEVICEREMOVECOMPLETE

		}						// process device interface notification

	return TRUE;
}							// CTestDlg::HandleDeviceChange
*/

void CTestAppUsbDlg::OnButtonWSTestAn()
{
	m_MyFlt.m_pTestAppUsbDlg = this;

	WORD wPID = (WORD)strtoul(m_strPID, NULL, 10);
	if(m_MyFlt.SetFilter(CDVBTSFilter::SECTION_FILTER, wPID, NULL, NULL, 0) != DVB_ERR_NONE)
	{
		MessageBox("Could not set Section Filter!");
	}
	else
	{
		if(m_MyFlt.SOpen(m_MyFlt.GetFilterID()))
			SetDlgItemText(IDC_EDIT1, "Set Filter SEC success!");
		else
			MessageBox("Could not open Winsock for Section Filter!");
	}
}

void CTestAppUsbDlg::OnButtonWSTestAus()
{
	if(m_MyFlt.ResetFilter() != DVB_ERR_NONE)
	{
		MessageBox("Could not delete Section Filter!");
	}
	else
	{
		m_MyFlt.SClose();
		SetDlgItemText(IDC_EDIT1, "Del Filter SEC success!");
	}
}

void CMyFlt::OnDataArrival(BYTE* Buff, int len)
{
	if(len > 20)
		s.Format("Data: %x %x %x %x %x %x %x %x %x %x %x %x %x %x %x %x %x %x %x %x", Buff[0],Buff[1],Buff[2],Buff[3],Buff[4],Buff[5],Buff[6],Buff[7],Buff[8],Buff[9], Buff[10],Buff[11],Buff[12],Buff[13],Buff[14],Buff[15],Buff[16],Buff[17],Buff[18],Buff[19]);
	
	m_pTestAppUsbDlg->SetDlgItemText(IDC_EDIT1, s);
};


void CTestAppUsbDlg::OnButtonDevId() 
{
	DVB_ERROR err;
	WORD wVendorID, wDeviceID;
	CString s;

	err = m_BoardControl.GetUsbDeviceIDs(wVendorID, wDeviceID);

	if(err != DVB_ERR_NONE)
		MessageBox("Could not get Usb-Device-IDs!");
	else
	{
		s.Format("Vendor-ID: %04x, Device-ID: %04x", wVendorID, wDeviceID);
		MessageBox(s);
	}
}

void CTestAppUsbDlg::OnButtonEon() 
{
	DVB_ERROR err;
	BYTE line[32] = "143UHJH-1WP8VCo-0537FFV-142NG5S";
	CString s;


	err = m_BoardControl.CheckRegistration((const char*)line);

	if(err != DVB_ERR_NONE)
		MessageBox("Could not CheckRegistration failed!");
	else
	{
		s.Format("success!");
		MessageBox(s);
	}
}

//============================================================================

CMyTeleText::CMyTeleText()
{

}

CMyTeleText::~CMyTeleText()
{
	TTXOff();
}
	
void CMyTeleText::OnTTXPage(BYTE* Buff, int len)
{
//	TRACE("OnDataArrival\n");
	for(int i=0; ((i<len) && (i<40)); i++)
	{
		if((Buff[i] >= 32) && (Buff[i] < 128))
			TRACE("%c ", Buff[i]);
		else
			TRACE(". ");
	}
	TRACE("\n");
}


void CTestAppUsbDlg::OnButtonTTXon() 
{
	DVB_ERROR err;
	WORD wMag, wTens, wUnits;

	UpdateData(TRUE);

	WORD wPID = (WORD)strtoul(m_strTTPID, NULL, 10);

	//DVB_ERROR TTXOn(WORD wPID);
	err = m_Teletext.TTXOn(wPID);
	if(err != DVB_ERR_NONE)
		MessageBox("Could not start Teletext!");
	
	wMag = wTens = wUnits = (WORD)-1;

	if(! m_Teletext.TTXModifySearchTable(wMag, wTens, wUnits, CDVBTeletext::CAPTURE_PAGE_PARITY_CORRECTED))
		MessageBox("Could not modify SearchTable!");

}

void CTestAppUsbDlg::OnButtonTTXoff() 
{
	if(m_Teletext.TTXOff() != DVB_ERR_NONE)
		MessageBox("Could not stop Teletext!");
}

void CTestAppUsbDlg::OnButtonStress() 
{
	DVB_ERROR err;
	BOOL lock = FALSE;
	CDVBFrontend::SIGNAL_TYPE Signal;

	UpdateData(TRUE);

	err = m_FE.GetState(lock, &Signal);
	err = m_BoardControl.SetBusyLEDFreq(200);
	
	err = m_SecFilter1.SetFilter(CDVBTSFilter::SECTION_FILTER, 0, NULL, NULL, 0);
	if(err != DVB_ERR_NONE) TRACE("Err: %u\n", err);

	err = m_FE.GetState(lock, &Signal);
	if(err != DVB_ERR_NONE) TRACE("Err: %u\n", err);

	err = m_SecFilter2.SetFilter(CDVBTSFilter::SECTION_FILTER, 1, NULL, NULL, 0);
	if(err != DVB_ERR_NONE) TRACE("Err: %u\n", err);
	err = m_FE.GetState(lock, &Signal);
	if(err != DVB_ERR_NONE) TRACE("Err: %u\n", err);

	err = m_SecFilter3.SetFilter(CDVBTSFilter::SECTION_FILTER, 17, NULL, NULL, 0);
	if(err != DVB_ERR_NONE) TRACE("Err: %u\n", err);


	err = m_FE.GetState(lock, &Signal);
	if(err != DVB_ERR_NONE) TRACE("Err: %u\n", err);

	err = m_SecFilter1.ResetFilter();
	if(err != DVB_ERR_NONE) TRACE("Err: %u\n", err);
	err = m_SecFilter2.ResetFilter();
	if(err != DVB_ERR_NONE) TRACE("Err: %u\n", err);
	
	err = m_FE.GetState(lock, &Signal);
	if(err != DVB_ERR_NONE) TRACE("Err: %u\n", err);

	err = m_SecFilter3.ResetFilter();
	if(err != DVB_ERR_NONE) TRACE("Err: %u\n", err);


	err = m_SecFilter1.SetFilter(CDVBTSFilter::SECTION_FILTER, 0, NULL, NULL, 0);
	if(err != DVB_ERR_NONE) TRACE("Err: %u\n", err);
	
	err = m_FE.GetState(lock, &Signal);
	if(err != DVB_ERR_NONE) TRACE("Err: %u\n", err);


	err = m_SecFilter2.SetFilter(CDVBTSFilter::SECTION_FILTER, 1, NULL, NULL, 0);
	if(err != DVB_ERR_NONE) TRACE("Err: %u\n", err);
	err = m_SecFilter3.SetFilter(CDVBTSFilter::SECTION_FILTER, 17, NULL, NULL, 0);
	if(err != DVB_ERR_NONE) TRACE("Err: %u\n", err);
	
	err = m_SecFilter3.ResetFilter();
	if(err != DVB_ERR_NONE) TRACE("Err: %u\n", err);
	err = m_SecFilter2.ResetFilter();
	if(err != DVB_ERR_NONE) TRACE("Err: %u\n", err);
	
	err = m_FE.GetState(lock, &Signal);
	if(err != DVB_ERR_NONE) TRACE("Err: %u\n", err);

	err = m_SecFilter1.ResetFilter();
	if(err != DVB_ERR_NONE) TRACE("Err: %u\n", err);


	err = m_SecFilter1.SetFilter(CDVBTSFilter::SECTION_FILTER, 0, NULL, NULL, 0);
	if(err != DVB_ERR_NONE) TRACE("Err: %u\n", err);
	err = m_SecFilter2.SetFilter(CDVBTSFilter::SECTION_FILTER, 1, NULL, NULL, 0);
	if(err != DVB_ERR_NONE) TRACE("Err: %u\n", err);

	err = m_FE.GetState(lock, &Signal);
	if(err != DVB_ERR_NONE) TRACE("Err: %u\n", err);
	
	err = m_SecFilter3.SetFilter(CDVBTSFilter::SECTION_FILTER, 17, NULL, NULL, 0);
	if(err != DVB_ERR_NONE) TRACE("Err: %u\n", err);
	
	err = m_SecFilter3.ResetFilter();
	if(err != DVB_ERR_NONE) TRACE("Err: %u\n", err);



	err = m_FE.GetState(lock, &Signal);
	if(err != DVB_ERR_NONE) TRACE("Err: %u\n", err);
	
	err = m_SecFilter3.SetFilter(CDVBTSFilter::SECTION_FILTER, 17, NULL, NULL, 0);
	if(err != DVB_ERR_NONE) TRACE("Err: %u\n", err);

	err = m_SecFilter1.ResetFilter();
	if(err != DVB_ERR_NONE) TRACE("Err: %u\n", err);
	err = m_SecFilter1.SetFilter(CDVBTSFilter::SECTION_FILTER, 0, NULL, NULL, 0);
	if(err != DVB_ERR_NONE) TRACE("Err: %u\n", err);

	err = m_SecFilter2.ResetFilter();
	if(err != DVB_ERR_NONE) TRACE("Err: %u\n", err);
	err = m_SecFilter2.SetFilter(CDVBTSFilter::SECTION_FILTER, 1, NULL, NULL, 0);
	if(err != DVB_ERR_NONE) TRACE("Err: %u\n", err);

	err = m_SecFilter3.ResetFilter();
	if(err != DVB_ERR_NONE) TRACE("Err: %u\n", err);

	err = m_FE.GetState(lock, &Signal);
	if(err != DVB_ERR_NONE) TRACE("Err: %u\n", err);
	
	err = m_SecFilter2.ResetFilter();
	if(err != DVB_ERR_NONE) TRACE("Err: %u\n", err);
	err = m_SecFilter1.ResetFilter();
	if(err != DVB_ERR_NONE) TRACE("Err: %u\n", err);

	err = m_FE.GetState(lock, &Signal);
	if(err != DVB_ERR_NONE) TRACE("Err: %u\n", err);

	err = m_SecFilter1.SetFilter(CDVBTSFilter::SECTION_FILTER, 0, NULL, NULL, 0);
	if(err != DVB_ERR_NONE) TRACE("Err: %u\n", err);
	err = m_SecFilter2.SetFilter(CDVBTSFilter::SECTION_FILTER, 1, NULL, NULL, 0);
	if(err != DVB_ERR_NONE) TRACE("Err: %u\n", err);
	err = m_SecFilter3.SetFilter(CDVBTSFilter::SECTION_FILTER, 2, NULL, NULL, 0);
	if(err != DVB_ERR_NONE) TRACE("Err: %u\n", err);
	err = m_SecFilter4.SetFilter(CDVBTSFilter::SECTION_FILTER, 3, NULL, NULL, 0);
	if(err != DVB_ERR_NONE) TRACE("Err: %u\n", err);
	err = m_SecFilter5.SetFilter(CDVBTSFilter::SECTION_FILTER, 4, NULL, NULL, 0);
	if(err != DVB_ERR_NONE) TRACE("Err: %u\n", err);
	err = m_SecFilter6.SetFilter(CDVBTSFilter::SECTION_FILTER, 5, NULL, NULL, 0);
	if(err != DVB_ERR_NONE) TRACE("Err: %u\n", err);
	err = m_SecFilter7.SetFilter(CDVBTSFilter::SECTION_FILTER, 6, NULL, NULL, 0);
	if(err != DVB_ERR_NONE) TRACE("Err: %u\n", err);

	
	err = m_SecFilter8.SetFilter(CDVBTSFilter::SECTION_FILTER, 7, NULL, NULL, 0);
	if(err != DVB_ERR_NONE) TRACE("Err: %u\n", err);
	err = m_SecFilter9.SetFilter(CDVBTSFilter::SECTION_FILTER, 8, NULL, NULL, 0);
	if(err != DVB_ERR_NONE) TRACE("Err: %u\n", err);
	err = m_SecFilter10.SetFilter(CDVBTSFilter::SECTION_FILTER, 9, NULL, NULL, 0);
	if(err != DVB_ERR_NONE) TRACE("Err: %u\n", err);
	err = m_SecFilter11.SetFilter(CDVBTSFilter::SECTION_FILTER, 10, NULL, NULL, 0);
	if(err != DVB_ERR_NONE) TRACE("Err: %u\n", err);
	err = m_SecFilter12.SetFilter(CDVBTSFilter::SECTION_FILTER, 11, NULL, NULL, 0);
	if(err != DVB_ERR_NONE) TRACE("Err: %u\n", err);
	err = m_SecFilter13.SetFilter(CDVBTSFilter::SECTION_FILTER, 12, NULL, NULL, 0);
	if(err != DVB_ERR_NONE) TRACE("Err: %u\n", err);
	err = m_SecFilter14.SetFilter(CDVBTSFilter::SECTION_FILTER, 13, NULL, NULL, 0);
	if(err != DVB_ERR_NONE) TRACE("Err: %u\n", err);
	err = m_SecFilter15.SetFilter(CDVBTSFilter::SECTION_FILTER, 14, NULL, NULL, 0);
	if(err != DVB_ERR_NONE) TRACE("Err: %u\n", err);


	
	err = m_SecFilter16.SetFilter(CDVBTSFilter::SECTION_FILTER, 15, NULL, NULL, 0);
	if(err != DVB_ERR_NONE) TRACE("Err: %u\n", err);
	err = m_SecFilter17.SetFilter(CDVBTSFilter::SECTION_FILTER, 16, NULL, NULL, 0);
	if(err != DVB_ERR_NONE) TRACE("Err: %u\n", err);
	err = m_SecFilter18.SetFilter(CDVBTSFilter::SECTION_FILTER, 17, NULL, NULL, 0);
	if(err != DVB_ERR_NONE) TRACE("Err: %u\n", err);


	
	err = m_SecFilter1.ResetFilter();
	if(err != DVB_ERR_NONE) TRACE("Err: %u\n", err);
	err = m_SecFilter2.ResetFilter();
	if(err != DVB_ERR_NONE) TRACE("Err: %u\n", err);
	err = m_SecFilter3.ResetFilter();
	if(err != DVB_ERR_NONE) TRACE("Err: %u\n", err);
	err = m_SecFilter4.ResetFilter();
	if(err != DVB_ERR_NONE) TRACE("Err: %u\n", err);
	err = m_SecFilter5.ResetFilter();
	if(err != DVB_ERR_NONE) TRACE("Err: %u\n", err);
	err = m_SecFilter6.ResetFilter();
	if(err != DVB_ERR_NONE) TRACE("Err: %u\n", err);
	err = m_SecFilter7.ResetFilter();
	if(err != DVB_ERR_NONE) TRACE("Err: %u\n", err);
	err = m_SecFilter8.ResetFilter();
	if(err != DVB_ERR_NONE) TRACE("Err: %u\n", err);
	err = m_SecFilter9.ResetFilter();
	if(err != DVB_ERR_NONE) TRACE("Err: %u\n", err);
	err = m_SecFilter10.ResetFilter();
	if(err != DVB_ERR_NONE) TRACE("Err: %u\n", err);
	err = m_SecFilter11.ResetFilter();
	if(err != DVB_ERR_NONE) TRACE("Err: %u\n", err);
	err = m_SecFilter12.ResetFilter();
	if(err != DVB_ERR_NONE) TRACE("Err: %u\n", err);
	err = m_SecFilter13.ResetFilter();
	if(err != DVB_ERR_NONE) TRACE("Err: %u\n", err);
	err = m_SecFilter14.ResetFilter();
	if(err != DVB_ERR_NONE) TRACE("Err: %u\n", err);
	err = m_SecFilter15.ResetFilter();
	if(err != DVB_ERR_NONE) TRACE("Err: %u\n", err);
	err = m_SecFilter16.ResetFilter();
	if(err != DVB_ERR_NONE) TRACE("Err: %u\n", err);
	err = m_SecFilter17.ResetFilter();
	if(err != DVB_ERR_NONE) TRACE("Err: %u\n", err);
	err = m_SecFilter18.ResetFilter();
	if(err != DVB_ERR_NONE) TRACE("Err: %u\n", err);



}

BOOL CTestAppUsbDlg::OnDeviceChange(UINT nEventType, DWORD dwData)
{							// CTestDlg::OnDeviceChange
	if (!dwData)
		return TRUE;

	_DEV_BROADCAST_HEADER* p = (_DEV_BROADCAST_HEADER*) dwData;

	//if (p->dbcd_devicetype == DBT_DEVTYP_DEVICEINTERFACE)
	//	return HandleDeviceChange(nEventType, (PDEV_BROADCAST_DEVICEINTERFACE) p);
	//else
	if (p->dbcd_devicetype == DBT_DEVTYP_HANDLE)
		return HandleDeviceChange(nEventType, (PDEV_BROADCAST_HANDLE) p);
	else
		return TRUE;
}							// CTestDlg::OnDeviceChange

BOOL CTestAppUsbDlg::HandleDeviceChange(DWORD evtype, PDEV_BROADCAST_HANDLE dhp)
{							// CTestDlg::HandleDeviceChange
	CString MBText, MBTitle;

//	if (dhp->dbch_handle != m_hDevice)
//		return TRUE;			// notification for some other handle

	switch (evtype)
	{						// process handle notification

	case DBT_DEVICEQUERYREMOVE:
		//if (MessageBox(_T("Okay to remove the device?"), _T("Removal Query"), MB_YESNO) != IDYES)
		//	return BROADCAST_QUERY_DENY;

// //	MessageBox("DBT_DEVICEQUERYREMOVE");
		break;

//	case DBT_DEVICEREMOVEPENDING:
	case DBT_DEVICEREMOVECOMPLETE:
	
		if(m_hDevice != INVALID_HANDLE_VALUE)
			CDVBCommon::CloseDevice();
		m_hDevice = INVALID_HANDLE_VALUE;
	
		MessageBox(_T("Handle/Device closed"));
		
		break;
		
	}						// process handle notification

	return TRUE;
}							// CTestDlg::HandleDeviceChange

