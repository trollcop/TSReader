// TestAppLcd.cpp : Defines the class behaviors for the application.
//

#include "stdafx.h"
#include "TestAppUsb.h"
#include "TestAppUsbDlg.h"
#include <DVBDLLInit.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTestAppLcdApp

BEGIN_MESSAGE_MAP(CTestAppLcdApp, CWinApp)
	//{{AFX_MSG_MAP(CTestAppLcdApp)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG
	ON_COMMAND(ID_HELP, CWinApp::OnHelp)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTestAppLcdApp construction

CTestAppLcdApp::CTestAppLcdApp()
{
	// TODO: add construction code here,
	// Place all significant initialization in InitInstance
}

/////////////////////////////////////////////////////////////////////////////
// The one and only CTestAppLcdApp object

CTestAppLcdApp theApp;

/////////////////////////////////////////////////////////////////////////////
// CTestAppLcdApp initialization

BOOL CTestAppLcdApp::InitInstance()
{
	InitDvbApiDll(); // call this function before any other function in the API-DLL

	// socket initialization
/*	WORD wVersionRequested;
	WSADATA wsaData;
	int err; 
	wVersionRequested = MAKEWORD(2, 0); 
	err = WSAStartup( wVersionRequested, &wsaData );
	if(err != 0)
	{
		AfxMessageBox("Winsock 2.0 not supported!");
		return FALSE;
	}
*/
/*	if (!AfxSocketInit())
	{
		AfxMessageBox("Fehler beim Initialisieren der Windows-Sockets.");
		return FALSE;
	}
*/	
	AfxEnableControlContainer();

	// Standard initialization
	// If you are not using these features and wish to reduce the size
	//  of your final executable, you should remove from the following
	//  the specific initialization routines you do not need.

#ifdef _AFXDLL
	Enable3dControls();			// Call this when using MFC in a shared DLL
#else
	Enable3dControlsStatic();	// Call this when linking to MFC statically
#endif

	CTestAppUsbDlg dlg;
	m_pMainWnd = &dlg;
	int nResponse = dlg.DoModal();
	if (nResponse == IDOK)
	{
		// TODO: Place code here to handle when the dialog is
		//  dismissed with OK
	}
	else if (nResponse == IDCANCEL)
	{
		// TODO: Place code here to handle when the dialog is
		//  dismissed with Cancel
	}

	// socket de-initialization
	//WSACleanup();

	// Since the dialog has been closed, return FALSE so that we exit the
	//  application, rather than start the application's message pump.
	return FALSE;
}
