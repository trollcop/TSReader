//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by TestAppUsb.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_TESTAPPLCD_DIALOG           102
#define IDR_MAINFRAME                   128
#define IDC_BUTTON3                     1002
#define IDC_BUTTON_BULK_WRITE           1002
#define IDC_BUTTON5                     1004
#define IDC_BUTTON_BULK_READ            1004
#define IDC_EDIT1                       1005
#define IDC_BUTTON6                     1006
#define IDC_BUTTON_BOOT                 1006
#define IDC_BUTTON7                     1007
#define IDC_BUTTON8                     1008
#define IDC_EDIT2                       1009
#define IDC_BUTTON1                     1010
#define IDC_BUTTON2                     1011
#define IDC_BUTTON9                     1012
#define IDC_BUTTON10                    1013
#define IDC_BUTTON11                    1014
#define IDC_EDIT3                       1015
#define IDC_BUTTON12                    1016
#define IDC_BUTTON13                    1017
#define IDC_BUTTON15                    1019
#define IDC_BUTTON16                    1020
#define IDC_BUTTON14                    1021
#define IDC_BUTTON17                    1022
#define IDC_EDIT4                       1023
#define IDC_BUTTON18                    1024
#define IDC_BUTTON19                    1025
#define IDC_BUTTON4                     1026
#define IDC_BUTTON20                    1027
#define IDC_BUTTON21                    1028
#define IDC_EDIT5                       1029
#define IDC_CHECK1                      1030
#define IDC_CHECK2                      1031
#define IDC_EDIT6                       1032
#define IDC_RADIO1                      1033
#define IDC_RADIO2                      1034
#define IDC_BUTTON22                    1035
#define IDC_BUTTON23                    1037
#define IDC_BUTTON_LOOP_MPE             1037
#define IDC_BUTTON24                    1038
#define IDC_BUTTON25                    1039
#define IDC_BUTTON26                    1040
#define IDC_BUTTON_I2C_RW               1040
#define IDC_BUTTON27                    1041
#define IDC_BUTTON_LOOP_DATA            1041
#define IDC_BUTTON28                    1042
#define IDC_BUTTONWRITE_MAC             1042
#define IDC_BUTTON29                    1043
#define IDC_BUTTON_SET_PID_FILTER       1043
#define IDC_BUTTON30                    1044
#define IDC_BUTTON31                    1045
#define IDC_BUTTON32                    1046
#define IDC_BUTTON_DEL_PID_FILTER       1046
#define IDC_BUTTON33                    1047
#define IDC_BUTTON_SET_ES               1047
#define IDC_BUTTON34                    1048
#define IDC_BUTTON_DEL_ES               1048
#define IDC_BUTTON35                    1049
#define IDC_BUTTON_SET_ES_FILE          1049
#define IDC_EDIT7                       1050
#define IDC_EDIT_WRITE_LEN              1050
#define IDC_BUTTON36                    1051
#define IDC_BUTTON_DEL_ES_FILE          1051
#define IDC_BUTTON37                    1052
#define IDC_BUTTON_GET_VER              1052
#define IDC_BUTTON38                    1053
#define IDC_BUTTON_ISO_BYTES            1053
#define IDC_BUTTON39                    1054
#define IDC_BUTTON_PID_CNT              1054
#define IDC_BUTTON_I2C_READ             1055
#define IDC_EDIT_READ_LEN               1056
#define IDC_EDIT_I2C_WRITE              1057
#define IDC_EDIT_FID                    1058
#define IDC_EDIT_IP                     1059
#define IDC_EDIT_PORT                   1060
#define IDC_BUTTON_CLOSE_PREV_APP       1061
#define IDC_BUTTON_STCGETREG            1062
#define IDC_BUTTON_STCSETREG            1063
#define IDC_BUTTON_STCSETGPIO           1064
#define IDC_BUTTON_STCGETGPIO           1065
#define IDC_EDIT_ADDR                   1066
#define IDC_EDIT_WERT                   1067
#define IDC_WS_TEST_AN                  1068
#define IDC_WS_TEST_AUS                 1069
#define IDC_BUTTON_UPDATE_STC           1070
#define IDC_BUTTON_INSTANZ              1071
#define IDC_BUTTON_CLOSE_CURR_APP       1072
#define IDC_BUTTON_LED                  1073
#define IDC_CHECK_POS_A_B               1075
#define IDC_BUTTON_SCR                  1076
#define IDC_BUTTON_I_FRAME              1077
#define IDC_EDIT8                       1078
#define IDC_USB_BANDWIDTH               1080
#define IDC_BUTTON_DEV_ID               1081
#define IDC_BUTTON_EON                  1082
#define IDC_EDIT_TTPID                  1083
#define IDC_BUTTON_TTON                 1084
#define IDC_BUTTON_TTOFF                1085
#define IDC_BUTTON_STRESS               1086

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        129
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1087
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
