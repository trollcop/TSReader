// TestAppLcdDlg.h : header file
//

#if !defined(AFX_TESTAPPLCDDLG_H__13AF57D3_120E_11D4_B83C_00105A22770E__INCLUDED_)
#define AFX_TESTAPPLCDDLG_H__13AF57D3_120E_11D4_B83C_00105A22770E__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


#include <DVBCommon.h>
#include <DVBBoardControl.h>
#include <DVBFrontend.h>
#include <DVBTSFilter.h>
#include <DVBFilterToFile.h>
#include <DVBTeleText.h>
#include <DVBComnIF.h>
#include <DVBRemoteControl.h>

/////////////////////////////////////////////////////////////////////////////
// CTestAppLcdDlg dialog

class CMyTeleText : public CDVBTeletext
{
public:
	CMyTeleText();
	virtual ~CMyTeleText();

	void OnTTXPage(BYTE* TTXPage, int len);
};

class CMyFilter : public CDVBTSFilter
{
public:
	CMyFilter();
	virtual ~CMyFilter();
	
//	CFile m_File;

	void OnDataArrival(BYTE* Buff, int len);
};

class CTestAppLcdDlg : public CDialog
{
// Construction
public:
	CTestAppLcdDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CTestAppLcdDlg)
	enum { IDD = IDD_TESTAPPLCD_DIALOG };
	CString	m_strOutput;
	CString	m_strFEStatus;
	CString	m_strPID;
	CString	m_strDevNr;
	BOOL	m_LNBPower;
	BOOL	m_Diseqc;
	CString	m_strFreq;
	CString	m_strSymb;
	int		m_iPol;
	CString	m_strPID2;
	CString	m_strDebiAddr;
	CString	m_strDebiData;
	BOOL	m_bCIVideoPort;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTestAppLcdDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CTestAppLcdDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnDestroy();
	afx_msg void OnSetFrontend();
	afx_msg void OnGetFEStatus();
	afx_msg void OnEnableDMA();
	afx_msg void OnDisableDMA();
	afx_msg void OnGetMAC();
	afx_msg void OnSetFilterMPE();
	afx_msg void OnDelFilterMPE();
	afx_msg void OnGetByteCount();
	afx_msg void OnGetMCList();
	afx_msg void OnSetFilterPES();
	afx_msg void OnDelFilterPES();
	afx_msg void OnOpenDevice();
	afx_msg void OnCloseDevice();
	afx_msg void OnDevicesInfo();
	afx_msg void OnInitFrontend();
	afx_msg void OnSetFilterSEC();
	afx_msg void OnDelFilterSEC();
	afx_msg void OnGetIP();
	afx_msg void OnReset();
	afx_msg void OnStartEStoFile();
	afx_msg void OnStopEStoFile();
	afx_msg void OnSetFilterES();
	afx_msg void OnDelFilterES();
	afx_msg void OnSetFilterTS();
	afx_msg void OnDelFilterTS();
	afx_msg void OnSetFilterPID();
	afx_msg void OnDelFilterPID();
	afx_msg void OnStartSectoFile();
	afx_msg void OnStopSectoFile();
	afx_msg void OnStartPEStoFile();
	afx_msg void OnStopPEStoFile();
	afx_msg void OnStartTStoFile();
	afx_msg void OnStopTStoFile();
	afx_msg void OnStartPIDtoFile();
	afx_msg void OnStopPIDtoFile();
	afx_msg void OnSetFilterMPID();
	afx_msg void OnDelFilterMPID();
	afx_msg void OnStartMPIDtoFile();
	afx_msg void OnStopMPIDtoFile();
	afx_msg void OnButtonTtxon();
	afx_msg void OnButtonTtxoff();
	afx_msg void OnButtonStartCi();
	afx_msg void OnButtonStopCi();
	afx_msg void OnCheckVideoPort();
	afx_msg void OnButtonCaPmt();
	afx_msg void OnButtonIr();
	afx_msg void OnButtonDrvStat();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

private:
	CDVBBoardControl m_BoardControl;
	CDVBFrontend  m_FE;
	
	CDVBTSFilter m_MPEFilter;
	CMyFilter m_SecFilter;
	CMyFilter m_PESFilter;
	CMyFilter m_ESFilter;
	CMyFilter m_TSFilter;
	CMyFilter m_PIDFilter;
	CMyFilter m_MPIDFilter;

	CDVBFilterToFile m_SecFilterToFile;
	CDVBFilterToFile m_PESFilterToFile;
	CDVBFilterToFile m_ESFilterToFile;
	CDVBFilterToFile m_TSFilterToFile;
	CDVBFilterToFile m_PIDFilterToFile;
	CDVBFilterToFile m_MPIDFilterToFile;

	CMyTeleText m_Teletext;
	CDVBComnIF m_DVBComnIF;
	CDVBRemoteControl m_RC;
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TESTAPPLCDDLG_H__13AF57D3_120E_11D4_B83C_00105A22770E__INCLUDED_)
