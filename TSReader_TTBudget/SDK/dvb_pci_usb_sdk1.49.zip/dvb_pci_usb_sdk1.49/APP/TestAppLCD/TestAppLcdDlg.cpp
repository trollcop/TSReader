// TestAppLcdDlg.cpp : implementation file
//

#include "stdafx.h"
#include "TestAppLcd.h"
#include "TestAppLcdDlg.h"

#include <direct.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTestAppLcdDlg dialog

CTestAppLcdDlg::CTestAppLcdDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CTestAppLcdDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CTestAppLcdDlg)
	m_strOutput = _T("");
	m_strFEStatus = _T("");
	m_strPID = _T("104");
	m_strDevNr = _T("0");
	m_LNBPower = TRUE;
	m_Diseqc = TRUE;
	m_strFreq = _T("12640000");	// m_strFreq = _T("11836000");
	m_strSymb = _T("22000000");	// m_strSymb = _T("27500000");
	m_iPol = 1; // == Vert. (14V)
	m_strPID2 = _T("");
	m_strDebiAddr = _T("");
	m_strDebiData = _T("");
	m_bCIVideoPort = FALSE;
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CTestAppLcdDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CTestAppLcdDlg)
	DDX_Text(pDX, IDC_EDIT1, m_strOutput);
	DDX_Text(pDX, IDC_EDIT2, m_strFEStatus);
	DDX_Text(pDX, IDC_EDIT3, m_strPID);
	DDX_Text(pDX, IDC_EDIT4, m_strDevNr);
	DDX_Check(pDX, IDC_CHECK1, m_LNBPower);
	DDX_Check(pDX, IDC_CHECK2, m_Diseqc);
	DDX_Text(pDX, IDC_EDIT5, m_strFreq);
	DDX_Text(pDX, IDC_EDIT6, m_strSymb);
	DDX_Radio(pDX, IDC_RADIO1, m_iPol);
	DDX_Text(pDX, IDC_EDIT7, m_strPID2);
	DDX_Text(pDX, IDC_EDIT_DEBI_ADDR, m_strDebiAddr);
	DDX_Text(pDX, IDC_EDIT_DEBI_DATA, m_strDebiData);
	DDX_Check(pDX, IDC_CHECK_VIDEO_PORT, m_bCIVideoPort);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CTestAppLcdDlg, CDialog)
	//{{AFX_MSG_MAP(CTestAppLcdDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_WM_DESTROY()
	ON_BN_CLICKED(IDC_BUTTON7, OnSetFrontend)
	ON_BN_CLICKED(IDC_BUTTON8, OnGetFEStatus)
	ON_BN_CLICKED(IDC_BUTTON1, OnEnableDMA)
	ON_BN_CLICKED(IDC_BUTTON2, OnDisableDMA)
	ON_BN_CLICKED(IDC_BUTTON9, OnGetMAC)
	ON_BN_CLICKED(IDC_BUTTON10, OnSetFilterMPE)
	ON_BN_CLICKED(IDC_BUTTON11, OnDelFilterMPE)
	ON_BN_CLICKED(IDC_BUTTON12, OnGetByteCount)
	ON_BN_CLICKED(IDC_BUTTON13, OnGetMCList)
	ON_BN_CLICKED(IDC_BUTTON15, OnSetFilterPES)
	ON_BN_CLICKED(IDC_BUTTON16, OnDelFilterPES)
	ON_BN_CLICKED(IDC_BUTTON14, OnOpenDevice)
	ON_BN_CLICKED(IDC_BUTTON17, OnCloseDevice)
	ON_BN_CLICKED(IDC_BUTTON19, OnDevicesInfo)
	ON_BN_CLICKED(IDC_BUTTON18, OnInitFrontend)
	ON_BN_CLICKED(IDC_BUTTON4, OnSetFilterSEC)
	ON_BN_CLICKED(IDC_BUTTON20, OnDelFilterSEC)
	ON_BN_CLICKED(IDC_BUTTON21, OnGetIP)
	ON_BN_CLICKED(IDC_BUTTON22, OnReset)
	ON_BN_CLICKED(IDC_BUTTON3, OnStartEStoFile)
	ON_BN_CLICKED(IDC_BUTTON5, OnStopEStoFile)
	ON_BN_CLICKED(IDC_BUTTON6, OnSetFilterES)
	ON_BN_CLICKED(IDC_BUTTON23, OnDelFilterES)
	ON_BN_CLICKED(IDC_BUTTON29, OnSetFilterTS)
	ON_BN_CLICKED(IDC_BUTTON28, OnDelFilterTS)
	ON_BN_CLICKED(IDC_BUTTON32, OnSetFilterPID)
	ON_BN_CLICKED(IDC_BUTTON33, OnDelFilterPID)
	ON_BN_CLICKED(IDC_BUTTON30, OnStartSectoFile)
	ON_BN_CLICKED(IDC_BUTTON31, OnStopSectoFile)
	ON_BN_CLICKED(IDC_BUTTON24, OnStartPEStoFile)
	ON_BN_CLICKED(IDC_BUTTON25, OnStopPEStoFile)
	ON_BN_CLICKED(IDC_BUTTON26, OnStartTStoFile)
	ON_BN_CLICKED(IDC_BUTTON27, OnStopTStoFile)
	ON_BN_CLICKED(IDC_BUTTON34, OnStartPIDtoFile)
	ON_BN_CLICKED(IDC_BUTTON35, OnStopPIDtoFile)
	ON_BN_CLICKED(IDC_BUTTON36, OnSetFilterMPID)
	ON_BN_CLICKED(IDC_BUTTON37, OnDelFilterMPID)
	ON_BN_CLICKED(IDC_BUTTON38, OnStartMPIDtoFile)
	ON_BN_CLICKED(IDC_BUTTON39, OnStopMPIDtoFile)
	ON_BN_CLICKED(IDC_BUTTON_TTXON, OnButtonTtxon)
	ON_BN_CLICKED(IDC_BUTTON_TTXOFF, OnButtonTtxoff)
	ON_BN_CLICKED(IDC_BUTTON_START_CI, OnButtonStartCi)
	ON_BN_CLICKED(IDC_BUTTON_STOP_CI, OnButtonStopCi)
	ON_BN_CLICKED(IDC_CHECK_VIDEO_PORT, OnCheckVideoPort)
	ON_BN_CLICKED(IDC_BUTTON_CA_PMT, OnButtonCaPmt)
	ON_BN_CLICKED(IDC_BUTTON_IR, OnButtonIr)
	ON_BN_CLICKED(IDC_BUTTON_DRV_STAT, OnButtonDrvStat)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTestAppLcdDlg message handlers

BOOL CTestAppLcdDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
	
	_mkdir("c:\\filter\\");

	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CTestAppLcdDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CTestAppLcdDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CTestAppLcdDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CTestAppLcdDlg::OnDestroy() 
{
	CDialog::OnDestroy();
	
	// TODO: Add your message handler code here

	m_MPEFilter.ResetFilter();
	m_PESFilter.ResetFilter();
	m_SecFilter.ResetFilter();
	
	m_BoardControl.EnableDataDMA(FALSE);
	
	CDVBCommon::CloseDevice();
}


#define DISEQC_HIGH_NIBLE	0xF0
#define DISEQC_LOW_BAND		0x00
#define DISEQC_HIGH_BAND	0x01
#define DISEQC_VERTICAL		0x00
#define DISEQC_HORIZONTAL	0x02
#define DISEQC_POSITION_A	0x00
#define DISEQC_POSITION_B	0x04
#define DISEQC_OPTION_A		0x00
#define DISEQC_OPTION_B		0x08

void CTestAppLcdDlg::OnSetFrontend() 
{
	UpdateData(TRUE);

	if(m_FE.GetType() == CDVBFrontend::FE_SATELLITE)
	{
		DWORD dwFrequenz = strtoul(m_strFreq, NULL, 10);
		DWORD dwSymbolrate = strtoul(m_strSymb, NULL, 10);

		if(m_Diseqc)
		{
			BYTE DiPar[4];
			
			DiPar[0] = 0xE0; DiPar[1] = 0x10; DiPar[2] = 0x38;
			DiPar[3] = DISEQC_HIGH_NIBLE;
			if(!m_iPol) // H
				DiPar[3] |= DISEQC_HORIZONTAL;
			else // V
				DiPar[3] |= DISEQC_VERTICAL;
			if(dwFrequenz > 11700000)
				DiPar[3] |= DISEQC_HIGH_BAND;
			else
				DiPar[3] |= DISEQC_LOW_BAND;
			DiPar[3] |= DISEQC_POSITION_A;
			DiPar[3] |= DISEQC_OPTION_A;
			for(int i=0; i<3; i++)
			{
				m_FE.SendDiSEqCMsg(DiPar, 4, 0xff);
				DiPar[0] = 0xE1; // Wiederholung
				Sleep(120); // Wartezeit zwischen Diseqc-Sequenzen
			}
		}
		
		CDVBFrontend::CHANNEL_TYPE ch;

		ch.dvb_s.dwFreq = dwFrequenz;
		ch.dvb_s.dwLOF = (dwFrequenz > 11700000) ? 10600000 : 9750000;
		ch.dvb_s.bF22kHz = (dwFrequenz > 11700000) ? TRUE : FALSE;
		ch.dvb_s.LNB_Power = (! m_LNBPower) ? CDVBFrontend::POWER_OFF : (! m_iPol) ? CDVBFrontend::POL_HORZ : CDVBFrontend::POL_VERT;
		ch.dvb_s.dwSymbRate = dwSymbolrate;
		ch.dvb_s.Inversion = CDVBFrontend::SI_AUTO;
		//ch.dvb_s.Inversion = CDVBFrontend::SI_ON;
		ch.dvb_s.Viterbi = CDVBFrontend::VR_AUTO;
		
		m_FE.SetChannel(ch);
	}
	else if(m_FE.GetType() == CDVBFrontend::FE_CABLE)
	{
		DWORD dwFrequenz = strtoul(m_strFreq, NULL, 10);
		DWORD dwSymbolrate = strtoul(m_strSymb, NULL, 10);

		CDVBFrontend::CHANNEL_TYPE ch;

		ch.dvb_c.dwFreq = dwFrequenz;
		ch.dvb_c.dwSymbRate = dwSymbolrate;
		ch.dvb_c.Inversion = CDVBFrontend::SI_AUTO;
		ch.dvb_c.Qam = CDVBFrontend::QAM_64;

		m_FE.SetChannel(ch);
	}
	else if(m_FE.GetType() == CDVBFrontend::FE_TERRESTRIAL)
	{
		DWORD dwFrequenz = strtoul(m_strFreq, NULL, 10);
		DWORD dwSymbolrate = strtoul(m_strSymb, NULL, 10);

		CDVBFrontend::CHANNEL_TYPE ch;

		ch.dvb_t.dwFreq = dwFrequenz;
		ch.dvb_t.Inversion = CDVBFrontend::SI_AUTO;

		m_FE.SetChannel(ch);
	}
	else
		MessageBox("unknown Frontend-Type!");
}

void CTestAppLcdDlg::OnGetFEStatus() 
{
	//LOCKSTATE_OLD lock;
	BOOL lock = FALSE;
	CDVBFrontend::SIGNAL_TYPE Signal;
	BYTE quality = 0;

	UpdateData(TRUE);

	if(m_FE.GetState(lock, &Signal) == DVB_ERR_NONE)
	{
		if(lock)
			m_strFEStatus = "Locked!";
		else
			m_strFEStatus = "Not locked!";

		if(Signal.BER < 10e-4)
			quality = 75; // 75%
		else if(Signal.BER < 10e-3)
			quality = 50; // 50%
		else if(Signal.BER < 10e-2)
			quality = 25; // 25%
		else // (Signal.BER >= 10e-2)
			quality = 0; // 0%

		if(lock)
			quality += 25;

		m_strOutput.Format("Signal.BER: %f (%e), Quality: %u%%, Level: %u%%", Signal.BER, Signal.BER, quality, Signal.SNR100);
	}

	UpdateData(FALSE);
}

void CTestAppLcdDlg::OnEnableDMA() 
{
	m_BoardControl.EnableDataDMA(TRUE);
}

void CTestAppLcdDlg::OnDisableDMA() 
{
	m_BoardControl.EnableDataDMA(FALSE);
}

void CTestAppLcdDlg::OnGetMAC() 
{
	DWORD oid, snr;
	
	UpdateData(TRUE);

	if(m_BoardControl.GetMACAddress(oid, snr) != DVB_ERR_NONE)
		MessageBox("Could not get MAC!");
	else
	{
		m_strOutput.Format("MAC: %06x%06x", oid, snr);
		UpdateData(FALSE);
	}
}

void CTestAppLcdDlg::OnGetByteCount() 
{
	UpdateData(TRUE);
	m_strOutput.Format("ByteCount: (MPE)%u, (PES)%u, (SEC)%u", m_MPEFilter.GetByteCount(),m_PESFilter.GetByteCount(),m_SecFilter.GetByteCount());
	UpdateData(FALSE);
}

void CTestAppLcdDlg::OnGetMCList() 
{
	CString strA, strB;
	CDVBBoardControl::MULTICAST_LIST mcl;
	char pf[33];
	UINT i;

	if(m_BoardControl.GetMulticastList(mcl) == DVB_ERR_NONE)
	{
		strB.Format("Multicast-List Eintrage: %u\n\r", mcl.MulticastListInUse);
		for(i=0; i<mcl.MulticastListInUse; i++)
		{
			strA.Format("MC-MAC: %02x%02x%02x%02x%02x%02x\n\r", mcl.AddressList[i][0],mcl.AddressList[i][1],mcl.AddressList[i][2],mcl.AddressList[i][3],mcl.AddressList[i][4],mcl.AddressList[i][5]);
			strB += strA;
		}
		strA.Format("Packet-Filter: %u\n\r", mcl.PacketFilter);
		strB += strA;
		for(i=0; i<32; i++)
			pf[31-i] = ((mcl.PacketFilter>>i)&0x01) + 0x30;
		pf[32] = 0;
		strB += pf;
		MessageBox(strB);
	}
	else
	{
		MessageBox("Fehler beim Lesen der Mulicast-Liste!");
	}
}

void CTestAppLcdDlg::OnOpenDevice() 
{
	UpdateData(TRUE);

	WORD wDev = (WORD)strtoul(m_strDevNr, NULL, 10);
	
	CDVBCommon::OpenDevice(wDev);
}

void CTestAppLcdDlg::OnCloseDevice() 
{
	CDVBCommon::CloseDevice();
}

void CTestAppLcdDlg::OnDevicesInfo() 
{
	CString s, t, Name, MAC, IP;
	WORD w = CDVBCommon::GetNumberOfDevices();
	
	s.Format("Number of Devices: %u\n", w);
	for(WORD i=0; i<w; i++)
	{
		CDVBCommon::GetDeviceInfo(i, Name, MAC, IP);
		t.Format("Nr: %u, Name: %s, MAC: %s, IP: %s\n", i, Name, MAC, IP);
		s += t;
	}

	MessageBox(s);
}

void CTestAppLcdDlg::OnInitFrontend() 
{
	// Frontend aus Reset nehmen und Frontend initialisieren
	m_FE.Init();
}

void CTestAppLcdDlg::OnGetIP() 
{
	DWORD _ip, _sm;
	WORD bp;
	BYTE ip[4], sm[4];

	UpdateData(TRUE);

	if(m_BoardControl.Get_IP_SM_BP(_ip, _sm, bp) != DVB_ERR_NONE)
		MessageBox("Could not get IP!");
	else
	{
		*(DWORD*)ip = _ip;
		*(DWORD*)sm = _sm;
		m_strOutput.Format("IP-Address: %u.%u.%u.%u, SubnetMask: %u.%u.%u.%u, BasePort: %u", ip[0],ip[1],ip[2],ip[3], sm[0],sm[1],sm[2],sm[3], bp);
		UpdateData(FALSE);
	}
}

void CTestAppLcdDlg::OnReset() 
{
	m_BoardControl.ResetInit();
}

void CTestAppLcdDlg::OnSetFilterMPE() 
{
	UpdateData(TRUE);

	BYTE fd[1] = {0x3e};
	BYTE fm[1] = {0xff};

	WORD wPID = (WORD)strtoul(m_strPID, NULL, 10);
	
	if(m_MPEFilter.SetFilter(CDVBTSFilter::MPE_SECTION_FILTER, wPID, fd, fm, 1) != DVB_ERR_NONE)
		MessageBox("Could not set Filter!");
}

void CTestAppLcdDlg::OnDelFilterMPE() 
{
	if(m_MPEFilter.ResetFilter() != DVB_ERR_NONE)
		MessageBox("Could not delete Filter!");
}

void CTestAppLcdDlg::OnSetFilterSEC() 
{
	UpdateData(TRUE);

	WORD wPID = (WORD)strtoul(m_strPID, NULL, 10);
	if(m_SecFilter.SetFilter(CDVBTSFilter::SECTION_FILTER, wPID, NULL, NULL, 0) != DVB_ERR_NONE)
		MessageBox("Could not set Section Filter!");
	else if(! m_SecFilter.SOpen(m_SecFilter.GetFilterID()))
		MessageBox("Could not open Socket!");

}

void CTestAppLcdDlg::OnDelFilterSEC() 
{
	if(m_SecFilter.ResetFilter() != DVB_ERR_NONE)
		MessageBox("Could not delete Section Filter!");
	else
		m_SecFilter.SClose();
}

void CTestAppLcdDlg::OnSetFilterPES() 
{
	UpdateData(TRUE);

	WORD wPID = (WORD)strtoul(m_strPID, NULL, 10);
	if(m_PESFilter.SetFilter(CDVBTSFilter::PES_FILTER, wPID, NULL, NULL, 0) != DVB_ERR_NONE)
		MessageBox("Could not set Filter!");
	else if(! m_PESFilter.SOpen(m_PESFilter.GetFilterID()))
		MessageBox("Could not open Socket!");
}

void CTestAppLcdDlg::OnDelFilterPES() 
{
	if(m_PESFilter.ResetFilter() != DVB_ERR_NONE)
		MessageBox("Could not delete Filter!");
	else
		m_PESFilter.SClose();
}

void CTestAppLcdDlg::OnSetFilterES() 
{
	UpdateData(TRUE);

	WORD wPID = (WORD)strtoul(m_strPID, NULL, 10);
	if(m_ESFilter.SetFilter(CDVBTSFilter::ES_FILTER, wPID, NULL, NULL, 0) != DVB_ERR_NONE)
		MessageBox("Could not set Filter!");
	else if(! m_ESFilter.SOpen(m_ESFilter.GetFilterID()))
		MessageBox("Could not open Socket!");
}

void CTestAppLcdDlg::OnDelFilterES() 
{
	if(m_ESFilter.ResetFilter() != DVB_ERR_NONE)
		MessageBox("Could not delete Filter!");
	else
		m_ESFilter.SClose();
}

void CTestAppLcdDlg::OnSetFilterTS() 
{
	UpdateData(TRUE);

//	if(m_TSFilter.m_File.m_hFile != CFile::hFileNull)
//		m_TSFilter.m_File.Close();


//	if(m_TSFilter.m_File.Open("C:\\TSData.bin", CFile::modeCreate | CFile::modeWrite))
//	{
		if(m_TSFilter.SetFilter(CDVBTSFilter::TS_FILTER, 0, NULL, NULL, 0) != DVB_ERR_NONE)
			MessageBox("Could not set Filter!");
		else if(! m_TSFilter.SOpen(m_TSFilter.GetFilterID()))
			MessageBox("Could not open Socket!");
//	}
//	else
//		MessageBox("Could not open File!");
}

void CTestAppLcdDlg::OnDelFilterTS() 
{
	if(m_TSFilter.ResetFilter() != DVB_ERR_NONE)
		MessageBox("Could not delete Filter!");
	else
		m_TSFilter.SClose();

//	m_TSFilter.m_File.Close();
}

void CTestAppLcdDlg::OnSetFilterPID() 
{
	UpdateData(TRUE);

	WORD wPID = (WORD)strtoul(m_strPID, NULL, 10);
	if(m_PIDFilter.SetFilter(CDVBTSFilter::PID_FILTER, wPID, NULL, NULL, 0) != DVB_ERR_NONE)
		MessageBox("Could not set Filter!");
	else if(! m_PIDFilter.SOpen(m_PIDFilter.GetFilterID()))
		MessageBox("Could not open Socket!");
}

void CTestAppLcdDlg::OnDelFilterPID() 
{
	if(m_PIDFilter.ResetFilter() != DVB_ERR_NONE)
		MessageBox("Could not delete Filter!");
	else
		m_PIDFilter.SClose();
}

void CTestAppLcdDlg::OnSetFilterMPID() 
{
	UpdateData(TRUE);

	WORD apid[2];

	apid[0] = (WORD)strtoul(m_strPID, NULL, 10);
	apid[1] = (WORD)strtoul(m_strPID2, NULL, 10);
	if(m_MPIDFilter.SetMultiPIDFilter(apid, 2) != DVB_ERR_NONE)
		MessageBox("Could not set Filter!");
	else if(! m_MPIDFilter.SOpen(m_MPIDFilter.GetFilterID()))
		MessageBox("Could not open Socket!");
}

void CTestAppLcdDlg::OnDelFilterMPID() 
{
	if(m_MPIDFilter.ResetFilter() != DVB_ERR_NONE)
		MessageBox("Could not delete Filter!");
	else
		m_MPIDFilter.SClose();
}



void CTestAppLcdDlg::OnStartSectoFile() 
{
	UpdateData(TRUE);

	WORD wPID = (WORD)strtoul(m_strPID, NULL, 10);

	m_SecFilterToFile.SetFileParams("c:\\filter\\dvblcd.sec");
	
	if(m_SecFilterToFile.StartFilter(CDVBTSFilter::SECTION_FILTER, wPID, NULL, NULL, 0) != DVB_ERR_NONE)
		MessageBox("Could not start FilterToFile!");
}

void CTestAppLcdDlg::OnStopSectoFile() 
{
	m_SecFilterToFile.StopFilter();
}

void CTestAppLcdDlg::OnStartPEStoFile() 
{
	UpdateData(TRUE);

	WORD wPID = (WORD)strtoul(m_strPID, NULL, 10);

	m_PESFilterToFile.SetFileParams("c:\\filter\\dvblcd.pes");
	
	if(m_PESFilterToFile.StartFilter(CDVBTSFilter::PES_FILTER, wPID, NULL, NULL, 0) != DVB_ERR_NONE)
		MessageBox("Could not start FilterToFile!");
}

void CTestAppLcdDlg::OnStopPEStoFile() 
{
	m_PESFilterToFile.StopFilter();
}

void CTestAppLcdDlg::OnStartEStoFile() 
{
	UpdateData(TRUE);

	WORD wPID = (WORD)strtoul(m_strPID, NULL, 10);

	m_ESFilterToFile.SetFileParams("c:\\filter\\dvblcd.es");
	
	if(m_ESFilterToFile.StartFilter(CDVBTSFilter::ES_FILTER, wPID, NULL, NULL, 0) != DVB_ERR_NONE)
		MessageBox("Could not start FilterToFile!");
}

void CTestAppLcdDlg::OnStopEStoFile() 
{
	m_ESFilterToFile.StopFilter();
}

void CTestAppLcdDlg::OnStartTStoFile() 
{
	UpdateData(TRUE);

	m_TSFilterToFile.SetFileParams("c:\\filter\\dvblcd.ts");
	
	if(m_TSFilterToFile.StartFilter(CDVBTSFilter::TS_FILTER, 0, NULL, NULL, 0) != DVB_ERR_NONE)
		MessageBox("Could not start FilterToFile!");
}

void CTestAppLcdDlg::OnStopTStoFile() 
{
	m_TSFilterToFile.StopFilter();
}

void CTestAppLcdDlg::OnStartPIDtoFile() 
{
	UpdateData(TRUE);

	WORD wPID = (WORD)strtoul(m_strPID, NULL, 10);

	m_PIDFilterToFile.SetFileParams("c:\\filter\\dvblcd.pid");
	
	if(m_PIDFilterToFile.StartFilter(CDVBTSFilter::PID_FILTER, wPID, NULL, NULL, 0) != DVB_ERR_NONE)
		MessageBox("Could not start FilterToFile!");
}

void CTestAppLcdDlg::OnStopPIDtoFile() 
{
	m_PIDFilterToFile.StopFilter();
}

void CTestAppLcdDlg::OnStartMPIDtoFile() 
{
	UpdateData(TRUE);

	WORD apid[2];

	apid[0] = (WORD)strtoul(m_strPID, NULL, 10);
	apid[1] = (WORD)strtoul(m_strPID2, NULL, 10);

	m_MPIDFilterToFile.SetFileParams("c:\\filter\\dvblcd.mpid");

	if(m_MPIDFilterToFile.StartMultiPIDFilter(apid, 2) != DVB_ERR_NONE)
		MessageBox("Could not start FilterToFile!");
}

void CTestAppLcdDlg::OnStopMPIDtoFile() 
{
	m_MPIDFilterToFile.StopFilter();
}

void CTestAppLcdDlg::OnButtonDrvStat()
{
	DWORD aData[16];
	DWORD dwWrong1, dwWrong2, dwPktCounter;
	CString s;

	if(m_BoardControl.GetDriverStatus(aData, 16))
	{
		dwPktCounter = aData[15]; // Anzahl der eingetroffenen TS-Pakete
		dwWrong1     = aData[ 9]; // Zahl der ung�ltigen TS-Pakete
		dwWrong2     = aData[10]; // Zahl der TS-Kontinuit�tsfehler (filterunabh�ngig)

		m_strOutput.Format("Pkts: %u, Bad: %u, Kont: %u", dwPktCounter, dwWrong1, dwWrong2);
		UpdateData(FALSE);

	}
}


//=======================================================================

CMyFilter::CMyFilter()
{

}

CMyFilter::~CMyFilter()
{

}
	
#define	PID_MASK	0x1FFF

void CMyFilter::OnDataArrival(BYTE* Buff, int len)
{
	TRACE("OnDataArrival\n");
	for(int i=0; ((i<len) && (i<8)); i++)
	{
		TRACE("%02x ", Buff[i]);
	}
	TRACE("\n");
/*
	WORD PID;
	int packs = len / 188;

	for(int i=0; i<packs; i++)
	{
		PID = ((Buff[i*188 + 1] << 8) + Buff[i*188 + 2]) & PID_MASK;
		if((PID != 111) && (PID != 121) && (PID != 131) && (PID != 141) && (PID != 112))
		{
			if(m_File.m_hFile != CFile::hFileNull)
				m_File.Write(Buff+i*188, 188);
		}
	}
*/
}

CMyTeleText::CMyTeleText()
{

}

CMyTeleText::~CMyTeleText()
{
	TTXOff();
}
	
void CMyTeleText::OnTTXPage(BYTE* Buff, int len)
{
	//TRACE("OnDataArrival\n");
	for(int i=0; ((i<len) && (i<40)); i++)
	{
		if((Buff[i] >= 32) && (Buff[i] < 128))
			TRACE("%c ", Buff[i]);
		else
			TRACE(". ");
	}
	TRACE("\n");
}


void CTestAppLcdDlg::OnButtonTtxon() 
{
	DVB_ERROR err;
	WORD wMag, wTens, wUnits;

	UpdateData(TRUE);

	WORD wPID = (WORD)strtoul(m_strPID, NULL, 10);

	//DVB_ERROR TTXOn(WORD wPID);
	err = m_Teletext.TTXOn(wPID);
	if(err != DVB_ERR_NONE)
		MessageBox("Could not start Teletext!");
	
	wMag = wTens = wUnits = (WORD)-1;

	if(! m_Teletext.TTXModifySearchTable(wMag, wTens, wUnits, CDVBTeletext::CAPTURE_PAGE_PARITY_CORRECTED))
		MessageBox("Could not modify SearchTable!");

}

void CTestAppLcdDlg::OnButtonTtxoff() 
{
	if(m_Teletext.TTXOff() != DVB_ERR_NONE)
		MessageBox("Could not stop Teletext!");
}
/*
void CTestAppLcdDlg::OnButtonDebiIn8() 
{
	UpdateData(TRUE);

	WORD addr = (WORD)strtoul(m_strDebiAddr, NULL, 0);

	BYTE data = m_BoardControl.DebiIn8(addr);

	m_strDebiData.Format("%u", data);

	if(m_BoardControl.GetLastDebiError() > 0)
		MessageBox("m_BoardControl.DebiIn8 failed!");

	UpdateData(FALSE);
}

void CTestAppLcdDlg::OnButtondebiOut8() 
{
	UpdateData(TRUE);

	WORD addr = (WORD)strtoul(m_strDebiAddr, NULL, 0);
	BYTE data = (BYTE)strtoul(m_strDebiData, NULL, 0);

	if(! m_BoardControl.DebiOut8(addr, data))
		MessageBox("m_BoardControl.DebiOut8 failed!");

	UpdateData(FALSE);
}
*/
void CTestAppLcdDlg::OnButtonStartCi() 
{
	m_DVBComnIF.Open();
}

void CTestAppLcdDlg::OnButtonStopCi() 
{
	m_DVBComnIF.Close();
}

void CTestAppLcdDlg::OnCheckVideoPort() 
{
	UpdateData(TRUE);

	//m_DVBComnIF.SwitchVideoPort(m_bCIVideoPort);
}

void CTestAppLcdDlg::OnButtonCaPmt() 
{
//	m_DVBComnIF.

//	BOOL CI_SetPmt( BYTE *pPmt, WORD wSize, BOOL bCheckCAIDs = TRUE,
//					BOOL bFilterPIDs = FALSE,WORD wVPID = 0, WORD APID = 0 );

}

void CTestAppLcdDlg::OnButtonIr() 
{
	// TODO: Code f�r die Behandlungsroutine der Steuerelement-Benachrichtigung hier einf�gen
	m_RC.SetRemoteControl(CDVBRemoteControl::IR_RC5);
}
