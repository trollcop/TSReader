// MyPESFilter.cpp: Implementierung der Klasse CMyPESFilter.
//
//////////////////////////////////////////////////////////////////////
 
#include "stdafx.h"
#include "TestAppLcd.h"
#include "TestAppLcdDlg.h"
#include "MyPESFilter.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Konstruktion/Destruktion
//////////////////////////////////////////////////////////////////////

CMyPESFilter::CMyPESFilter()
{
	m_pDlg = NULL;
}

CMyPESFilter::~CMyPESFilter()
{
	TRACE("\n+++ DESTRUCTOR ~CMyPESFilter");
}

void CMyPESFilter::OnPESArrival(BYTE *Buff, int len)
{
	if(m_pDlg != NULL)
		m_pDlg->ForwardPES(Buff,len);
}
