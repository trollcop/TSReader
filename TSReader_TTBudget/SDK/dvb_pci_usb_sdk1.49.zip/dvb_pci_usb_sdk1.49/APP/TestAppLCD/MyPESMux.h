// MyPESMux.h: Schnittstelle f�r die Klasse CMyPESMux.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_MYPESMUX_H__9EE66720_B0C6_11D4_9583_00D05CFFFC84__INCLUDED_)
#define AFX_MYPESMUX_H__9EE66720_B0C6_11D4_9583_00D05CFFFC84__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "PESMux.h"

class CTestAppLcdDlg;

class CMyPESMux : public CPESMux  
{
public:
	CTestAppLcdDlg * m_pDlg;
	CMyPESMux();
	virtual ~CMyPESMux();

private:
	void OnPackArrival(BYTE * buff, int len);
};

#endif // !defined(AFX_MYPESMUX_H__9EE66720_B0C6_11D4_9583_00D05CFFFC84__INCLUDED_)
