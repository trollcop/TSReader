// MyPESMux.cpp: Implementierung der Klasse CMyPESMux.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "MyPESMux.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Konstruktion/Destruktion
//////////////////////////////////////////////////////////////////////

CMyPESMux::CMyPESMux()
{
	m_pDlg = NULL;
}

CMyPESMux::~CMyPESMux()
{

}

void CMyPESMux::OnPackArrival(BYTE *buff, int len)
{
	TRACE("\nPESMUX Packet arrived (%d)",len);
}
