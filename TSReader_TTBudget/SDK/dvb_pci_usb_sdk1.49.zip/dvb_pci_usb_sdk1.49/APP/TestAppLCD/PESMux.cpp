// PESMux.cpp : Defines the initialization routines for the DLL.
//

#include "stdafx.h"
#include "PESMux.h"
  
#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


// CPESMux construction

CPESMux::CPESMux()
{   			AFX_MANAGE_STATE(AfxGetStaticModuleState());

	MAX_PACKET_LENGTH = 2000000;
	GRENZ_LEN = (MAX_PACKET_LENGTH>>2)*3;
	MAX_PES_BUFFER = 8000;
	FIRST_PTS_DELAY = 0x8000;
//	AUDIO_PTS_DELAY = 0xA000;
	MAX_PTS_DELAY = 0x10000;
	m_pPackBuffer = new BYTE[MAX_PACKET_LENGTH];
	m_pPESBuffer = new BYTE[MAX_PES_BUFFER];
	//m_pPackBuffer = (BYTE*)malloc(MAX_PACKET_LENGTH);
	//m_pPESBuffer = (BYTE*)malloc(MAX_PES_BUFFER);

#ifdef _FILETEST_
	f1.Open( "c:\\1_MUX.mpg", CFile::modeCreate | CFile::modeWrite) ;
#endif

#ifdef _FILETEST2_
	f2.Open( "c:\\1_In-MUX.PES", CFile::modeCreate | CFile::modeWrite) ;
#endif

#ifdef _FILE_LOG_
	f3 = fopen( "c:\\1_In-MUX.log", "w") ;
#endif

	m_pPESBuffer[0]=m_pPESBuffer[1]=m_pPESBuffer[2]=0xFF;
	m_bNotStart = 1;
	m_lPTS = 0xFFFFFFFFFF;
	m_nCurrPos = 0;
	m_nPackPTS = FIRST_PTS_DELAY;

}

CPESMux::~CPESMux()
{			AFX_MANAGE_STATE(AfxGetStaticModuleState());

//	free (m_pPackBuffer);
//	free (m_pPESBuffer);
	delete [] m_pPackBuffer;
	delete [] m_pPESBuffer;

#ifdef _FILETEST_
	f1.Close();
#endif
#ifdef _FILETEST2_
	f2.Close();
#endif
#ifdef _FILE_LOG_
	fclose(f3);
#endif

}

/////////////////////////////////////////////////////////////////////////////
// The one and only CPESMuxApp object

void CPESMux::InPutPESPacket(BYTE *buff, int len)
{			AFX_MANAGE_STATE(AfxGetStaticModuleState());
	int MAX_PACK_LENGTH = 180000;
	BUFF = buff;

#ifdef _FILETEST2_
	f2.Write(buff, len);                 // temp
#endif
	if (m_lFirstAuPTS)
		m_nLength += len - 19;

	if (buff[3] >= 0xC0 && buff[3] <= 0xDF) 	
	{
		buff[3] = 0xC0;
#ifdef _FILE_LOG_
		fprintf (f3, "AUDIO PES INPUT  lenA = %d\n", len);
#endif
	}
	if (buff[3] >= 0xE0 && buff[3] <= 0xEF)		
	{
		buff[3] = 0xE0;
#ifdef _FILE_LOG_
		fprintf (f3, "VIDEO PES INPUT  lenV = %d\n", len);
#endif
	}
	if (m_bNotStart) 
	{	
		if (buff[3] == 0xC0 && buff[7] & 0x80)
		{
			GetPTS(buff);
			if (m_lFirstAuPTS)
			{
				m_lSecondAuPTS = m_lPTS;
				m_nSpeed = (m_nLength * 1000) / (m_lSecondAuPTS - m_lFirstAuPTS);
				m_nLength = 0;
				m_lFirstAuPTS = m_lSecondAuPTS;
			}
			else
			{
				m_lFirstAuPTS = m_lPTS;
				m_nLength = 0;
			}
		}
		if (m_nSpeed)
		{			
			if (buff[3] == 0xE0)
				m_bNotStart = FindIFrame(buff, len);
		}
	}
	else
	{
		if (buff[3] == 0xC0 && buff[7] & 0x80)
			m_nPTSDelay = GetPTSDelay(buff);
		if (buff[3] == 0xC0 && buff[7] & 0x80 || m_nCurrPos >= MAX_PACK_LENGTH )

		{
			if (buff[3] != 0xC0 || !(buff[7] & 0x80))
			{
				m_nPTSDelay = (m_nCurrPos * 1800) / m_nLastMux;
				m_nCurrPTS = m_nPackPTS + m_nPTSDelay;
			}
m1:			OutPacket(buff, len); m_nPTSDelay = 0;
		}
		else
		{
			memcpy(m_pPackBuffer+m_nCurrPos, buff, len);
			if (buff[7] & 0x80)
			{
				GetPTS(buff);
				Set_PTS(m_pPackBuffer+m_nCurrPos+9, (long)(m_lPTS - m_lNormPTS));
	#ifdef _FILE_LOG_
			fprintf (f3, "PTS - Presentation Time Stamp = %d\n", (long)(m_lPTS - m_lNormPTS));
	#endif
				if (buff[7] & 0x40)
				{
					GetDTS(buff);
					Set_DTS(m_pPackBuffer+m_nCurrPos+14, (long)(m_lDTS - m_lNormPTS));
	#ifdef _FILE_LOG_
			fprintf (f3, "DTS - Decoding Time Stamp = %d\n", (long)(m_lDTS - m_lNormPTS));
	#endif
				}

				if (m_nCurrPos + len > GRENZ_LEN)
				{
	#ifdef _FILE_LOG_
			fprintf (f3, "!!!!!Packet Length ist grosser als GRENZ_LEN and = %d !!!!!\n", (m_nCurrPos + len));
	#endif
					m_nPTSDelay = GetPTSDelay(buff);
					goto m1;
				}
			}
			m_nCurrPos += len;
			if (MaxPackLen < m_nCurrPos) MaxPackLen = m_nCurrPos;
		}
	}

}

BOOL CPESMux::FindIFrame(BYTE *buff, int len)
{ 			AFX_MANAGE_STATE(AfxGetStaticModuleState());

  long IFrameStartCode = 0xB3010000;
  long * pL;
  bool ret=1;
  B6 = buff[6];
//	if (buff[7] & 0x80)
//		GetPTS(buff);
//	if (m_lPTS != 0xFFFFFFFFFF)
//	{
		memcpy(m_pPESBuffer+3, buff+19, len-19);
		for (int i = 0; i < len-19; i++)
		{
			pL =(long *)(m_pPESBuffer+i);
			if (*pL == IFrameStartCode)
			{
				ret = 0;
				FirstPacket(i, len-19+3);
				m_nLength += i - len;
				break;
			}
		}
//	}
	if (ret)
		memcpy(m_pPESBuffer, buff+len-3, 3);
	return(ret);
}

void CPESMux::GetPTS(BYTE *buff)
{			AFX_MANAGE_STATE(AfxGetStaticModuleState());

	__int64 i64 = 0;
	BYTE PTS[5]; BYTE b;
	BYTE *pB;
	pB = (BYTE *) &i64;
	memcpy(PTS, buff+9, 5);
	PTS[4] >>= 1;
	if (PTS[3] & 1) PTS[4] |=0x80;
	PTS[3] >>= 1;
	if (PTS[2] & 2) PTS[3] |=0x80;
	PTS[2] >>= 2;  b = PTS[1];
	b <<= 6;  	PTS[2] |= b;
	PTS[1] >>= 2;  b = PTS[0];
    PTS[0] &= 0xE; PTS[0] <<= 5;
	PTS[1] |= PTS[0];  	PTS[0] = 0;
	if (b & 8) PTS[0] = 1;
	pB[4] = PTS[0]; pB[3] = PTS[1]; pB[2] = PTS[2];
	pB[1] = PTS[3]; pB[0] = PTS[4];
	m_lOLDPTS = m_lPTS;
	m_lPTS = i64;	
//	if (buff[3] == 0xC0) m_lPTS += AUDIO_PTS_DELAY;
}

void CPESMux::GetDTS(BYTE *buff)
{			AFX_MANAGE_STATE(AfxGetStaticModuleState());

	__int64 i64 = 0;
	BYTE DTS[5]; BYTE b;
	BYTE *pB;
	pB = (BYTE *) &i64;
	memcpy(DTS, buff+14, 5);
	DTS[4] >>= 1;
	if (DTS[3] & 1) DTS[4] |=0x80;
	DTS[3] >>= 1;
	if (DTS[2] & 2) DTS[3] |=0x80;
	DTS[2] >>= 2;  b = DTS[1];
	b <<= 6;  	DTS[2] |= b;
	DTS[1] >>= 2;  b = DTS[0];
    DTS[0] &= 0xE; DTS[0] <<= 5;
	DTS[1] |= DTS[0];  	DTS[0] = 0;
	if (b & 8) DTS[0] = 1;
	pB[4] = DTS[0]; pB[3] = DTS[1]; pB[2] = DTS[2];
	pB[1] = DTS[3]; pB[0] = DTS[4];
	m_lDTS = i64;	
}


void CPESMux::Set_PTS(BYTE * NewPTS, __int64 Wert)
{			AFX_MANAGE_STATE(AfxGetStaticModuleState());
	BYTE *pB;
	pB = (BYTE *) &Wert;
	NewPTS[0] = 0x21;  NewPTS[1] = pB[3]; NewPTS[2] = pB[2];
	NewPTS[3] = pB[1]; NewPTS[4] = pB[0];
	NewPTS[4] <<= 1;   NewPTS[4] |= 1;
	NewPTS[3] <<= 1;   if (pB[0] & 0x80) NewPTS[3] |= 1;
	NewPTS[2] <<= 2;   NewPTS[2] |= 1;
	if (pB[1] & 0x80)  NewPTS[2] |= 2;
	NewPTS[1] <<= 2;   pB[2] >>= 6;  NewPTS[1] |= pB[2];
    pB[3] >>= 5;  NewPTS[0] |= pB[3]; 
}

void CPESMux::Set_DTS(BYTE * NewDTS, __int64 Wert)
{			AFX_MANAGE_STATE(AfxGetStaticModuleState());
	BYTE *pB;
	pB = (BYTE *) &Wert;
	NewDTS[-5] |= 0x10; 
	NewDTS[0] = 0x11;  NewDTS[1] = pB[3]; NewDTS[2] = pB[2];
	NewDTS[3] = pB[1]; NewDTS[4] = pB[0];
	NewDTS[4] <<= 1;   NewDTS[4] |= 1;
	NewDTS[3] <<= 1;   if (pB[0] & 0x80) NewDTS[3] |= 1;
	NewDTS[2] <<= 2;   NewDTS[2] |= 1;
	if (pB[1] & 0x80)  NewDTS[2] |= 2;
	NewDTS[1] <<= 2;   pB[2] >>= 6;  NewDTS[1] |= pB[2];
    pB[3] >>= 5;  NewDTS[0] |= pB[3]; 
}


int CPESMux::GetPTSDelay(BYTE * buff)
{			AFX_MANAGE_STATE(AfxGetStaticModuleState());
	int Ret = 0;
	GetPTS(buff);
//	if (m_lPTS < m_lNormPTS) m_lPTS += 0x0200000000;
	m_nCurrPTS = (long)(m_lPTS - m_lNormPTS);
	Ret = m_nCurrPTS - m_nPackPTS;
	return (Ret);
}

void CPESMux::FirstPacket(int First, int Last)
{			AFX_MANAGE_STATE(AfxGetStaticModuleState());

	m_lNormPTS = m_lSecondAuPTS - FIRST_PTS_DELAY + (m_nLength * 1000) / m_nSpeed;
	FormPackHeader();
	FormSystHeader();
	FormPESHeader(Last-First);
	FormSCR(0);
	for (int i = First; i < Last; i++)   
		m_pPackBuffer[m_nCurrPos++] = m_pPESBuffer[i];
}

void CPESMux::OnPackArrival(BYTE *buff, int len)
{
}

void CPESMux::FormSCR(__int64 lSCR)
{			AFX_MANAGE_STATE(AfxGetStaticModuleState());
	BYTE * ps; __int64 i64; BYTE B, *pB;
	i64 = lSCR%300;  ps =(BYTE *) &i64; pB = m_pPackBuffer;
	pB[9] = ps[0]; pB[9] <<= 1; pB[9] |= 1;
	pB[8] = 4; if (ps[0] & 0x80)  pB[8] |= 1;
	if (ps[1] & 1)  pB[8] |= 2;
	i64 = lSCR/300; 
	B = ps[0]; B <<=3; pB[8] |= B;
	pB[7] = ps[0]; pB[7] >>= 5;
	B = ps[1]; B <<=3; pB[7] |= B;
	pB[6] = ps[1]; pB[6] >>= 5;
	if (pB[6] & 4) pB[6] |= 8; pB[6] |= 4;
	B = ps[2]; B <<=4; pB[6] |= B;
	pB[5] = ps[2]; pB[5] >>= 4;
	B = ps[3]; B <<=4; pB[5] |= B;
	pB[4] = ps[3]; pB[4] >>= 4;
	if (pB[4] & 8) pB[4] |= 16; 
	if (pB[4] & 4) pB[4] |= 8;
	pB[4] |= 0x44;
	if (ps[4] & 1)  pB[4] |= 0x20;
}

void CPESMux::FormMUX(int MUX)
{			AFX_MANAGE_STATE(AfxGetStaticModuleState());
	BYTE * ps, *pB;
	MUX <<= 2; MUX |= 3;
	ps =(BYTE *) &MUX; pB = m_pPackBuffer;
	pB[10] = ps[2];
	pB[11] = ps[1];
	pB[12] = ps[0];
}

void CPESMux::FormPackHeader()
{				AFX_MANAGE_STATE(AfxGetStaticModuleState());
	BYTE *pB; pB = m_pPackBuffer;
	pB[0] = 0x00;  pB[1] = 0x00;
	pB[2] = 0x01;  pB[3] = 0xBA;
	pB[13] = 0xF8; m_nCurrPos = 14;

}

void CPESMux::FormSystHeader()
{			AFX_MANAGE_STATE(AfxGetStaticModuleState());
	BYTE *pB = m_pPackBuffer; 
	pB[m_nCurrPos++] = 0x00;  pB[m_nCurrPos++] = 0x00;
	pB[m_nCurrPos++] = 0x01;  pB[m_nCurrPos++] = 0xBB;
	pB[m_nCurrPos++] = 0x00;  pB[m_nCurrPos++] = 0x0C;
	
	pB[m_nCurrPos++] = 0x88;  // rate_bound - 14 Mbod
	pB[m_nCurrPos++] = 0x8b;
	pB[m_nCurrPos++] = 0x81;  
	
	pB[m_nCurrPos++] = 0x05;  // Flags & Video _bound
	pB[m_nCurrPos++] = 0xE1;  
	pB[m_nCurrPos++] = 0xFF;
	
	pB[m_nCurrPos++] = 0xC0;  // Audio ID
	pB[m_nCurrPos++] = 0xC0;
	pB[m_nCurrPos++] = 0x80;  // Sound P-STD buffer  - 16k
	
	pB[m_nCurrPos++] = 0xE0;  // Video ID
	pB[m_nCurrPos++] = 0xE0;  // 0xE3  -  P-STD buffer - 1.5Mb
	pB[m_nCurrPos++] = 0xE6;  // Video P-STD buffer - 230k
}

void CPESMux::FormPESHeader(int len)
{			AFX_MANAGE_STATE(AfxGetStaticModuleState());
	BYTE *pB = m_pPackBuffer; BYTE * ps; 
	int i; i = len + 13;
	ps = (BYTE *) &i;
	m_nPTSPos = m_nCurrPos+9;
	pB[m_nCurrPos] = 0x00;    pB[m_nCurrPos+1] = 0x00;
	pB[m_nCurrPos+2] = 0x01;  pB[m_nCurrPos+3] = 0xE0;
	pB[m_nCurrPos+4] = ps[1];  
	pB[m_nCurrPos+5] = ps[0]; 
	pB[m_nCurrPos+6] = B6;

// vstavyty PTS i DTS
	if (BUFF[7] & 0x80)
	{
		GetPTS(BUFF);
		Set_PTS(m_pPackBuffer+m_nCurrPos+9, (long)(m_lPTS - m_lNormPTS));
		pB[m_nCurrPos+7] = 0x80; 
		if (BUFF[7] & 0x40)
		{
			GetDTS(BUFF);
			Set_DTS(m_pPackBuffer+m_nCurrPos+14, (long)(m_lDTS - m_lNormPTS));
			pB[m_nCurrPos+7] = 0xC0; 
		}
		else
		{
			*((DWORD*)(pB+m_nCurrPos+14)) = 0xFFFFFFFF;
			pB[m_nCurrPos+18] = 0xFF;
		}

	}
							// !!Viele PES haben kein PTS!!
	pB[m_nCurrPos+8] = 0x0A;
	m_nCurrPos+=19;
#ifdef _FILE_LOG_
	fprintf (f3, "START PROGRAM PACKET: SCR  = 0\n");
	if (BUFF[7] & 0x80)
		fprintf (f3, "START PROGRAM PACKET: PTS  = %d\n", (long)(m_lPTS - m_lNormPTS));
#endif
}

void CPESMux::OutPacket(BYTE * buff, int len)
{			AFX_MANAGE_STATE(AfxGetStaticModuleState());
	int i; __int64 lSCR;
	i = m_nCurrPos * 1800 / m_nPTSDelay;
//	i *=20; ///////////////////
	FormMUX(i);
	m_nLastMux = i;
#ifdef _FILE_LOG_
		fprintf (f3, "END-END PROGRAM PACKET: RATE = %d  LENGTG = %d   DELAY = %d  MaxLen = %d\n", i, m_nCurrPos, m_nPTSDelay, MaxPackLen);
#endif

#ifdef _FILETEST_
	f1.Write(m_pPackBuffer, m_nCurrPos);                 // temp
#endif

	OnPackArrival(m_pPackBuffer, m_nCurrPos);
	m_nPackPTS = m_nCurrPTS;
	FormPackHeader();
	lSCR = (__int64)(m_nCurrPTS - FIRST_PTS_DELAY)*300;
//	lSCR  /= 20; //////////////////////////
	FormSCR(lSCR);
	memcpy(m_pPackBuffer+m_nCurrPos, buff, len);
	Set_PTS(m_pPackBuffer+m_nCurrPos+9, m_nCurrPTS);
#ifdef _FILE_LOG_
		fprintf (f3, "START PROGRAM PACKET: SCR  = %I64d\n", lSCR);
		fprintf (f3, "START PROGRAM PACKET: PTS  = %d\n", m_nCurrPTS);
#endif
	m_nCurrPos += len;
}

void CPESMux::OpenPESMux()
{
	m_pPESBuffer[0]=m_pPESBuffer[1]=m_pPESBuffer[2]=0xFF;
	m_bNotStart = 1;
	m_lPTS = 0xFFFFFFFFFF;
	m_nCurrPos = 0;
	m_nPackPTS = FIRST_PTS_DELAY;
	m_lFirstAuPTS = 0;
	m_lSecondAuPTS = 0;
	m_nLength = 0;
	m_nSpeed = 0;
	MaxPackLen = 0;

#ifdef _FILETEST_
	f1.Seek(0, CFile::begin ) ;
#endif
#ifdef _FILETEST2_
	f2.Seek(0, CFile::begin ) ;
#endif
#ifdef _FILE_LOG_
	fseek(f3, 0, SEEK_SET) ;
#endif

}
