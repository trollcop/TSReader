// MyPESFilter.h: Schnittstelle f�r die Klasse CMyPESFilter.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_MYPESFILTER_H__9EE66721_B0C6_11D4_9583_00D05CFFFC84__INCLUDED_)
#define AFX_MYPESFILTER_H__9EE66721_B0C6_11D4_9583_00D05CFFFC84__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "PESFilter.h"

class CTestAppLcdDlg;

class CMyPESFilter : public CPESFilter  
{
public:
	CTestAppLcdDlg * m_pDlg;
	CMyPESFilter();
	virtual ~CMyPESFilter();

private:
	void OnPESArrival(BYTE* Buff, int len);

};

#endif // !defined(AFX_MYPESFILTER_H__9EE66721_B0C6_11D4_9583_00D05CFFFC84__INCLUDED_)
