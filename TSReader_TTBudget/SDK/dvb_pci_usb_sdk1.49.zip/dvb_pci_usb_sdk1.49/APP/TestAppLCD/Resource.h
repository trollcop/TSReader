//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by TestAppLcd.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_TESTAPPLCD_DIALOG           102
#define IDR_MAINFRAME                   128
#define IDC_BUTTON3                     1002
#define IDC_BUTTON5                     1004
#define IDC_EDIT1                       1005
#define IDC_BUTTON6                     1006
#define IDC_BUTTON7                     1007
#define IDC_BUTTON8                     1008
#define IDC_EDIT2                       1009
#define IDC_BUTTON1                     1010
#define IDC_BUTTON2                     1011
#define IDC_BUTTON9                     1012
#define IDC_BUTTON10                    1013
#define IDC_BUTTON11                    1014
#define IDC_EDIT3                       1015
#define IDC_BUTTON12                    1016
#define IDC_BUTTON13                    1017
#define IDC_BUTTON15                    1019
#define IDC_BUTTON16                    1020
#define IDC_BUTTON14                    1021
#define IDC_BUTTON17                    1022
#define IDC_EDIT4                       1023
#define IDC_BUTTON18                    1024
#define IDC_BUTTON19                    1025
#define IDC_BUTTON4                     1026
#define IDC_BUTTON20                    1027
#define IDC_BUTTON21                    1028
#define IDC_EDIT5                       1029
#define IDC_CHECK1                      1030
#define IDC_CHECK2                      1031
#define IDC_EDIT6                       1032
#define IDC_RADIO1                      1033
#define IDC_RADIO2                      1034
#define IDC_BUTTON22                    1035
#define IDC_EDIT8                       1036
#define IDC_EDIT_DEBI_ADDR              1036
#define IDC_BUTTON23                    1037
#define IDC_BUTTON24                    1038
#define IDC_BUTTON25                    1039
#define IDC_BUTTON26                    1040
#define IDC_BUTTON27                    1041
#define IDC_BUTTON28                    1042
#define IDC_BUTTON29                    1043
#define IDC_BUTTON30                    1044
#define IDC_BUTTON31                    1045
#define IDC_BUTTON32                    1046
#define IDC_BUTTON33                    1047
#define IDC_BUTTON34                    1048
#define IDC_BUTTON35                    1049
#define IDC_EDIT7                       1050
#define IDC_BUTTON36                    1051
#define IDC_BUTTON37                    1052
#define IDC_BUTTON38                    1053
#define IDC_BUTTON39                    1054
#define IDC_EDIT9                       1055
#define IDC_EDIT_DEBI_DATA              1055
#define IDC_BUTTON40                    1056
#define IDC_BUTTON_TTXON                1056
#define IDC_BUTTON41                    1057
#define IDC_BUTTON_TTXOFF               1057
#define IDC_EDIT10                      1058
#define IDC_EDIT11                      1059
#define IDC_BUTTON42                    1060
#define IDC_BUTTON_DEBI_IN8             1060
#define IDC_BUTTON43                    1061
#define IDC_BUTTONDEBI_OUT8             1061
#define IDC_EDIT12                      1062
#define IDC_EDIT13                      1063
#define IDC_EDIT14                      1064
#define IDC_EDIT15                      1065
#define IDC_EDIT16                      1066
#define IDC_EDIT17                      1067
#define IDC_EDIT18                      1068
#define IDC_EDIT19                      1069
#define IDC_EDIT20                      1070
#define IDC_EDIT21                      1071
#define IDC_BUTTON_START_CI             1071
#define IDC_EDIT22                      1072
#define IDC_BUTTON_STOP_CI              1072
#define IDC_EDIT23                      1073
#define IDC_CHECK_VIDEO_PORT            1073
#define IDC_BUTTON_CA_PMT               1074
#define IDC_BUTTON_IR                   1075
#define IDC_BUTTON_DRV_STAT             1076

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1077
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
