// MyCommonInterface.h: Schnittstelle f�r die Klasse CMyCommonInterface.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_MYCOMMONINTERFACE_H__B7A66489_CE16_4443_91E0_A3FAC2A5020F__INCLUDED_)
#define AFX_MYCOMMONINTERFACE_H__B7A66489_CE16_4443_91E0_A3FAC2A5020F__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifdef _TTDVBLCD

#include <DVBComnIF.h>

class CCIDlg;

class CMyCommonInterface : public CDVBComnIF
{
public:
	CMyCommonInterface();
	virtual ~CMyCommonInterface();

	DVB_ERROR Open(CCIDlg* pCIDlg);
	BYTE GetAnswerLength(void){return m_nAnswerLength;};

private:
	void OnSlotStatus(BYTE nSlot, BYTE nStatus, typ_SlotInfo* csInfo);
	void OnCAStatus(BYTE nSlot, BYTE nReplyTag, WORD wStatus);
	void OnDisplayString(BYTE nSlot, char* pString, WORD wLength);
	void OnDisplayMenu(BYTE nSlot, WORD wItems, char* pStringArray, WORD wLength);
	void OnDisplayList(BYTE nSlot, WORD wItems, char* pStringArray, WORD wLength);
	void OnSwitchOsdOff(BYTE nSlot);
	void OnInputRequest(BYTE nSlot, BOOL bBlindAnswer, BYTE nExpectedLength, DWORD dwKeyMask);

	int	DisplayMenuOrList(char* pStringArray, WORD wLength, BOOL bMenu);
	void DisplayString(char* pString, WORD wLength);
	void DisplayModuleStatus(void);

	CCIDlg* m_pCIDlg;

	BOOL	m_bBlindAnswer;
	BYTE	m_nAnswerLength;
	BYTE	m_nKeyBuffer[255];
	BYTE	m_nKeyBufferIndex;
	DWORD	m_dwKeyMask;		// not implemented yet
	BYTE	m_nSlotStatus[2];
	CString	m_sModuleMenuTitle[2];
	WORD	m_wTimeout;
	WORD	m_wBufferSize;
//	WORD	m_wLastSID;
};

#endif // _TTDVBLCD

#endif // !defined(AFX_MYCOMMONINTERFACE_H__B7A66489_CE16_4443_91E0_A3FAC2A5020F__INCLUDED_)
