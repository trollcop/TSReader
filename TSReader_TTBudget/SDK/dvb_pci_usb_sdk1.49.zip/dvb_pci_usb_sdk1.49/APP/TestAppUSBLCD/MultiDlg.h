#if !defined(AFX_MULTIDLG_H__B5557953_9A51_4163_8889_6129F4766648__INCLUDED_)
#define AFX_MULTIDLG_H__B5557953_9A51_4163_8889_6129F4766648__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// MultiDlg.h : Header-Datei
//

/////////////////////////////////////////////////////////////////////////////
// Dialogfeld CMultiDlg 

#include <DVBTSFilter.h>
#define		MAX_MULTI 15


class CTestFilter: public CDVBTSFilter
{
public:
	void OnDataArrival(BYTE* Buff, int len);
};

class CMultiDlg : public CDialog
{
// Konstruktion
public:
	CMultiDlg(CWnd* pParent = NULL);   // Standardkonstruktor
	void OnData(BYTE * Buff, int Len);
	int  ConvT2I(CString & Sour, BYTE * Targ, int l);
	void ConvI2T(BYTE * Sour, CString & Targ, int l);
// Dialogfelddaten
	//{{AFX_DATA(CMultiDlg)
	enum { IDD = IDD_MULTI_DLG };
	CButton	m_BuAddMac3;
	CButton	m_BuAddMac2;
	CButton	m_BuAddMac1;
	CButton	m_BuDelMac3;
	CButton	m_BuDelMac2;
	CButton	m_BuDelMac1;
	CButton	m_ButDelMult;
	CString	m_sPID1;
	CString	m_sPID2;
	CString	m_sPID3;
	CString	m_sPID4;
	CString	m_sPID5;
	CString	m_sData;
	CString	m_sFilt1;
	CString	m_sFilt2;
	CString	m_sFilt3;
	CString	m_sMask1;
	CString	m_sMask2;
	CString	m_sMask3;
	UINT	m_nMasterID;
	UINT	m_MidNum;
	int		m_nError;
	short	m_nFID1;
	short	m_nFID2;
	short	m_nFID3;
	UINT	m_nLen;
	//}}AFX_DATA


// �berschreibungen
	// Vom Klassen-Assistenten generierte virtuelle Funktions�berschreibungen
	//{{AFX_VIRTUAL(CMultiDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV-Unterst�tzung
	//}}AFX_VIRTUAL

// Implementierung
protected:

CTestFilter * pMULT[MAX_MULTI];
CTestFilter * pMAC1[MAX_MULTI];
CTestFilter * pMAC2[MAX_MULTI];
CTestFilter * pMAC3[MAX_MULTI];

int			CurrMult;
int			CurrFilt;
WORD		MasterID[MAX_MULTI];
WORD		PIDs[MAX_MULTI][5];
BYTE		bFID1[MAX_MULTI], bFID2[MAX_MULTI], bFID3[MAX_MULTI];
BYTE		FiltID1[MAX_MULTI], FiltID2[MAX_MULTI], FiltID3[MAX_MULTI];
BYTE		Filt1[MAX_MULTI][16], Mask1[MAX_MULTI][16], Filt2[MAX_MULTI][16];
BYTE		Mask2[MAX_MULTI][16], Filt3[MAX_MULTI][16], Mask3[MAX_MULTI][16];
short		L1[MAX_MULTI], L2[MAX_MULTI], L3[MAX_MULTI];
bool		IsMac1[MAX_MULTI], IsMac2[MAX_MULTI], IsMac3[MAX_MULTI];


	// Generierte Nachrichtenzuordnungsfunktionen
	//{{AFX_MSG(CMultiDlg)
	afx_msg void OnMultiSet();
	afx_msg void OnMultiDel();
	afx_msg void OnAddMac1();
	afx_msg void OnGetlen();
	afx_msg void OnAddMac2();
	afx_msg void OnAddMac3();
	afx_msg void OnDelMac1();
	afx_msg void OnDelMac2();
	afx_msg void OnDelMac3();
	afx_msg void OnResetlen();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ f�gt unmittelbar vor der vorhergehenden Zeile zus�tzliche Deklarationen ein.


#endif // AFX_MULTIDLG_H__B5557953_9A51_4163_8889_6129F4766648__INCLUDED_
