#if !defined(AFX_TTDVBCTRL_H__40DC5969_FD06_4780_8D4C_33525C6974CC__INCLUDED_)
#define AFX_TTDVBCTRL_H__40DC5969_FD06_4780_8D4C_33525C6974CC__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// Mit Microsoft Visual C++ automatisch erstellte IDispatch-Kapselungsklasse(n). 

// HINWEIS: Die Inhalte dieser Datei nicht �ndern. Wenn Microsoft Visual C++
// diese Klasse erneuert, werden Ihre �nderungen �berschrieben.

/////////////////////////////////////////////////////////////////////////////
// Wrapper-Klasse CTTDvbCtrl 

class CTTDvbCtrl : public CWnd
{
protected:
	DECLARE_DYNCREATE(CTTDvbCtrl)
public:
	CLSID const& GetClsid()
	{
		static CLSID const clsid
			= { 0x6ea1b9c1, 0xf41e, 0x4f0b, { 0xaa, 0x5, 0xc5, 0x4, 0xbd, 0x12, 0xbe, 0xb9 } };
		return clsid;
	}
	virtual BOOL Create(LPCTSTR lpszClassName,
		LPCTSTR lpszWindowName, DWORD dwStyle,
		const RECT& rect,
		CWnd* pParentWnd, UINT nID,
		CCreateContext* pContext = NULL)
	{ return CreateControl(GetClsid(), lpszWindowName, dwStyle, rect, pParentWnd, nID); }

    BOOL Create(LPCTSTR lpszWindowName, DWORD dwStyle,
		const RECT& rect, CWnd* pParentWnd, UINT nID,
		CFile* pPersist = NULL, BOOL bStorage = FALSE,
		BSTR bstrLicKey = NULL)
	{ return CreateControl(GetClsid(), lpszWindowName, dwStyle, rect, pParentWnd, nID,
		pPersist, bStorage, bstrLicKey); }

// Attribute
public:

// Operationen
public:
	CString GetBaseIP();
	void SetBaseIP(LPCTSTR lpszNewValue);
	short GetAudioPort();
	void SetAudioPort(short nNewValue);
	short GetVideoPort();
	void SetVideoPort(short nNewValue);
	void start();
	void stop();
	long GetFullScreenMode();
	void SetFullScreenMode(long nNewValue);
	CString GetLastErrorText();
	short GetAudioOffset();
	void SetAudioOffset(short nNewValue);
	short GetVideoOffset();
	void SetVideoOffset(short nNewValue);
	void open(LPCTSTR sIP, short AudioPort, short VideoPort);
	void close();
	void putAudioData(unsigned long dat, long len);
	void putVideoData(unsigned long dat, long len);
	void registerCallback(unsigned long ptr);
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ f�gt unmittelbar vor der vorhergehenden Zeile zus�tzliche Deklarationen ein.

#endif // AFX_TTDVBCTRL_H__40DC5969_FD06_4780_8D4C_33525C6974CC__INCLUDED_
