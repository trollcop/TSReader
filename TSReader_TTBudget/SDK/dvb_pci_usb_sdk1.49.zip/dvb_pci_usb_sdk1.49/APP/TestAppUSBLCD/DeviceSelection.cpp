//  TT  -  TechnoTrend  -  TT  -  TechnoTrend  -  TT  -  TechnoTrend  -  TT  
//
//
//  (C) TechnoTrend AG 1999-2001
//
//  All rights are reserved. Reproduction in whole or in part is prohibited 
//  without the written consent of the copyright owner. TechnoTrend 
//  reserves the right to make changes without notice at any time.  
//
//
//  TT  -  TechnoTrend  -  TT  -  TechnoTrend  -  TT  -  TechnoTrend  -  TT  
//
///////////////////////////////////////////////////////////////////////////
//
//  Filename:     DeviceSelection.cpp
//
//  Project(s):   TestAppDvb
//
//  Author:       GRi
//
//  Purpose:      DeviceSelection.cpp
//   
//  Environment:  Win32
//
//  Dev. Tool(s): MSVC 6.0
//
//  Note(s):      
// 
///////////////////////////////////////////////////////////////////////////
// 
//  File History
//
//   $Workfile: DeviceSelection.cpp $
//   $Revision: 1 $  
//    $Modtime: 29.05.01 9:18 $
//
//   $Log: /DVB-PC/APP/TestAppUsbLcd/DeviceSelection.cpp $
//     >>   
//     >>   1     10.07.01 14:48 Guido
//     >>   
//     >>   1     6.06.01 10:55 Guido
//     >>   
//     >>   2     16.05.01 15:11 Guido
//
///////////////////////////////////////////////////////////////////////////

// DeviceSelection.cpp : implementation file
//

#include "stdafx.h"
#include "dvbmpe.h"
#include "DeviceSelection.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDeviceSelection dialog


CDeviceSelection::CDeviceSelection(CWnd* pParent /*=NULL*/)
	: CDialog(CDeviceSelection::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDeviceSelection)
	//}}AFX_DATA_INIT
}


void CDeviceSelection::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDeviceSelection)
	DDX_Control(pDX, IDC_COMBO1, m_ctrlDevices);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDeviceSelection, CDialog)
	//{{AFX_MSG_MAP(CDeviceSelection)
	ON_WM_DESTROY()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDeviceSelection message handlers

BOOL CDeviceSelection::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	int nIndex;

	for(int i=0; i<m_strArr.GetSize(); i++)
	{
		nIndex = m_ctrlDevices.AddString(m_strArr.GetAt(i));
		m_ctrlDevices.SetItemData(nIndex, i);
	}
	
	m_ctrlDevices.SetCurSel(0);

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CDeviceSelection::OnDestroy() 
{
	CDialog::OnDestroy();
	
	int nIndex;

	nIndex = m_ctrlDevices.GetCurSel();

	if(nIndex != CB_ERR)
		m_dwItemData = m_ctrlDevices.GetItemData(nIndex);
	else
		m_dwItemData = 0;
}
