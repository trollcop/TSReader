//  TT  -  TechnoTrend  -  TT  -  TechnoTrend  -  TT  -  TechnoTrend  -  TT  
//
//
//  (C) TechnoTrend AG 1999-2001
//
//  All rights are reserved. Reproduction in whole or in part is prohibited 
//  without the written consent of the copyright owner. TechnoTrend 
//  reserves the right to make changes without notice at any time.  
//
//
//  TT  -  TechnoTrend  -  TT  -  TechnoTrend  -  TT  -  TechnoTrend  -  TT  
//
///////////////////////////////////////////////////////////////////////////
//
//  Filename:     DDVidDlg.cpp
//
//  Project(s):   TestAppDvb
//
//  Author:       GRi
//
//  Purpose:      DDVidDlg.cpp
//   
//  Environment:  Win32
//
//  Dev. Tool(s): MSVC 6.0
//
//  Note(s):      
// 
///////////////////////////////////////////////////////////////////////////
// 
//  File History
//
//   $Workfile: DDVidDlg.cpp $
//   $Revision: 6 $  
//    $Modtime: 21.02.03 17:00 $
//
//   $Log: /DVB-PC/APP/TestAppUsbLcd/DDVidDlg.cpp $
//     >>   
//     >>   6     21.02.03 17:01 Guido
//     >>   
//     >>   5     27.03.02 15:54 Guido
//     >>   
//     >>   4     26.03.02 17:30 Guido
//     >>   
//     >>   3     25.03.02 18:13 Guido
//     >>   
//     >>   1     25.01.02 9:02 J�rg
//     >>   
//     >>   2     3.08.01 15:51 Guido
//     >>   
//     >>   1     10.07.01 14:48 Guido
//     >>   
//     >>   2     14.06.01 17:52 Guido
//     >>   
//     >>   1     6.06.01 10:55 Guido
//     >>   
//     >>   8     16.05.01 15:11 Guido
//
///////////////////////////////////////////////////////////////////////////


// DDVidDlg.cpp: Implementierungsdatei
//

#include "stdafx.h"
#include "dvbmpe.h"
#include "DDVidDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

extern CString DVBMPE_REGISTRY_START_STRING;

/////////////////////////////////////////////////////////////////////////////
// Dialogfeld CDDVidDlg 


CDDVidDlg::CDDVidDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CDDVidDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDDVidDlg)
	m_bCheckChild = TRUE;
	m_strAudioPID = _T("167");
	m_strVideoPID = _T("166");
	//}}AFX_DATA_INIT

	m_hVidWnd = NULL;
//	m_MonitorMode = CDVBAVControl::MONITOR_4_3;
}


void CDDVidDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDDVidDlg)
	DDX_Check(pDX, IDC_CHECK_CHILD, m_bCheckChild);
	DDX_Text(pDX, IDC_EDIT_APID, m_strAudioPID);
	DDX_Text(pDX, IDC_EDIT_VPID, m_strVideoPID);
	DDX_Control(pDX, IDC_TTDVBCTRL1, m_Video);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDDVidDlg, CDialog)
	//{{AFX_MSG_MAP(CDDVidDlg)
	ON_BN_CLICKED(IDC_DDVID, OnDDVid)
	ON_WM_DESTROY()
	ON_BN_CLICKED(IDC_CHECK_CHILD, OnCheckChild)
	ON_WM_SHOWWINDOW()
	ON_WM_VSCROLL()
	ON_WM_PAINT()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// Behandlungsroutinen f�r Nachrichten CDDVidDlg 

BOOL CDDVidDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Zus�tzliche Initialisierung hier einf�gen

	m_AudioFilter.m_pDDVidDlg = this;
	m_VideoFilter.m_pDDVidDlg = this;

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX-Eigenschaftenseiten sollten FALSE zur�ckgeben
}

void CDDVidDlg::OnDestroy() 
{
	CDialog::OnDestroy();
	
	// TODO: Code f�r die Behandlungsroutine f�r Nachrichten hier einf�gen
	if(m_hVidWnd != NULL)
	{
		m_AudioFilter.ResetFilter();
		m_VideoFilter.ResetFilter();

		m_Video.stop();
		m_Video.close();
		
		m_hVidWnd = NULL;
	}
	
}

void CDDVidDlg::OnPaint() 
{
	CPaintDC dc(this); // device context for painting
	
	// TODO: Code f�r die Behandlungsroutine f�r Nachrichten hier einf�gen
	// geht nicht so ???
	if(::IsWindow(m_Video.m_hWnd))
	{
		::InvalidateRect(m_Video.m_hWnd, NULL, TRUE);
		::UpdateWindow  (m_Video.m_hWnd);
	
	}
	//damit XP nicht grau bleibt
	
	// Kein Aufruf von CDialog::OnPaint() f�r Zeichnungsnachrichten
}

void CDDVidDlg::OnOK() 
{

}

void CDDVidDlg::OnCancel() 
{
//	m_VideoDisplay.Close();
//	m_hVidWnd = NULL;
}

void CDDVidDlg::OnDDVid() 
{
	if(m_hVidWnd != NULL)
	{
		m_AudioFilter.ResetFilter();
		m_VideoFilter.ResetFilter();

		m_Video.stop();
		m_Video.close();
		
		m_hVidWnd = NULL;

//
//if(m_File.m_hFile != CFile::hFileNull)
//	m_File.Close();
//
	}
	else
	{
//
//if(m_File.m_hFile != CFile::hFileNull)
//	m_File.Close();
//m_File.Open("E:\\pes_AV.mpg", CFile::modeCreate | CFile::modeWrite);
//m_File.SeekToBegin();
//		
		BeginWaitCursor();

		UpdateData(TRUE);

		m_Video.SetFullScreenMode(FALSE);


		WORD wAudPid, wVidPid;
	
		wAudPid = (WORD)strtoul(m_strAudioPID, NULL, 0);
		wVidPid = (WORD)strtoul(m_strVideoPID, NULL, 0);
		
		if(m_VideoFilter.SetFilter(CDVBTSFilter::PES_FILTER, wVidPid, NULL, NULL, 0) != DVB_ERR_NONE)
			MessageBox("Could not set Filter!");
		if(m_AudioFilter.SetFilter(CDVBTSFilter::PES_FILTER, wAudPid, NULL, NULL, 0) != DVB_ERR_NONE)
			MessageBox("Could not set Filter!");


		Sleep(1000); // first Set the Audio and Video Filter, then Start the Video !!!


		m_Video.open("", 1, 1);
		m_Video.start();

		m_hVidWnd = m_Video.m_hWnd;

		RECT Rect;
		long lwide, lhigh;
		CWnd* pWnd = GetDlgItem(IDC_STATIC_VID_FRAME);
		pWnd->GetClientRect(&Rect);
		lwide = Rect.right - Rect.left - 15;
		lhigh = Rect.bottom - Rect.top - 20;

		if(m_bCheckChild) // im Dialog eingebettet
		{
			m_Video.SetParent(this);
			m_Video.ModifyStyle(WS_OVERLAPPEDWINDOW, 0, 0);
			m_Video.MoveWindow(Rect.left+15, Rect.top+20, lwide, lhigh, TRUE);
		}
		else
		{
			m_Video.SetParent(NULL);
			m_Video.ModifyStyle(0, WS_OVERLAPPEDWINDOW, 0);
			m_Video.MoveWindow(10, 10, 200, 150, TRUE);

		}

		//pWnd->ShowWindow(SW_HIDE);
/*		
		WORD wAudPid, wVidPid;
	
		wAudPid = (WORD)strtoul(m_strAudioPID, NULL, 0);
		wVidPid = (WORD)strtoul(m_strVideoPID, NULL, 0);
		
		if(m_VideoFilter.SetFilter(CDVBTSFilter::PES_FILTER, wVidPid, NULL, NULL, 0) != DVB_ERR_NONE)
			MessageBox("Could not set Filter!");
		if(m_AudioFilter.SetFilter(CDVBTSFilter::PES_FILTER, wAudPid, NULL, NULL, 0) != DVB_ERR_NONE)
			MessageBox("Could not set Filter!");
*/
		SettingsSaveToRegistry();

		EndWaitCursor();

		UpdateData(FALSE);
	}
}

void CDDVidDlg::OnCheckChild() 
{
	UpdateData(TRUE);

	if(m_hVidWnd != NULL)
	{
		m_AudioFilter.ResetFilter();
		m_VideoFilter.ResetFilter();

		m_Video.stop();
		m_Video.close();
		
		m_hVidWnd = NULL;

		OnDDVid();
	}
}

void CDDVidDlg::SettingsSaveToRegistry()
{
	CString s, to;

	to = DVBMPE_REGISTRY_START_STRING;
	to += m_strActProfile + "\\Settings";
	
	m_myReg.SaveToRegistry(to, "AudioPID", m_strAudioPID);
	m_myReg.SaveToRegistry(to, "VideoPID", m_strVideoPID);
}

void CDDVidDlg::SettingsReadFromRegistry()
{
	CString from;

	from = DVBMPE_REGISTRY_START_STRING;
	from += m_strActProfile + "\\Settings";

	if(! m_myReg.ReadFromRegistry(from, "AudioPID", m_strAudioPID))
		m_strAudioPID = "167";
	
	if(! m_myReg.ReadFromRegistry(from, "VideoPID", m_strVideoPID))
		m_strVideoPID = "166";
}

void CDDVidDlg::ProfileEvent(const CString& newProfile, const CString& cpyProfile)
{
//	UpdateData(TRUE);
//	if(m_strActProfile.GetLength() > 0)
//		SettingsSaveToRegistry();

	if(cpyProfile == "")
	{
		m_strActProfile = newProfile;
		SettingsReadFromRegistry();

		UpdateData(FALSE); // Dialog aktualisieren
		
		//SettingsSaveToRegistry();
	}
	else
	{
		m_strActProfile = cpyProfile;
		SettingsReadFromRegistry();

		UpdateData(FALSE); // Dialog aktualisieren

		m_strActProfile = newProfile;
		SettingsSaveToRegistry();
	}
}

//-----------------------------------------------------------------------------------

CMyAudio::CMyAudio()
{
	m_pDDVidDlg = NULL;
}

CMyAudio::~CMyAudio()
{
}
	
void CMyAudio::OnDataArrival(BYTE* Buff, int len)
{
	TRACE("Audio OnDataArrival\n");
	/*for(int i=0; ((i<len) && (i<8)); i++)
	{
		TRACE("%02x ", Buff[i]);
	}
	TRACE("\n");*/
	
	if(NULL != m_pDDVidDlg)
		m_pDDVidDlg->m_Video.putAudioData((unsigned long)Buff,len);
//
//if(m_pDDVidDlg->m_File.m_hFile != CFile::hFileNull)
//	m_pDDVidDlg->m_File.Write(Buff, len);
//
}

CMyVideo::CMyVideo()
{
	m_pDDVidDlg = NULL;

//	m_File.Open("C:\\videopid.bin", CFile::modeCreate | CFile::modeWrite);
//	m_File.SeekToBegin();
}

CMyVideo::~CMyVideo()
{
//	m_File.Close();
}
	
void CMyVideo::OnDataArrival(BYTE* Buff, int len)
{
	TRACE("Video OnDataArrival\n");
	/*for(int i=0; ((i<len) && (i<8)); i++)
	{
		TRACE("%02x ", Buff[i]);
	}
	TRACE("\n");*/
	
	if(NULL != m_pDDVidDlg)
		m_pDDVidDlg->m_Video.putVideoData((unsigned long)Buff,len);
//	
//if(m_pDDVidDlg->m_File.m_hFile != CFile::hFileNull)
//	m_pDDVidDlg->m_File.Write(Buff, len);
//

//	m_File.Write(Buff, len);
}

