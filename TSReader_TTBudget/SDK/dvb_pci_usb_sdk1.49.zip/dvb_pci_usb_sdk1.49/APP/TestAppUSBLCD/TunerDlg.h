//  TT  -  TechnoTrend  -  TT  -  TechnoTrend  -  TT  -  TechnoTrend  -  TT  
//
//
//  (C) TechnoTrend AG 1999-2001
//
//  All rights are reserved. Reproduction in whole or in part is prohibited 
//  without the written consent of the copyright owner. TechnoTrend 
//  reserves the right to make changes without notice at any time.  
//
//
//  TT  -  TechnoTrend  -  TT  -  TechnoTrend  -  TT  -  TechnoTrend  -  TT  
//
///////////////////////////////////////////////////////////////////////////
//
//  Filename:     TunerDlg.h
//
//  Project(s):   TestAppDvb
//
//  Author:       GRi
//
//  Purpose:      Tuner Settings Dialog
//   
//  Environment:  Win32
//
//  Dev. Tool(s): MSVC 6.0
//
//  Note(s):      
// 
///////////////////////////////////////////////////////////////////////////
// 
//  File History
//
//   $Workfile: TunerDlg.h $
//   $Revision: 3 $  
//    $Modtime: 27.01.03 15:47 $
//
//   $Log: /DVB-PC/APP/TestAppUsbLcd/TunerDlg.h $
//     >>   
//     >>   3     27.01.03 16:59 Guido
//     >>   
//     >>   2     22.11.01 17:08 Guido
//     >>   
//     >>   1     10.07.01 14:48 Guido
//     >>   
//     >>   1     6.06.01 10:55 Guido
//     >>   
//     >>   6     16.05.01 15:11 Guido
//
///////////////////////////////////////////////////////////////////////////

#if !defined(AFX_TUNERDLG_H__66849560_8178_11D3_A2D9_00D05CFFFF04__INCLUDED_)
#define AFX_TUNERDLG_H__66849560_8178_11D3_A2D9_00D05CFFFF04__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// TunerDlg.h : Header-Datei
//
#include <DVBBoardControl.h>
#include <DVBFrontend.h>
#include "MyRegistry.h"
#include "mmsystem.h"
#include "GradientProgressCtrl.h"
#include <math.h>
#include "LnbDlg.h"

#define DISEQC_HIGH_NIBLE	0xF0
#define DISEQC_LOW_BAND		0x00
#define DISEQC_HIGH_BAND	0x01
#define DISEQC_VERTICAL		0x00
#define DISEQC_HORIZONTAL	0x02
#define DISEQC_POSITION_A	0x00
#define DISEQC_POSITION_B	0x04
#define DISEQC_OPTION_A		0x00
#define DISEQC_OPTION_B		0x08

/////////////////////////////////////////////////////////////////////////////
// Dialogfeld CTunerDlg 

class CTunerDlg : public CDialog
{
// Konstruktion
public:
	//DWORD GetFEStatus(CString & sAI);
	//CTunerDlg(CWnd* pParent = NULL);   // Standardkonstruktor
	CTunerDlg(CLnbDlg* pLnbDlg, CDVBFrontend& fe, CWnd* pParent = NULL);
	
	BOOL TimerEvent(void);
	void ProfileEvent(const CString& newProfile, const CString& cpyProfile);

// Dialogfelddaten
	//{{AFX_DATA(CTunerDlg)
	enum { IDD = IDD_TUNER_DLG };
	CComboBox	m_ctrlSymbolRate;
	CSpinButtonCtrl	m_ctrlFreqSpin;
	CButton	m_ctrlLvlSound;
	CGradientProgressCtrl	m_ctrlNestAGC;
	CGradientProgressCtrl	m_ctrlBitErr;
	CGradientProgressCtrl	m_ctrlSyncStat;
	CString	m_strFrequenz;
	int		m_iQAM;
	int		m_iPolarisation;
	CString	m_strUpperFreq;
	CString	m_strLowerFreq;
	BOOL	m_bSpecInv;
	int		m_iBandWidth;
	//}}AFX_DATA


// �berschreibungen
	// Vom Klassen-Assistenten generierte virtuelle Funktions�berschreibungen
	//{{AFX_VIRTUAL(CTunerDlg)
	public:
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV-Unterst�tzung
	//}}AFX_VIRTUAL

// Implementierung
protected:

	// Generierte Nachrichtenzuordnungsfunktionen
	//{{AFX_MSG(CTunerDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnDestroy();
	virtual void OnOK();
	virtual void OnCancel();
	afx_msg void OnDeltaposFreqspin(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnButtonApply();
	afx_msg void OnButtonScan();
	afx_msg void OnButtonStartScan();
	afx_msg void OnButtonStopScan();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

private:
	void SetValuesEvent();

	BOOL PlayResource(int nID, int rpt, BOOL sync = TRUE);
	BOOL PlayPercentEnglish(BYTE Percent);
	void DisableFrontendSettings(CDVBFrontend::FRONTEND_TYPE& FE_Type);
	void SettingsReadFromRegistry();
	void SettingsSaveToRegistry();

	static UDACCEL	udaccel[3];
	CDVBBoardControl m_BoardControl;
	CDVBFrontend& m_Frontend;
	CMyRegistry m_myReg;
	CString m_strSymbRate;
	CDVBFrontend::FRONTEND_TYPE m_FE_Type;
	CString m_strActProfile;

	CLnbDlg* m_pLnbDlg; // f�r "Slave"-Dialog Steuerung

	int		m_iDiseqc;
	int		m_iSimplePosition;
	int		m_iMultiOption;
	int		m_iMultiPosition;
	DWORD	m_dwLOF1;
	DWORD	m_dwLOF2;
	DWORD	m_dwLOFSW;
	BOOL	m_bLNBPower;
	BOOL	m_bScanning;

	typedef struct tag_str_table_struct
	{	LPSTR strName;
		LPSTR strFreq;
	} STR_TABLE_STRUCT;
	static const STR_TABLE_STRUCT freqlist[];

	//CString GetFreq_Str(const DWORD& dwFreq);
	DWORD GetFreq(const CString& strName);
	CString GetFirstFreq(BOOL dir = TRUE);
	CString GetLastFreq(BOOL dir = TRUE);
	CString GetNextFreq(const CString& strName, BOOL dir = TRUE);
	CString GetPrevFreq(const CString& strName, BOOL dir = TRUE);
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ f�gt unmittelbar vor der vorhergehenden Zeile zus�tzliche Deklarationen ein.

#endif // AFX_TUNERDLG_H__66849560_8178_11D3_A2D9_00D05CFFFF04__INCLUDED_
