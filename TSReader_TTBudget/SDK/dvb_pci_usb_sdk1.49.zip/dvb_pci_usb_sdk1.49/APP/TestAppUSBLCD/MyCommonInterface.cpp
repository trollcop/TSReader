// MyCommonInterface.cpp: Implementierung der Klasse CMyCommonInterface.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "dvbmpe.h"
#include "MyCommonInterface.h"
#include "CIDlg.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

#ifdef _TTDVBLCD

//////////////////////////////////////////////////////////////////////
// Konstruktion/Destruktion
//////////////////////////////////////////////////////////////////////

CMyCommonInterface::CMyCommonInterface()
{
	m_wBufferSize		= 16;		//default values for data reception
	m_wTimeout			= 1000;	//1s timeout
	m_nAnswerLength = 0;
	m_bBlindAnswer = FALSE;
//	m_wLastSID = 0;

	m_nSlotStatus[0]=CI_SLOT_EMPTY;
	m_nSlotStatus[1]=CI_SLOT_EMPTY;
	m_sModuleMenuTitle[0]="";
	m_sModuleMenuTitle[1]="";

	m_pCIDlg = NULL;
}

CMyCommonInterface::~CMyCommonInterface()
{

}

DVB_ERROR CMyCommonInterface::Open(CCIDlg* pCIDlg)
{
	DVB_ERROR err;
	
	m_pCIDlg = pCIDlg;
	
	err = CDVBComnIF::Open();
	
	DisplayModuleStatus();

	CString version,date;
	CDVBComnIF::GetCIVersion(version,date);
	
	m_pCIDlg->SetDlgItemText(IDC_INFOS,"CI library version " + version + "  " + date);

	return err;
}

void CMyCommonInterface::OnSlotStatus(BYTE nSlot, BYTE nStatus, typ_SlotInfo* csInfo)
{
	WORD n;
	
	if(m_pCIDlg == NULL)
		return;

	switch(nStatus)
	{
	case CI_SLOT_EMPTY:
	case CI_SLOT_UNKNOWN_STATE:
			TRACE("empty or unknown module\n");
			m_nSlotStatus[nSlot]=CI_SLOT_EMPTY;
		break;

	case CI_SLOT_MODULE_INSERTED:
			TRACE("module inserted\n");
			m_nSlotStatus[nSlot]=CI_SLOT_MODULE_INSERTED;
		break;

	case CI_SLOT_MODULE_OK:
	case CI_SLOT_CA_OK:
			m_nSlotStatus[nSlot]=CI_SLOT_MODULE_OK;

			for(n=0; n < csInfo->wNoOfCaSystemIDs; n++)
			{
				TRACE("supported CA ID: %04X \n", csInfo->pCaSystemIDs[n]);
			}
			//TRACE("+++ reading PSI... +++\n");
			//ReadPSIFast((WORD)strtoul(m_pCIDlg->m_strPNR, NULL, 0));

			m_sModuleMenuTitle[nSlot].Format("%s", csInfo->pMenuTitleString);
		break;
	case CI_SLOT_DBG_MSG:
			TRACE("Test Struktur empfangen\n");
			//pCiTest=(typ_CITest*)csInfo;
			//TRACE("\n%s %s\n",pCiTest->Slot[0].czMenuTitleString,pCiTest->Slot[1].czMenuTitleString );
		break;

	default:
			TRACE("unknown SlotState\n");
		return;
	}
	DisplayModuleStatus();
}

void CMyCommonInterface::OnCAStatus(BYTE nSlot, BYTE nReplyTag, WORD wStatus)
{
	if(m_pCIDlg == NULL)
		return;
	
	switch(nReplyTag)	
	{
	case CI_PSI_COMPLETE:
				m_pCIDlg->SetDlgItemText(IDC_INFOS,"PSI complete");
				TRACE("### Number of programs : %04d\n", wStatus);
				//SetProgram((WORD)m_pCIDlg->m_PNR);
		break;

	case CI_MODULE_READY:
				TRACE("CI_MODULE_READY in OnCAStatus not supported\n");
		break;
	case CI_SWITCH_PRG_REPLY:
			switch(wStatus)
			{
			case	ERR_INVALID_DATA:
				m_pCIDlg->SetDlgItemText(IDC_INFOS,"SetProgram failed");
				TRACE("ERROR::SetProgram failed !!! (invalid PNR)\n");
				break;
			case	ERR_NO_CA_RESOURCE:
				m_pCIDlg->SetDlgItemText(IDC_INFOS,"SetProgram failed");
				TRACE("ERROR::SetProgram failed !!! (no CA resource available)\n");
				break;
			case	ERR_NONE:
				m_pCIDlg->SetDlgItemText(IDC_INFOS,"SetProgram OK");
				TRACE("   SetProgram OK\n");
				break;
			}
			//((CListBox*)(m_pCIDlg->GetDlgItem(IDC_CI_SCREEN)))->ResetContent();
			//((CListBox*)(m_pCIDlg->GetDlgItem(IDC_PSI_SERVICES)))->ResetContent();
			//TRACE("request psi infos of service %d\n",((CListBox*)m_pCIDlg->GetDlgItem(IDC_PSI_SERVICES))->GetCurSel());
			//m_pCIDlg->m_SrvDecoder.GetPrgInfos( ((CListBox*)m_pCIDlg->GetDlgItem(IDC_PSI_SERVICES))->GetCurSel());
		break;
	}
}

void CMyCommonInterface::OnDisplayString(BYTE nSlot,char* pString,WORD wLength)
{
	if(m_pCIDlg == NULL)
		return;

	m_pCIDlg->SetDlgItemText(IDC_INFOS,"OSD aktiv");
	DisplayString(pString, wLength);
}

void CMyCommonInterface::OnDisplayMenu(BYTE nSlot, WORD wItems, char* pStringArray, WORD wLength)
{
	if(m_pCIDlg == NULL)
		return;

	m_pCIDlg->SetDlgItemText(IDC_INFOS,"OSD aktiv");
	DisplayMenuOrList(pStringArray, wLength, TRUE);
}

void CMyCommonInterface::OnDisplayList(BYTE nSlot, WORD wItems, char* pStringArray, WORD wLength)
{
	if(m_pCIDlg == NULL)
		return;

	m_pCIDlg->SetDlgItemText(IDC_INFOS,"OSD aktiv");
	DisplayMenuOrList(pStringArray, wLength, FALSE);
}

void CMyCommonInterface::OnSwitchOsdOff(BYTE nSlot)
{
	if(m_pCIDlg == NULL)
		return;

	((CListBox*)(m_pCIDlg->GetDlgItem(IDC_CI_SCREEN)))->ResetContent();
	m_pCIDlg->SetDlgItemText(IDC_INFOS,"OSD inaktiv");
}

void CMyCommonInterface::DisplayString(char* pString, WORD wLength)
{
	if(m_pCIDlg == NULL)
		return;

	CListBox* pListBox;
	char* ptr = pString; //+ 3;
	int offset = 0;
	CString s, s2;

	pListBox=(CListBox*)(m_pCIDlg->GetDlgItem(IDC_CI_SCREEN));
	pListBox->ResetContent();

	s.Format("%s",ptr + offset);
	offset += s.GetLength() + 1;
	s2 = s;
	s=s.Right(s.GetLength() - ConvertCharBuf(s2, s2.GetLength()));
	if(s2.GetLength() > 0)
	{
		s2 = s2.Left(s2.GetLength()-1); // ???
		pListBox->InsertString(-1, s2);
		return;
	}
}

int CMyCommonInterface::DisplayMenuOrList(char* pStringArray, WORD wLength, BOOL bMenu)
{
	if(m_pCIDlg == NULL)
		return 0;

	CListBox* pListBox;
	char* ptr = pStringArray; //+ 3;
	int offset = 0, index = 0;
	CString s, s2, t;

	pListBox=(CListBox*)(m_pCIDlg->GetDlgItem(IDC_CI_SCREEN));
	pListBox->ResetContent();

	//while(offset < (wLength - 3))
	while(offset < (wLength))
	{
		s.Format("%s", ptr + offset);
		offset += s.GetLength() + 1;

		do
		{
			s2 = s;
			s = s.Right(s.GetLength() - ConvertCharBuf(s2, s2.GetLength()));
			TRACE("%s\n",s2);
			++index;
			
			switch(index)
			{
			case 1:
				t = bMenu?"[MenuTitle] ":"[ListTitle] " + s2;
				pListBox->InsertString(-1, t);
				break;
			case 2:
				t = "[SubTitle] " + s2;
				pListBox->InsertString(-1, t);
				break;
			case 3:
				t = "[Bottom] " + s2;
				pListBox->InsertString(-1, t);
				break;
			default:
				if(bMenu)
					t.Format("[%u] %s", index-3, s2);
				else
					t = s2;
				pListBox->InsertString(index-2, t);
				break;
			}

		} while(s.GetLength() != 0);
	}
	return index;
}

void CMyCommonInterface::OnInputRequest(BYTE nSlot,BOOL bBlindAnswer,BYTE nExpectedLength,DWORD dwKeyMask)
{
	if(m_pCIDlg == NULL)
		return;

	m_bBlindAnswer=bBlindAnswer;
	m_nAnswerLength=nExpectedLength;
	m_dwKeyMask=dwKeyMask;
	m_nKeyBufferIndex=0;
	//m_pCIDlg->SetDlgItemText(IDC_KEYBOARD,"");
	m_pCIDlg->SetDlgItemText(IDC_INFOS,"Tastatureingabe!");
	m_pCIDlg->m_ActCAM = nSlot;
	m_pCIDlg->MarkActiveCAM();
	TRACE(" Input request for %02X keys\n", nExpectedLength);
}

void CMyCommonInterface::DisplayModuleStatus()
{
	CString	s, status = "";

	if(m_pCIDlg == NULL)
		return;

	for(int ModulNumber=0; ModulNumber<2; ModulNumber++)	
	{
		switch(m_nSlotStatus[ModulNumber])
		{
		case CI_SLOT_EMPTY:
				s.Format("Slot empty", ModulNumber);
			break;

		case CI_SLOT_MODULE_INSERTED:
				s.Format("Module inserted");
			break;

		case CI_SLOT_MODULE_OK:
				s.Format("%s",m_sModuleMenuTitle[ModulNumber]);
			break;
		}
		switch(ModulNumber){
			case 0:
				((CButton*)(m_pCIDlg->GetDlgItem(IDC_SLOT0)))->SetWindowText((LPCTSTR)s);
				break;
			case 1:
				((CButton*)(m_pCIDlg->GetDlgItem(IDC_SLOT1)))->SetWindowText((LPCTSTR)s);
				break;
		}
		status +=s;
	}
}

#endif // _TTDVBLCD

