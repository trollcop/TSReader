//  TT  -  TechnoTrend  -  TT  -  TechnoTrend  -  TT  -  TechnoTrend  -  TT  
//
//
//  (C) TechnoTrend AG 1999-2001
//
//  All rights are reserved. Reproduction in whole or in part is prohibited 
//  without the written consent of the copyright owner. TechnoTrend 
//  reserves the right to make changes without notice at any time.  
//
//
//  TT  -  TechnoTrend  -  TT  -  TechnoTrend  -  TT  -  TechnoTrend  -  TT  
//
///////////////////////////////////////////////////////////////////////////
//
//  Filename:     TeletextDlg.h
//
//  Project(s):   TestAppDvb
//
//  Author:       GRi
//
//  Purpose:      Teletext/Section-Filter Dialog
//   
//  Environment:  Win32
//
//  Dev. Tool(s): MSVC 6.0
//
//  Note(s):      
// 
///////////////////////////////////////////////////////////////////////////
// 
//  File History
//
//   $Workfile: TeletextDlg.h $
//   $Revision: 1 $  
//    $Modtime: 6.06.01 10:46 $
//
//   $Log: /DVB-PC/APP/TestAppUsbLcd/TeletextDlg.h $
//     >>   
//     >>   1     10.07.01 14:48 Guido
//     >>   
//     >>   1     6.06.01 10:55 Guido
//     >>   
//     >>   3     16.05.01 15:11 Guido
//
///////////////////////////////////////////////////////////////////////////

#if !defined(AFX_TELETEXTDLG_H__F43F7360_D6B3_4844_9F53_90B8DBB35721__INCLUDED_)
#define AFX_TELETEXTDLG_H__F43F7360_D6B3_4844_9F53_90B8DBB35721__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// TeletextDlg.h : Header-Datei
//

//#include <DVBBoardControl.h>
#include <DVBTeletext.h>
#include <DVBTSFilter.h>
#include "MyRegistry.h"

/////////////////////////////////////////////////////////////////////////////
class CTeletextDlg;

class CMyTeleText : public CDVBTeletext
{
public:
	CTeletextDlg* m_pTeletextDlg;
private:
	void OnTTXPage(BYTE* TTXPage, int len);
	CString m_strOut;
};

class CMyFilter : public CDVBTSFilter
{
public:
	CTeletextDlg* m_pTeletextDlg;
private:
	void OnDataArrival(BYTE* Buff, int len);
	CString m_strOut;
};

/////////////////////////////////////////////////////////////////////////////
// Dialogfeld CTeletextDlg 

class CTeletextDlg : public CDialog
{
// Konstruktion
public:
	CTeletextDlg(CWnd* pParent = NULL);   // Standardkonstruktor

	void ProfileEvent(const CString& newProfile, const CString& cpyProfile);

// Dialogfelddaten
	//{{AFX_DATA(CTeletextDlg)
	enum { IDD = IDD_TELETEXT_DLG };
	CString	m_strSecPID;
	CString	m_strSecTID;
	CString	m_strFltRawOut;
	CString	m_strTTPage;
	CString	m_strTTPID;
	CString	m_strTTRawOut;
	//}}AFX_DATA


// �berschreibungen
	// Vom Klassen-Assistenten generierte virtuelle Funktions�berschreibungen
	//{{AFX_VIRTUAL(CTeletextDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV-Unterst�tzung
	//}}AFX_VIRTUAL

// Implementierung
protected:

	// Generierte Nachrichtenzuordnungsfunktionen
	//{{AFX_MSG(CTeletextDlg)
	virtual BOOL OnInitDialog();
	virtual void OnOK();
	virtual void OnCancel();
	afx_msg void OnTeletextOn();
	afx_msg void OnTeletextOff();
	afx_msg void OnTeletextAddPage();
	afx_msg void OnTeletextAllPages();
	afx_msg void OnSecFltSet();
	afx_msg void OnSecFltReset();
	afx_msg void OnDestroy();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

private:
	CMyTeleText m_Teletext;
	CMyFilter m_SecFilter;

	void SettingsReadFromRegistry();
	void SettingsSaveToRegistry();
	CString m_strActProfile;
	CMyRegistry m_myReg;

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ f�gt unmittelbar vor der vorhergehenden Zeile zus�tzliche Deklarationen ein.

#endif // AFX_TELETEXTDLG_H__F43F7360_D6B3_4844_9F53_90B8DBB35721__INCLUDED_
