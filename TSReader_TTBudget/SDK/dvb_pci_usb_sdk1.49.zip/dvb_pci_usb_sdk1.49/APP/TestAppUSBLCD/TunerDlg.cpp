//  TT  -  TechnoTrend  -  TT  -  TechnoTrend  -  TT  -  TechnoTrend  -  TT  
//
//
//  (C) TechnoTrend AG 1999-2001
//
//  All rights are reserved. Reproduction in whole or in part is prohibited 
//  without the written consent of the copyright owner. TechnoTrend 
//  reserves the right to make changes without notice at any time.  
//
//
//  TT  -  TechnoTrend  -  TT  -  TechnoTrend  -  TT  -  TechnoTrend  -  TT  
//
///////////////////////////////////////////////////////////////////////////
//
//  Filename:     TunerDlg.cpp
//
//  Project(s):   TestAppDvb
//
//  Author:       GRi
//
//  Purpose:      TunerDlg.cpp
//   
//  Environment:  Win32
//
//  Dev. Tool(s): MSVC 6.0
//
//  Note(s):      
// 
///////////////////////////////////////////////////////////////////////////
// 
//  File History
//
//   $Workfile: TunerDlg.cpp $
//   $Revision: 5 $  
//    $Modtime: 20.02.03 9:05 $
//
//   $Log: /DVB-PC/APP/TestAppUsbLcd/TunerDlg.cpp $
//     >>   
//     >>   5     20.02.03 9:53 Guido
//     >>   
//     >>   4     27.01.03 16:59 Guido
//     >>   
//     >>   3     5.12.02 15:38 Guido
//     >>   
//     >>   2     22.11.01 17:08 Guido
//     >>   
//     >>   1     10.07.01 14:48 Guido
//     >>   
//     >>   1     6.06.01 10:55 Guido
//     >>   
//     >>   9     16.05.01 15:11 Guido
//
///////////////////////////////////////////////////////////////////////////

// TunerDlg.cpp: Implementierungsdatei
//

#include "stdafx.h"
#include "dvbmpe.h"
#include "TunerDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

extern CString DVBMPE_REGISTRY_START_STRING;

/////////////////////////////////////////////////////////////////////////////
// Dialogfeld CTunerDlg 
UDACCEL CTunerDlg::udaccel[] = {{0, 1}, {2, 3}, {5, 9}};

const CTunerDlg::STR_TABLE_STRUCT CTunerDlg::freqlist[] = {     

    {"2",    "50500"}, {"3",    "57500"}, {"4",    "64500"}, {"X",    "71500"}, {"Y",    "78500"},
    {"Z",    "85500"}, {"Z+1",  "92500"}, {"Z+2",  "99500"}, {"S1",  "107500"}, {"S2",  "114500"},
    {"S3",  "121500"}, {"S4",  "128500"}, {"S5",  "135500"}, {"S6",  "142500"}, {"S7",  "149500"},
    {"S8",  "156500"}, {"S9",  "163500"}, {"S10", "170500"}, {"5",   "177500"}, {"6",   "184500"},
    {"7",   "191500"}, {"8",   "198500"}, {"9",   "205500"}, {"10",  "212500"}, {"11",  "219500"},
    {"12",  "226500"}, {"S11", "233500"}, {"S12", "240500"}, {"S13", "247500"}, {"S14", "254500"},
    {"S15", "261500"}, {"S16", "268500"}, {"S17", "275500"}, {"S18", "282500"}, {"S19", "289500"},
    {"S20", "296500"}, {"S21", "306000"}, {"S22", "314000"}, {"S23", "322000"}, {"S24", "330000"},
    {"S25", "338000"}, {"S26", "346000"}, {"S27", "354000"}, {"S28", "362000"}, {"S29", "370000"},
    {"S30", "378000"}, {"S31", "386000"}, {"S32", "394000"}, {"S33", "402000"}, {"S34", "410000"},
    {"S35", "418000"}, {"S36", "426000"}, {"S37", "434000"}, {"S38", "442000"}, {"S39", "450000"},
    {"S40", "458000"}, {"S41", "466000"}, {"21",  "474000"}, {"22",	 "482000"}, {"23",  "490000"},
    {"24",  "498000"}, {"25",  "506000"}, {"26",  "514000"}, {"27",  "522000"}, {"28",  "530000"},
    {"29",  "538000"}, {"30",  "546000"}, {"31",  "554000"}, {"32",  "562000"}, {"33",  "570000"},
    {"34",  "578000"}, {"35",  "586000"}, {"36",  "594000"}, {"37",  "602000"}, {"38",  "610000"},
    {"39",  "618000"}, {"40",  "626000"}, {"41",  "634000"}, {"42",  "642000"}, {"43",  "650000"},
    {"44",  "658000"}, {"45",  "666000"}, {"46",  "674000"}, {"47",  "682000"}, {"48",  "690000"},
    {"49",  "698000"}, {"50",  "706000"}, {"51",  "714000"}, {"52",  "722000"}, {"53",  "730000"},
    {"54",  "738000"}, {"55",  "746000"}, {"56",  "754000"}, {"57",  "762000"}, {"58",  "770000"},
    {"59",  "778000"}, {"60",  "786000"}, {"61",  "794000"}, {"62",  "802000"}, {"63",  "810000"},
    {"64",  "818000"}, {"65",  "826000"}, {"66",  "834000"}, {"67",  "842000"}, {"68",  "850000"},
    {"69",  "858000"}, {NULL,  NULL}
};

DWORD CTunerDlg::GetFreq(const CString& val)
{
	int search = 0;
	CString s = val;

	s.MakeUpper();
	if(s.Left(1) == "E")
		s = s.Mid(1);

	while (freqlist[search].strName) 
	{
		if (s == freqlist[search].strName)
			return strtoul(freqlist[search].strFreq, NULL, 10);
		search++;     
	}
	return 0;
}

CString CTunerDlg::GetFirstFreq(BOOL dir)
{
	 // etwas optimiert
	if(dir)
		return "2";
	else
		return "50500";


}

CString CTunerDlg::GetLastFreq(BOOL dir)
{
	 // etwas optimiert
	if(dir)
		return "69";
	else
		return "858000";
}

CString CTunerDlg::GetNextFreq(const CString& val, BOOL dir)
{
	int search = 0;

	if(dir)
	{
		CString s = val;
		s.MakeUpper();
		if(s.Left(1) == "E")
			s = s.Mid(1);

		while (freqlist[search].strName) 
		{         
			if(s == freqlist[search].strName)
				if(freqlist[search+1].strName)
					return freqlist[search+1].strName;
				else
					return GetFirstFreq(dir);
			search++;     
		}
	}
	else
	{
		DWORD dw = strtoul(val, NULL, 10);
		while (freqlist[search].strFreq) 
		{         
			if (dw < strtoul(freqlist[search].strFreq, NULL, 10))
				return freqlist[search].strFreq;
			search++;     
		}
	}
	return GetFirstFreq(dir);
}

CString CTunerDlg::GetPrevFreq(const CString& val, BOOL dir)
{
	int search = 0;

	if(dir)
	{
		CString s = val;
		s.MakeUpper();
		if(s.Left(1) == "E")
			s = s.Mid(1);

		while (freqlist[search].strName) 
		{         
			if (s == freqlist[search].strName)
				if (search>0)
					return freqlist[search-1].strName;
				else
					return GetLastFreq(dir);
			search++;     
		}
	}
	else
	{
		DWORD dw = strtoul(val, NULL, 10);
		while (freqlist[search].strFreq) 
		{         
			if (dw <= strtoul(freqlist[search].strFreq, NULL, 10))
				if (search>0)
					return freqlist[search-1].strFreq;
				else
					return GetLastFreq(dir);
			search++;     
		}
	}
	return GetLastFreq(dir);
}

CTunerDlg::CTunerDlg(CLnbDlg* pLnbDlg, CDVBFrontend& fe, CWnd* pParent /*=NULL*/)
	: CDialog(CTunerDlg::IDD, pParent), m_Frontend(fe)
{
	//{{AFX_DATA_INIT(CTunerDlg)
	m_strFrequenz = _T("12051000");
	m_iQAM = 2;
	m_iPolarisation = 1;
	m_strUpperFreq = _T("12100000");
	m_strLowerFreq = _T("12060000");
	m_bSpecInv = FALSE;
	m_iBandWidth = 1;
	//}}AFX_DATA_INIT
	
	m_bScanning = FALSE;
	
	m_iDiseqc = 0;
	m_iSimplePosition = 0;
	m_iMultiOption = 0;
	m_iMultiPosition = 0;
	m_dwLOF1 = 9750000;
	m_dwLOF2 = 10600000;
	m_dwLOFSW = 11700000;
	m_bLNBPower = TRUE;

	m_pLnbDlg = pLnbDlg;
	
	m_FE_Type = m_Frontend.GetType();
}

void CTunerDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CTunerDlg)
	DDX_Control(pDX, IDC_SYMBOLRATE, m_ctrlSymbolRate);
	DDX_Control(pDX, IDC_FREQSPIN, m_ctrlFreqSpin);
	DDX_Control(pDX, IDC_LVL_SOUND, m_ctrlLvlSound);
	DDX_Control(pDX, IDC_NEST, m_ctrlNestAGC);
	DDX_Control(pDX, IDC_BERR, m_ctrlBitErr);
	DDX_Control(pDX, IDC_SYNCSTAT, m_ctrlSyncStat);
	DDX_Text(pDX, IDC_FREQUENZ, m_strFrequenz);
	DDX_CBIndex(pDX, IDC_QAM, m_iQAM);
	DDX_Radio(pDX, IDC_HORIZONTAL, m_iPolarisation);
	DDX_Text(pDX, IDC_EDIT_UPPER_FREQ, m_strUpperFreq);
	DDX_Text(pDX, IDC_EDIT_LOWER_FREQ, m_strLowerFreq);
	DDX_Check(pDX, IDC_SPEC_INV, m_bSpecInv);
	DDX_Radio(pDX, IDC_BW_7, m_iBandWidth);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CTunerDlg, CDialog)
	//{{AFX_MSG_MAP(CTunerDlg)
	ON_WM_DESTROY()
	ON_NOTIFY(UDN_DELTAPOS, IDC_FREQSPIN, OnDeltaposFreqspin)
	ON_BN_CLICKED(IDC_BUTTON_APPLY, OnButtonApply)
	ON_BN_CLICKED(IDC_BUTTON_SCAN, OnButtonScan)
	ON_BN_CLICKED(IDC_BUTTON_START_SCAN, OnButtonStartScan)
	ON_BN_CLICKED(IDC_BUTTON_STOP_SCAN, OnButtonStopScan)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

//#define DVBMPE_NEW_SAT_API
  
/////////////////////////////////////////////////////////////////////////////
// Behandlungsroutinen f�r Nachrichten CTunerDlg 
 
BOOL CTunerDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();

	// TODO: Zus�tzliche Initialisierung hier einf�gen
//	DVB_ERROR error;
	
//	error = m_Frontend.Init();
//	if (error != DVB_ERR_NONE)
//		MessageBox("Frontend.Init not successful.", "Error");

	// Frontendeinstellungsm�glichkeiten dem Frontend-Typ anpassen
	DisableFrontendSettings(m_FE_Type);

	m_ctrlFreqSpin.SetAccel(3, udaccel);
	m_ctrlFreqSpin.SetRange32(0, 100);
	m_ctrlFreqSpin.SetPos(0);

	m_strSymbRate = "27500000";
	m_ctrlSymbolRate.SelectString(-1, m_strSymbRate);

	m_ctrlSyncStat.SetRange(0,100); m_ctrlSyncStat.SetStartColor(0x0000ff00);
	m_ctrlSyncStat.SetEndColor(0x0000ff00); m_ctrlSyncStat.SetInterimColor(0x0000ff00);
	m_ctrlSyncStat.ShowPercent(FALSE);

	m_ctrlBitErr.SetRange(0,100); m_ctrlBitErr.SetStartColor(0x000000ff);
	m_ctrlBitErr.SetEndColor(0x0000ff00); m_ctrlBitErr.SetInterimColor(0x0000ffff);
	m_ctrlBitErr.SetTextColor(0); m_ctrlBitErr.ShowPercent(TRUE);

	m_ctrlNestAGC.SetRange(0,100); m_ctrlNestAGC.SetStartColor(0x000000ff); // 0x00bbggrr
	m_ctrlNestAGC.SetEndColor(0x0000ff00); m_ctrlNestAGC.SetInterimColor(0x0000ffff);
	m_ctrlNestAGC.SetTextColor(0); m_ctrlNestAGC.ShowPercent(TRUE);

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX-Eigenschaftenseiten sollten FALSE zur�ckgeben
}

void CTunerDlg::OnDestroy() 
{
	CDialog::OnDestroy();
	
	// TODO: Code f�r die Behandlungsroutine f�r Nachrichten hier einf�gen

	// Necessary to enable LNB loop through
	//m_Frontend.SetLNBParams(FALSE,FALSE,FALSE,FALSE);
}

BOOL CTunerDlg::PlayPercentEnglish(BYTE Percent)
{
	if(Percent < 20)
	{
		PlayResource(IDR_WAVE_E0,  0, FALSE);
	}
	else if(Percent >= 100)
	{
		PlayResource(IDR_WAVE_E100,0, FALSE);
	}
	else
	{
		switch(Percent/10) // Zehnerstellen
		{
		case 2: PlayResource(IDR_WAVE_E20, 0); break;
		case 3: PlayResource(IDR_WAVE_E30, 0); break;
		case 4: PlayResource(IDR_WAVE_E40, 0); break;
		case 5: PlayResource(IDR_WAVE_E50, 0); break;
		case 6: PlayResource(IDR_WAVE_E60, 0); break;
		case 7: PlayResource(IDR_WAVE_E70, 0); break;
		case 8: PlayResource(IDR_WAVE_E80, 0); break;
		case 9: PlayResource(IDR_WAVE_E90, 0); break;
		}
		switch(Percent%10) // Einerstellen
		{
		case 1: PlayResource(IDR_WAVE_E1, 0, FALSE); break;
		case 2: PlayResource(IDR_WAVE_E2, 0, FALSE); break;
		case 3: PlayResource(IDR_WAVE_E3, 0, FALSE); break;
		case 4: PlayResource(IDR_WAVE_E4, 0, FALSE); break;
		case 5: PlayResource(IDR_WAVE_E5, 0, FALSE); break;
		case 6: PlayResource(IDR_WAVE_E6, 0, FALSE); break;
		case 7: PlayResource(IDR_WAVE_E7, 0, FALSE); break;
		case 8: PlayResource(IDR_WAVE_E8, 0, FALSE); break;
		case 9: PlayResource(IDR_WAVE_E9, 0, FALSE); break;
		}
	}
	return TRUE;
}

BOOL CTunerDlg::PlayResource(int nID, int rpt, BOOL sync)
{
//  Header: Declared in mmsystem.h.
//  Import Library: Use winmm.lib.
	BOOL bRtn;
    LPSTR lpRes;
    HANDLE hRes;
    HRSRC hResInfo;
	int i;
    
	HINSTANCE Nl=AfxGetInstanceHandle();
    /* Find the WAVE resource. */
    hResInfo= FindResource(Nl,MAKEINTRESOURCE(nID),"WAVE");
    if(hResInfo == NULL)
		return FALSE;
    /* Load the WAVE resource. */
    hRes = LoadResource(Nl,hResInfo);
    if (hRes == NULL)
		return FALSE;
    /* Lock the WAVE resource. */
    lpRes=(LPSTR)LockResource(hRes);
    if(lpRes==NULL)
		return FALSE;
    /* Play the WAVE resource. */
	for(i=0; i<=rpt; i++)
	{
		if((i == rpt) && (!sync))
			bRtn = sndPlaySound(lpRes, SND_MEMORY | SND_ASYNC);
		else
			bRtn = sndPlaySound(lpRes, SND_MEMORY | SND_SYNC);
	    
		if(bRtn == NULL)
			return FALSE;
	}
    /* Free the WAVE resource and return success or failure. */
    FreeResource(hRes);
    return TRUE;
}

void CTunerDlg::OnOK() 
{

}

void CTunerDlg::OnCancel() 
{

}

BOOL CTunerDlg::TimerEvent(void)
{
	BOOL lock = FALSE;
	CDVBFrontend::SIGNAL_TYPE Signal;
	BYTE lvl, quality = 0;
	static BYTE doit = 0;

	if(m_Frontend.GetState(lock, &Signal) == DVB_ERR_NONE)
	{
		if(Signal.BER < 10e-4)
			quality = 75; // 75%
		else if(Signal.BER < 10e-3)
			quality = 50; // 50%
		else if(Signal.BER < 10e-2)
			quality = 25; // 25%
		else // (Signal.BER >= 10e-2)
			quality = 0; // 0%

		if(lock)
			quality += 25;
		else
			quality = 0;

		//m_strOutput.Format("Signal.BER: %f (%e), Quality: %u%%, Level: %u%%", Signal.BER, Signal.BER, quality, Signal.SNR100);
		m_ctrlSyncStat.SetPos(lock?100:0);
		m_ctrlBitErr.SetPos(quality);
		m_ctrlNestAGC.SetPos(Signal.SNR100);

		if(m_ctrlLvlSound.GetCheck())
		{	
			if(++doit%2) // jetzt Sprachausgabe (jedes 2.mal == alle 2 Sek.)
			{
				lvl = (BYTE)Signal.SNR100;
				PlayPercentEnglish(lvl);
			}
		}
	}
	else
	{
		m_ctrlSyncStat.SetPos(0);
		m_ctrlBitErr.SetPos(0);
		m_ctrlNestAGC.SetPos(0);
	}

	if(m_bScanning) // Sendersuchlauf
	{
		CDVBFrontend::CHANNEL_TYPE ch;
		DVB_ERROR err; 
		
		RestoreWaitCursor();

		if(m_Frontend.GetSearchState() == 0) // Running
		{
			err = m_Frontend.GetChannel(ch);
			m_strFrequenz.Format("%u", ch.dvb_s.dwFreq);
			SetDlgItemText(IDC_FREQUENZ, m_strFrequenz);
			UpdateWindow();
			Sleep(10);
		}
		else
		{
			UpdateData(TRUE);
			m_bScanning = FALSE;
			err = m_Frontend.GetChannel(ch);
			m_strFrequenz.Format("%u", ch.dvb_s.dwFreq);
			UpdateData(FALSE);
			OnButtonApply(); // Update GUI to new channel
			EndWaitCursor();
		}
	}


	return lock;
}

void CTunerDlg::DisableFrontendSettings(CDVBFrontend::FRONTEND_TYPE& FE_Type)
{
	switch(FE_Type)
	{
	case CDVBFrontend::FE_UNKNOWN:   // kein Frontend (Fehler)
		GetDlgItem( IDC_LVL_SOUND )->EnableWindow(FALSE);
		GetDlgItem( IDC_STATIC_FE )->EnableWindow(FALSE);
		GetDlgItem( IDC_STATIC_FREQ )->EnableWindow(FALSE);
		GetDlgItem( IDC_FREQUENZ )->EnableWindow(FALSE);
		GetDlgItem( IDC_FREQSPIN )->EnableWindow(FALSE);
	case CDVBFrontend::FE_TERRESTRIAL:  // terr. Frontend
		GetDlgItem( IDC_STATIC_SYMB )->EnableWindow(FALSE);
		GetDlgItem( IDC_SYMBOLRATE )->EnableWindow(FALSE);
		GetDlgItem( IDC_STATIC_QAM )->EnableWindow(FALSE);
		GetDlgItem( IDC_QAM )->EnableWindow(FALSE);
	case CDVBFrontend::FE_CABLE:   // Kabel-Frontend
		//GetDlgItem( IDC_LVL_SOUND )->EnableWindow(FALSE);
		GetDlgItem( IDC_STATIC_POL )->EnableWindow(FALSE);
		GetDlgItem( IDC_HORIZONTAL )->EnableWindow(FALSE);
		GetDlgItem( IDC_VERTIKAL )->EnableWindow(FALSE);
		break;
	case CDVBFrontend::FE_SATELLITE: // Sat-Frontend   
		GetDlgItem( IDC_STATIC_QAM )->EnableWindow(FALSE);
		GetDlgItem( IDC_QAM )->EnableWindow(FALSE);
		break;
	default:
		break;
	}	

	CDVBFrontend::BANDWITH_TYPE bwmin, bwmax;
	m_Frontend.GetBandwidthRange(bwmin, bwmax);
	if((m_Frontend.GetCapabilities() & HAS_BW_AUTO) || (bwmin == bwmax))
	{
		GetDlgItem( IDC_STATIC_BW )->ShowWindow(SW_HIDE);
		GetDlgItem( IDC_BW_7 )->ShowWindow(SW_HIDE);
		GetDlgItem( IDC_BW_8 )->ShowWindow(SW_HIDE);
	}

	if(m_Frontend.GetCapabilities() & HAS_SI_AUTO)
	{
		GetDlgItem( IDC_SPEC_INV )->ShowWindow(SW_HIDE);
	}
	else // move Spectral-Inversion check-box to the right position
	{
		RECT Rect, Rect2;
		long lwide, lhigh;
		CWnd* pWnd2 = NULL;

		CWnd* pWnd = GetDlgItem(IDC_SPEC_INV);
		pWnd->GetWindowRect(&Rect);
		ScreenToClient(&Rect);
		lwide = Rect.right - Rect.left;
		lhigh = Rect.bottom - Rect.top;
		
		switch(FE_Type)
		{
		case CDVBFrontend::FE_TERRESTRIAL:
		case CDVBFrontend::FE_SATELLITE:
			GetDlgItem( IDC_QAM )->ShowWindow(SW_HIDE);
			GetDlgItem( IDC_STATIC_QAM )->ShowWindow(SW_HIDE);
			pWnd2 = GetDlgItem(IDC_QAM);
			break;
		case CDVBFrontend::FE_CABLE:
			GetDlgItem( IDC_STATIC_POL )->ShowWindow(SW_HIDE);
			GetDlgItem( IDC_HORIZONTAL )->ShowWindow(SW_HIDE);
			GetDlgItem( IDC_VERTIKAL )->ShowWindow(SW_HIDE);
			pWnd2 = GetDlgItem(IDC_HORIZONTAL);
			break;
		}		
		if(pWnd2)
		{
			pWnd2->GetWindowRect(&Rect2);
			ScreenToClient(&Rect2);
			pWnd->MoveWindow(Rect2.left, Rect2.top, lwide, lhigh, TRUE);
		}
	}


	if(! (m_Frontend.GetCapabilities() & HAS_CH_SCAN)) // channel scan available?
	{
		GetDlgItem( IDC_STATIC_SEARCH )->EnableWindow(FALSE);
		GetDlgItem( IDC_STATIC_FROM )->EnableWindow(FALSE);
		GetDlgItem( IDC_STATIC_UPTO )->EnableWindow(FALSE);
		GetDlgItem( IDC_EDIT_LOWER_FREQ )->EnableWindow(FALSE);
		GetDlgItem( IDC_EDIT_UPPER_FREQ )->EnableWindow(FALSE);
		GetDlgItem( IDC_STATIC_KHZ1 )->EnableWindow(FALSE);
		GetDlgItem( IDC_STATIC_KHZ2 )->EnableWindow(FALSE);
		GetDlgItem( IDC_BUTTON_SCAN )->EnableWindow(FALSE);
		GetDlgItem( IDC_BUTTON_START_SCAN )->EnableWindow(FALSE);
		GetDlgItem( IDC_BUTTON_STOP_SCAN )->EnableWindow(FALSE);
	}
}

void CTunerDlg::SettingsSaveToRegistry()
{
	CString s, to;

	to = DVBMPE_REGISTRY_START_STRING;
	to += m_strActProfile + "\\Settings";
	
	// Tuner-Dialog
	m_myReg.SaveToRegistry(to, "Frequenz", m_strFrequenz);
	m_myReg.SaveToRegistry(to, "Symbolrate", m_strSymbRate);
	m_myReg.SaveToRegistry(to, "Polarisation", m_iPolarisation);
	m_myReg.SaveToRegistry(to, "QAM", m_iQAM);
	m_myReg.SaveToRegistry(to, "SpecInv", m_bSpecInv);
	m_myReg.SaveToRegistry(to, "BandWidth", m_iBandWidth);

	// LNB/Diseqc-Dialog
	m_myReg.SaveToRegistry(to, "LOF1", m_dwLOF1);
	m_myReg.SaveToRegistry(to, "LOF2", m_dwLOF2);
	m_myReg.SaveToRegistry(to, "LOF_SW", m_dwLOFSW);
	m_myReg.SaveToRegistry(to, "LNBPower", m_bLNBPower);
	m_myReg.SaveToRegistry(to, "Diseqc", m_iDiseqc);
	m_myReg.SaveToRegistry(to, "SimplePosition", m_iSimplePosition);
	m_myReg.SaveToRegistry(to, "MultiPosition", m_iMultiPosition);
	m_myReg.SaveToRegistry(to, "MultiOption", m_iMultiOption);
}

void CTunerDlg::SettingsReadFromRegistry()
{
	CString from;
	int pos;

	from = DVBMPE_REGISTRY_START_STRING;
	from += m_strActProfile + "\\Settings";

	// Tuner-Dialog
	if(! m_myReg.ReadFromRegistry(from, "Frequenz", m_strFrequenz))
		m_strFrequenz = "12051000";
	
	if(! m_myReg.ReadFromRegistry(from, "Symbolrate", m_strSymbRate))
	{
		m_strSymbRate = "27500000";
		m_ctrlSymbolRate.SelectString(-1, m_strSymbRate);
	}
	else
	{
		pos = m_ctrlSymbolRate.FindStringExact(-1, m_strSymbRate);
		if(pos == CB_ERR)
			pos = m_ctrlSymbolRate.InsertString(-1, m_strSymbRate);
		if(pos != CB_ERR)
			m_ctrlSymbolRate.SetCurSel(pos);
	}
	
	if(! m_myReg.ReadFromRegistry(from, "Polarisation", m_iPolarisation))
		m_iPolarisation = 1;

	if(! m_myReg.ReadFromRegistry(from, "QAM", m_iQAM))
		m_iQAM = 2;

	if(! m_myReg.ReadFromRegistry(from, "SpecInv", m_bSpecInv))
		m_bSpecInv = FALSE;

	if(! m_myReg.ReadFromRegistry(from, "BandWidth", m_iBandWidth))
		m_iBandWidth = 1;

	// LNB/Diseqc-Dialog
	if(! m_myReg.ReadFromRegistry(from, "LOF1", m_dwLOF1))
		m_dwLOF1 = 9750000;

	if(! m_myReg.ReadFromRegistry(from, "LOF2", m_dwLOF2))
		m_dwLOF2 = 10600000;

	if(! m_myReg.ReadFromRegistry(from, "LOF_SW", m_dwLOFSW))
		m_dwLOFSW = 11700000;

	if(! m_myReg.ReadFromRegistry(from, "LNBPower", m_bLNBPower))
		m_bLNBPower = TRUE;

	if(! m_myReg.ReadFromRegistry(from, "Diseqc", m_iDiseqc))
		m_iDiseqc = 0;
	
	if(! m_myReg.ReadFromRegistry(from, "SimplePosition", m_iSimplePosition))
		m_iSimplePosition = 0;
	
	if(! m_myReg.ReadFromRegistry(from, "MultiPosition", m_iMultiPosition))
		m_iMultiPosition = 0;
	
	if(! m_myReg.ReadFromRegistry(from, "MultiOption", m_iMultiOption))
		m_iMultiOption = 0;
}

void CTunerDlg::ProfileEvent(const CString& newProfile, const CString& cpyProfile)
{
	if(cpyProfile == "")
	{
		m_strActProfile = newProfile;
		SettingsReadFromRegistry();

		if(m_pLnbDlg != NULL)
			m_pLnbDlg->SetValues(m_iDiseqc, m_iSimplePosition, m_iMultiOption, m_iMultiPosition, m_dwLOF1, m_dwLOF2, m_dwLOFSW, m_bLNBPower);
		UpdateData(FALSE); // Dialog aktualisieren
		
		SetValuesEvent(); // gelesende Werte setzen, Settings speichern
	}
	else
	{
		m_strActProfile = cpyProfile;
		SettingsReadFromRegistry();

		if(m_pLnbDlg != NULL)
			m_pLnbDlg->SetValues(m_iDiseqc, m_iSimplePosition, m_iMultiOption, m_iMultiPosition, m_dwLOF1, m_dwLOF2, m_dwLOFSW, m_bLNBPower);
		UpdateData(FALSE); // Dialog aktualisieren

		m_strActProfile = newProfile;
		SetValuesEvent(); // gelesende Werte setzen, Settings speichern
	}
}

void CTunerDlg::SetValuesEvent(void)
{
	DVB_ERROR error;
	DWORD dwFrequenz, dwSymbolrate, lof;
	DWORD dwmax, dwmin;
	BOOL pol, f22;
	BYTE DiPar[4];
	int i, pos;
	CString s;
	CDVBFrontend::CHANNEL_TYPE ch;

	UpdateData(TRUE);

	m_ctrlSyncStat.SetPos(0);
	m_ctrlBitErr.SetPos(0);

	// Frontend einstellen (Tuner, Demodulator, Diseqc, LNB)
	GetDlgItemText(IDC_SYMBOLRATE, m_strSymbRate);
	dwSymbolrate = strtoul(m_strSymbRate, NULL, 10);
	pos = m_ctrlSymbolRate.FindStringExact(-1, m_strSymbRate);
	if(pos == CB_ERR)
		pos = m_ctrlSymbolRate.InsertString(-1, m_strSymbRate);
	if(pos != CB_ERR)
		pos = m_ctrlSymbolRate.SetCurSel(pos);
	
	m_Frontend.GetFrequencyRange(dwmin, dwmax);

	switch(m_FE_Type)
	{
	case CDVBFrontend::FE_SATELLITE: // Sat-Frontend
	
		if(m_pLnbDlg != NULL)
			m_pLnbDlg->GetValues(m_iDiseqc, m_iSimplePosition, m_iMultiOption, m_iMultiPosition, m_dwLOF1, m_dwLOF2, m_dwLOFSW, m_bLNBPower);

		dwFrequenz = strtoul(m_strFrequenz, NULL, 10);
		dwmin = dwmin + __min(m_dwLOF1, m_dwLOF2); 
		dwmax = dwmax + __max(m_dwLOF1, m_dwLOF2); 
		if((dwFrequenz < dwmin) || (dwFrequenz > dwmax))
		{
			s.Format("\n(%u kHz - %u kHz)", dwmin, dwmax);
			MessageBox("Please insert a valid frequency!" + s, "Error");
			return;
		}

		pol = m_iPolarisation;
		f22 = (dwFrequenz >= m_dwLOFSW) ? TRUE : FALSE;
		lof = (dwFrequenz >= m_dwLOFSW) ? m_dwLOF2 : m_dwLOF1;
		
		switch(m_iDiseqc)
		{
		case 0: // None (DiSEqC deaktivieren (Reset))
			DiPar[0] = 0xE0; DiPar[1] = 0x00; DiPar[2] = 0x00;
			error = m_Frontend.SendDiSEqCMsg(DiPar, 3, 0xff);
			break;
		case 1: // Simple (nur Ton-Burst senden)
			error = m_Frontend.SendDiSEqCMsg(DiPar, 0, (m_iSimplePosition == 0)?0:1);
			break;
		case 2: // Multi (DiSEqC-Sequenz wird dreimal gesendet)
			DiPar[0] = 0xE0; DiPar[1] = 0x10; DiPar[2] = 0x38;
			DiPar[3] = DISEQC_HIGH_NIBLE;
			DiPar[3] |= pol ? DISEQC_VERTICAL : DISEQC_HORIZONTAL;
			DiPar[3] |= f22 ? DISEQC_HIGH_BAND : DISEQC_LOW_BAND;
			DiPar[3] |= (m_iMultiPosition) ? DISEQC_POSITION_B : DISEQC_POSITION_A;
			DiPar[3] |= (m_iMultiOption) ? DISEQC_OPTION_B : DISEQC_OPTION_A;
			for(i=0; i<3; i++)
			{
				error = m_Frontend.SendDiSEqCMsg(DiPar, 4, 0xff);
				DiPar[0] = 0xE1; // Wiederholung
				Sleep(120); // Wartezeit zwischen Diseqc-Sequenzen
			}
			break;
		}
		Sleep(20);

		ch.dvb_s.dwFreq = dwFrequenz;
		ch.dvb_s.dwLOF = lof;
		ch.dvb_s.bF22kHz = f22;
		ch.dvb_s.LNB_Power = (! m_bLNBPower) ? CDVBFrontend::POWER_OFF : (! pol) ? CDVBFrontend::POL_HORZ : CDVBFrontend::POL_VERT;
		ch.dvb_s.dwSymbRate = dwSymbolrate;
		if(m_Frontend.GetCapabilities() & HAS_SI_AUTO)
			ch.dvb_s.Inversion = CDVBFrontend::SI_AUTO;
		else
			ch.dvb_s.Inversion = m_bSpecInv ? CDVBFrontend::SI_ON : CDVBFrontend::SI_OFF;
		//ch.dvb_s.Inversion = CDVBFrontend::SI_AUTO;
		ch.dvb_s.Viterbi = CDVBFrontend::VR_AUTO;
		m_Frontend.SetChannel(ch);
		break;

	case CDVBFrontend::FE_CABLE:   // Kabel-Frontend
		if(m_strFrequenz.GetLength() <=3) // Kanalangabe
			dwFrequenz = GetFreq(m_strFrequenz);
		else // Frequenzangabe
			dwFrequenz = strtoul(m_strFrequenz, NULL, 10);
		
		if((dwFrequenz < dwmin) || (dwFrequenz > dwmax))
		{
			s.Format("\n(%u kHz - %u kHz)", dwmin, dwmax);
			MessageBox("Please insert a valid frequency!" + s, "Error");
			return;
		}

		ch.dvb_c.dwFreq = dwFrequenz;
		ch.dvb_c.dwSymbRate = dwSymbolrate;
		if(m_Frontend.GetCapabilities() & HAS_SI_AUTO)
			ch.dvb_c.Inversion = CDVBFrontend::SI_AUTO;
		else
			ch.dvb_c.Inversion = m_bSpecInv ? CDVBFrontend::SI_ON : CDVBFrontend::SI_OFF;
		//ch.dvb_c.Inversion = CDVBFrontend::SI_AUTO;
		ch.dvb_c.Qam = (CDVBFrontend::QAM_TYPE)m_iQAM;

		if(m_Frontend.GetCapabilities() & HAS_BW_AUTO)
			ch.dvb_c.BandWidth = CDVBFrontend::BW_AUTO;
		else
		{
			CDVBFrontend::BANDWITH_TYPE bwmin, bwmax;
			m_Frontend.GetBandwidthRange(bwmin, bwmax);
			if(bwmin == bwmax)
				ch.dvb_c.BandWidth = bwmin;
			else
				ch.dvb_c.BandWidth = (m_iBandWidth == 0) ? CDVBFrontend::BW_7MHz : CDVBFrontend::BW_8MHz;
		}

		m_Frontend.SetChannel(ch);
		break;
	
	case CDVBFrontend::FE_TERRESTRIAL:  // terr. Frontend
		if(m_strFrequenz.GetLength() <=3) // Kanalangabe
			dwFrequenz = GetFreq(m_strFrequenz);
		else // Frequenzangabe
			dwFrequenz = strtoul(m_strFrequenz, NULL, 10);

		if((dwFrequenz < dwmin) || (dwFrequenz > dwmax))
		{
			s.Format("\n(%u kHz - %u kHz)", dwmin, dwmax);
			MessageBox("Please insert a valid frequency!" + s, "Error");
			return;
		}

		ch.dvb_t.dwFreq = dwFrequenz;
		if(m_Frontend.GetCapabilities() & HAS_SI_AUTO)
			ch.dvb_t.Inversion = CDVBFrontend::SI_AUTO;
		else
			ch.dvb_t.Inversion = m_bSpecInv ? CDVBFrontend::SI_ON : CDVBFrontend::SI_OFF;
		//ch.dvb_t.Inversion = CDVBFrontend::SI_AUTO;

		if(m_Frontend.GetCapabilities() & HAS_BW_AUTO)
			ch.dvb_t.BandWidth = CDVBFrontend::BW_AUTO;
		else
		{
			CDVBFrontend::BANDWITH_TYPE bwmin, bwmax;
			m_Frontend.GetBandwidthRange(bwmin, bwmax);
			if(bwmin == bwmax)
				ch.dvb_t.BandWidth = bwmin;
			else
				ch.dvb_t.BandWidth = (m_iBandWidth == 0) ? CDVBFrontend::BW_7MHz : CDVBFrontend::BW_8MHz;
		}
		ch.dvb_t.bScan = FALSE; // !!!

		m_Frontend.SetChannel(ch);
		break;
	
	case CDVBFrontend::FE_UNKNOWN:   // kein Frontend (Fehler)
	default:
		break;
	}

	// Werte in der Registry merken (f�r den n�chsten Start)
	SettingsSaveToRegistry();

	UpdateData(FALSE);
}

void CTunerDlg::OnDeltaposFreqspin(NMHDR* pNMHDR, LRESULT* pResult) 
{
	NM_UPDOWN* pNMUpDown = (NM_UPDOWN*)pNMHDR;
	CString strFreq;
	DWORD dwmax, dwmin, dwf, dwfn;
	int i;

	GetDlgItemText(IDC_FREQUENZ, strFreq);

	switch(m_FE_Type)
	{
	case CDVBFrontend::FE_SATELLITE: // Sat-Frontend   
		dwmin =  950000 + __min(m_dwLOF1, m_dwLOF2); 
		dwmax = 2150000 + __max(m_dwLOF1, m_dwLOF2); 
		dwf = strtoul(strFreq, NULL, 10);
		// 1, 9, 81er Schritte (250, 2250, 20250 kHz Schritte)
		dwfn = dwf + 250 * (pNMUpDown->iDelta * abs(pNMUpDown->iDelta));
		if(dwfn < dwmin)
			strFreq.Format("%u", dwmax);
		else if(dwfn > dwmax)
			strFreq.Format("%u", dwmin);
		else
			strFreq.Format("%u", dwfn);
		break;
	case CDVBFrontend::FE_CABLE:   // Kabel-Frontend
		//dwf = strtoul(strFreq, NULL, 10);
		if(strFreq.GetLength() <=3) // Kanalangabe
		{
			if(pNMUpDown->iDelta > 0)
				for(i=0; i<abs(pNMUpDown->iDelta); i++)
					strFreq = GetNextFreq(strFreq, TRUE); // 1, 3, 9er Schritte
			else			
				for(i=0; i<abs(pNMUpDown->iDelta); i++)
					strFreq = GetPrevFreq(strFreq, TRUE); // 1, 3, 9er Schritte
		}
		else // Frequenzangabe
		{	
			if(pNMUpDown->iDelta > 0)
				for(i=0; i<abs(pNMUpDown->iDelta); i++)
					strFreq = GetNextFreq(strFreq, FALSE); // ca. 8, 24, 72 MHz Schritte
			else			
				for(i=0; i<abs(pNMUpDown->iDelta); i++)
					strFreq = GetPrevFreq(strFreq, FALSE); // ca. 8, 24, 72 MHz Schritte
		}
		break;
	case CDVBFrontend::FE_TERRESTRIAL:  // terr. Frontend
		dwf = strtoul(strFreq, NULL, 10);
		if(strFreq.GetLength() <=3) // Kanalangabe
		{	dwmin = 21; dwmax = 69;
			dwfn = dwf + pNMUpDown->iDelta; // 1, 3, 9er Schritte
		}
		else // Frequenzangabe
		{	dwmin = 474000; dwmax = 858000;
			dwfn = dwf + pNMUpDown->iDelta * 8000; // 8, 24, 72 MHz Schritte
		}
		if(dwfn < dwmin)
			strFreq.Format("%u", dwmax);
		else if(dwfn > dwmax)
			strFreq.Format("%u", dwmin);
		else
			strFreq.Format("%u", dwfn);
		break;
	case CDVBFrontend::FE_UNKNOWN:   // kein Frontend (Fehler)
	default:
		break;
	}	

	SetDlgItemText(IDC_FREQUENZ, strFreq);
	
	*pResult = 0;
}

void CTunerDlg::OnButtonApply() 
{
	BeginWaitCursor();
	SetValuesEvent(); // gelesende Werte setzen, Settings speichern
	EndWaitCursor();
}

// uses Blocking version of SearchNextChannel
void CTunerDlg::OnButtonScan() 
{
	DWORD dwLowerFreq, dwUpperFreq, res;
	CDVBFrontend::CHANNEL_TYPE ch;
	DVB_ERROR err; 

	UpdateData(TRUE);
	dwLowerFreq = strtoul(m_strLowerFreq, NULL, 10);
	dwUpperFreq = strtoul(m_strUpperFreq, NULL, 10);

	m_strFrequenz = m_strLowerFreq;
	UpdateData(FALSE);
	OnButtonApply(); // set LowerFreq first

	BeginWaitCursor();
	res = m_Frontend.SearchNextChannel(dwUpperFreq); // search up to UpperFreq
	EndWaitCursor();

	err = m_Frontend.GetChannel(ch);
	m_strFrequenz.Format("%u", ch.dvb_s.dwFreq);
	UpdateData(FALSE);
	OnButtonApply(); // Update GUI to new channel
}

// uses None-Blocking version of SearchNextChannel
void CTunerDlg::OnButtonStartScan() 
{
	DWORD dwLowerFreq, dwUpperFreq, res;
	//CDVBFrontend::CHANNEL_TYPE ch;
	//DVB_ERROR err; 

	UpdateData(TRUE);
	dwLowerFreq = strtoul(m_strLowerFreq, NULL, 10);
	dwUpperFreq = strtoul(m_strUpperFreq, NULL, 10);

	m_strFrequenz = m_strLowerFreq;
	UpdateData(FALSE);
	OnButtonApply(); // set LowerFreq first

	BeginWaitCursor();
	res = m_Frontend.SearchNextChannel(dwUpperFreq, FALSE); // search up to UpperFreq

	m_bScanning = TRUE;
/*
	while(m_Frontend.GetSearchState() == 0) // Running
	{
		err = m_Frontend.GetChannel(ch);
		m_strFrequenz.Format("%u", ch.dvb_s.dwFreq);
		SetDlgItemText(IDC_FREQUENZ, m_strFrequenz);
		UpdateWindow();
		Sleep(10);
	}
	EndWaitCursor();

	err = m_Frontend.GetChannel(ch);
	m_strFrequenz.Format("%u", ch.dvb_s.dwFreq);
	UpdateData(FALSE);
	OnButtonApply(); // Update GUI to new channel
*/
}

void CTunerDlg::OnButtonStopScan() 
{
	m_bScanning = FALSE;
	m_Frontend.StopSearch();
	EndWaitCursor();
}

