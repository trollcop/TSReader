//  TT  -  TechnoTrend  -  TT  -  TechnoTrend  -  TT  -  TechnoTrend  -  TT  
//
//
//  (C) TechnoTrend AG 1999-2001
//
//  All rights are reserved. Reproduction in whole or in part is prohibited 
//  without the written consent of the copyright owner. TechnoTrend 
//  reserves the right to make changes without notice at any time.  
//
//
//  TT  -  TechnoTrend  -  TT  -  TechnoTrend  -  TT  -  TechnoTrend  -  TT  
//
///////////////////////////////////////////////////////////////////////////
//
//  Filename:     DVBMPE.cpp
//
//  Project(s):   TestAppDvb
//
//  Author:       GRi
//
//  Purpose:      DVBMPE.cpp
//   
//  Environment:  Win32
//
//  Dev. Tool(s): MSVC 6.0
//
//  Note(s):      
// 
///////////////////////////////////////////////////////////////////////////
// 
//  File History
//
//   $Workfile: DVBMPE.cpp $
//   $Revision: 2 $  
//    $Modtime: 18.07.01 11:55 $
//
//   $Log: /DVB-PC/APP/TestAppUsbLcd/DVBMPE.cpp $
//     >>   
//     >>   2     18.07.01 14:41 Guido
//     >>   
//     >>   1     10.07.01 14:48 Guido
//     >>   
//     >>   1     6.06.01 10:55 Guido
//     >>   
//     >>   3     16.05.01 15:11 Guido
//
///////////////////////////////////////////////////////////////////////////

// DVBMPE.cpp : Legt das Klassenverhalten f�r die Anwendung fest.
//

#include "stdafx.h"
#include "DVBMPE.h"
#include "DVBMPEDlg.h"
#include "DVBDLLInit.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDVBMPEApp

BEGIN_MESSAGE_MAP(CDVBMPEApp, CWinApp)
	//{{AFX_MSG_MAP(CDVBMPEApp)
	//}}AFX_MSG_MAP
	ON_COMMAND(ID_HELP, CWinApp::OnHelp)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDVBMPEApp Konstruktion

CDVBMPEApp::CDVBMPEApp()
{
	// ZU ERLEDIGEN: Hier Code zur Konstruktion einf�gen
	// Alle wichtigen Initialisierungen in InitInstance platzieren
}

/////////////////////////////////////////////////////////////////////////////
// Das einzige CDVBMPEApp-Objekt

CDVBMPEApp theApp;

CString DVBMPE_REGISTRY_START_STRING = "SOFTWARE\\TechnoTrend\\TestAppDVB";

/////////////////////////////////////////////////////////////////////////////
// CDVBMPEApp Initialisierung

BOOL CDVBMPEApp::InitInstance()
{
	InitDvbApiDll(); // call this function before any other function in the API-DLL

/*	if (!AfxSocketInit())
	{
		AfxMessageBox(IDP_SOCKETS_INIT_FAILED);
		return FALSE;
	}
*/
	AfxEnableControlContainer();

	// Standardinitialisierung
	// Wenn Sie diese Funktionen nicht nutzen und die Gr��e Ihrer fertigen 
	//  ausf�hrbaren Datei reduzieren wollen, sollten Sie die nachfolgenden
	//  spezifischen Initialisierungsroutinen, die Sie nicht ben�tigen, entfernen.

#ifdef _AFXDLL
	Enable3dControls();			// Diese Funktion bei Verwendung von MFC in gemeinsam genutzten DLLs aufrufen
#else
	Enable3dControlsStatic();	// Diese Funktion bei statischen MFC-Anbindungen aufrufen
#endif

	CDVBMPEDlg dlg;

	CString sCmd;
	sCmd.Format("\"%s\"",(LPCTSTR)m_lpCmdLine);
	sCmd.MakeUpper();

	dlg.m_bHideOnStart = (-1 != sCmd.Find("-HIDE",0)) ? TRUE : FALSE;

	m_pMainWnd = &dlg;

	int nResponse = dlg.DoModal();
	if (nResponse == IDOK)
	{
		// ZU ERLEDIGEN: F�gen Sie hier Code ein, um ein Schlie�en des
		//  Dialogfelds �ber OK zu steuern
	}
	else if (nResponse == IDCANCEL)
	{
		// ZU ERLEDIGEN: F�gen Sie hier Code ein, um ein Schlie�en des
		//  Dialogfelds �ber "Abbrechen" zu steuern
	}

	// Da das Dialogfeld geschlossen wurde, FALSE zur�ckliefern, so dass wir die
	//  Anwendung verlassen, anstatt das Nachrichtensystem der Anwendung zu starten.
	return FALSE;
}

void CDVBMPEApp::WinHelp(DWORD dwData, UINT nCmd) 
{
	// TODO: Speziellen Code hier einf�gen und/oder Basisklasse aufrufen
	return;
}

