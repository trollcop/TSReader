//  TT  -  TechnoTrend  -  TT  -  TechnoTrend  -  TT  -  TechnoTrend  -  TT  
//
//
//  (C) TechnoTrend AG 1999-2001
//
//  All rights are reserved. Reproduction in whole or in part is prohibited 
//  without the written consent of the copyright owner. TechnoTrend 
//  reserves the right to make changes without notice at any time.  
//
//
//  TT  -  TechnoTrend  -  TT  -  TechnoTrend  -  TT  -  TechnoTrend  -  TT  
//
///////////////////////////////////////////////////////////////////////////
//
//  Filename:     TeletextDlg.cpp
//
//  Project(s):   TestAppDvb
//
//  Author:       GRi
//
//  Purpose:      TeletextDlg.cpp
//   
//  Environment:  Win32
//
//  Dev. Tool(s): MSVC 6.0
//
//  Note(s):      
// 
///////////////////////////////////////////////////////////////////////////
// 
//  File History
//
//   $Workfile: TeletextDlg.cpp $
//   $Revision: 2 $  
//    $Modtime: 27.03.02 15:41 $
//
//   $Log: /DVB-PC/APP/TestAppUsbLcd/TeletextDlg.cpp $
//     >>   
//     >>   2     27.03.02 15:54 Guido
//     >>   
//     >>   1     10.07.01 14:48 Guido
//     >>   
//     >>   1     6.06.01 10:55 Guido
//     >>   
//     >>   5     16.05.01 15:11 Guido
//
///////////////////////////////////////////////////////////////////////////

// TeletextDlg.cpp: Implementierungsdatei
//

#include "stdafx.h"
#include "dvbmpe.h"
#include "TeletextDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

extern CString DVBMPE_REGISTRY_START_STRING;

/////////////////////////////////////////////////////////////////////////////
// Dialogfeld CTeletextDlg 


CTeletextDlg::CTeletextDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CTeletextDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CTeletextDlg)
	m_strSecPID = _T("17");
	m_strSecTID = _T("66");
	m_strFltRawOut = _T("");
	m_strTTPage = _T("100");
	m_strTTPID = _T("36");
	m_strTTRawOut = _T("");
	//}}AFX_DATA_INIT
}


void CTeletextDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CTeletextDlg)
	DDX_Text(pDX, IDC_EDIT_FLT_PID, m_strSecPID);
	DDX_Text(pDX, IDC_EDIT_FLT_TID, m_strSecTID);
	DDX_Text(pDX, IDC_EDIT_FLT_RAW, m_strFltRawOut);
	DDX_Text(pDX, IDC_EDIT_TT_PAGE, m_strTTPage);
	DDX_Text(pDX, IDC_EDIT_TT_PID, m_strTTPID);
	DDX_Text(pDX, IDC_EDIT_TT_RAW, m_strTTRawOut);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CTeletextDlg, CDialog)
	//{{AFX_MSG_MAP(CTeletextDlg)
	ON_BN_CLICKED(IDC_TELETEXT_ON, OnTeletextOn)
	ON_BN_CLICKED(IDC_TELETEXT_OFF, OnTeletextOff)
	ON_BN_CLICKED(IDC_ADD_PAGE, OnTeletextAddPage)
	ON_BN_CLICKED(IDC_ALL_PAGES, OnTeletextAllPages)
	ON_BN_CLICKED(IDC_FLT_SET, OnSecFltSet)
	ON_BN_CLICKED(IDC_FLT_RESET, OnSecFltReset)
	ON_WM_DESTROY()
	ON_WM_CANCELMODE()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// Behandlungsroutinen f�r Nachrichten CTeletextDlg 

BOOL CTeletextDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();

	// TODO: Zus�tzliche Initialisierung hier einf�gen
	m_Teletext.m_pTeletextDlg = this;
	m_SecFilter.m_pTeletextDlg = this;

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX-Eigenschaftenseiten sollten FALSE zur�ckgeben
}

void CTeletextDlg::OnDestroy() 
{
	CDialog::OnDestroy();
	
	// TODO: Code f�r die Behandlungsroutine f�r Nachrichten hier einf�gen
	
	m_Teletext.TTXOff();
	
	m_SecFilter.ResetFilter();	
}

void CTeletextDlg::OnOK() 
{

}

void CTeletextDlg::OnCancel() 
{

}

void CTeletextDlg::OnTeletextOn() 
{
	UpdateData(TRUE);

	WORD wPID = (WORD)strtoul(m_strTTPID, NULL, 10);

	if(m_Teletext.TTXOn(wPID) != DVB_ERR_NONE)
		MessageBox("Could not start Teletext!");

	SettingsSaveToRegistry();
}

void CTeletextDlg::OnTeletextOff() 
{
	if(m_Teletext.TTXOff() != DVB_ERR_NONE)
		MessageBox("Could not stop Teletext!");
}

void CTeletextDlg::OnTeletextAddPage() 
{
	UpdateData(TRUE);

	WORD wMag, wTens, wUnits;
	WORD wTTPage = (WORD)strtoul(m_strTTPage, NULL, 10);

	if( (wTTPage < 100) || (wTTPage >= 900))
	{
		wTTPage = 100;
		m_strTTPage = "100";
		UpdateData(FALSE);
	}

	if(wTTPage == (WORD)-1)
		wMag = wTens = wUnits = (WORD)-1;
	else
	{
		wMag = (WORD)(wTTPage / 100);
		wTens = (WORD)((wTTPage - wMag * 100) / 10);
		wUnits = (WORD)(wTTPage - wMag * 100 - wTens * 10);
		if(wMag == 8)
			wMag = 0;
	}

	if(! m_Teletext.TTXModifySearchTable(wMag, wTens, wUnits, CDVBTeletext::CAPTURE_PAGE_PARITY_CORRECTED))
		MessageBox("Could not modify SearchTable!");

	SettingsSaveToRegistry();
}

void CTeletextDlg::OnTeletextAllPages() 
{
	WORD wMag, wTens, wUnits;
	wMag = wTens = wUnits = (WORD)-1;

	if(! m_Teletext.TTXModifySearchTable(wMag, wTens, wUnits, CDVBTeletext::CAPTURE_PAGE_PARITY_CORRECTED))
		MessageBox("Could not modify SearchTable!");
}

void CTeletextDlg::OnSecFltSet() 
{
	UpdateData(TRUE);
	
	WORD wSecPid = (WORD)strtoul(m_strSecPID, NULL, 0);
	BYTE bSecTid = (BYTE)strtoul(m_strSecTID, NULL, 0);
	BYTE bSecMask = 0xff;

	DVB_ERROR err = m_SecFilter.SetFilter(CDVBTSFilter::SECTION_FILTER, wSecPid, &bSecTid, &bSecMask, 1);
	if(err != DVB_ERR_NONE)
		MessageBox("Could not set Filter!");

	SettingsSaveToRegistry();
}

void CTeletextDlg::OnSecFltReset() 
{
	DVB_ERROR err = m_SecFilter.ResetFilter();
	if(err != DVB_ERR_NONE)
		MessageBox("Could not del Filter!");
}

void CTeletextDlg::SettingsSaveToRegistry()
{
	CString s, to;

	to = DVBMPE_REGISTRY_START_STRING;
	to += m_strActProfile + "\\Settings";

	m_myReg.SaveToRegistry(to, "SecPID", m_strSecPID);
	m_myReg.SaveToRegistry(to, "SecTID", m_strSecTID);
	m_myReg.SaveToRegistry(to, "TTPage", m_strTTPage);
	m_myReg.SaveToRegistry(to, "TTPID", m_strTTPID);
}

void CTeletextDlg::SettingsReadFromRegistry()
{
	CString from;

	from = DVBMPE_REGISTRY_START_STRING;
	from += m_strActProfile + "\\Settings";

	if(! m_myReg.ReadFromRegistry(from, "SecPID", m_strSecPID))
		m_strSecPID = "17";
	
	if(! m_myReg.ReadFromRegistry(from, "SecTID", m_strSecTID))
		m_strSecTID = "66";
	
	if(! m_myReg.ReadFromRegistry(from, "TTPage", m_strTTPage))
		m_strTTPage = "100";

	if(! m_myReg.ReadFromRegistry(from, "TTPID", m_strTTPID))
		m_strTTPID = "36";
}

void CTeletextDlg::ProfileEvent(const CString& newProfile, const CString& cpyProfile)
{
//	UpdateData(TRUE);
//	if(m_strActProfile.GetLength() > 0)
//		SettingsSaveToRegistry();

	if(cpyProfile == "")
	{
		m_strActProfile = newProfile;
		SettingsReadFromRegistry();

		UpdateData(FALSE); // Dialog aktualisieren
		
		//SettingsSaveToRegistry();
	}
	else
	{
		m_strActProfile = cpyProfile;
		SettingsReadFromRegistry();

		UpdateData(FALSE); // Dialog aktualisieren

		m_strActProfile = newProfile;
		SettingsSaveToRegistry();
	}
}

//==========================================================================

void CMyTeleText::OnTTXPage(BYTE* TTXPage, int len)
{
		m_strOut = "";

		// Testhalber in TextBox ausgeben
		for(int i=0; i<((len>500)?500:len); i++)
		{
			if(isprint(TTXPage[i]))
				m_strOut += TTXPage[i];
			else
				m_strOut += " ";

			if((i>0) && (i%40 == 0))
				m_strOut += "\r\n";
		}

		m_pTeletextDlg->SetDlgItemText(IDC_EDIT_TT_RAW, m_strOut);
};

//===========================================================================
	
void CMyFilter::OnDataArrival(BYTE* Buff, int len)
{
		m_strOut = "";

		// Testhalber in TextBox ausgeben
		for(int i=0; i<((len>100)?100:len); i++)
		{
			if(isprint(Buff[i]))
				m_strOut += Buff[i];
			else
				m_strOut += " ";

			if((i>0) && (i%20 == 0))
				m_strOut += "\r\n";
		}

		m_pTeletextDlg->SetDlgItemText(IDC_EDIT_FLT_RAW, m_strOut);
}

