//  TT  -  TechnoTrend  -  TT  -  TechnoTrend  -  TT  -  TechnoTrend  -  TT  
//
//
//  (C) TechnoTrend AG 1999-2001
//
//  All rights are reserved. Reproduction in whole or in part is prohibited 
//  without the written consent of the copyright owner. TechnoTrend 
//  reserves the right to make changes without notice at any time.  
//
//
//  TT  -  TechnoTrend  -  TT  -  TechnoTrend  -  TT  -  TechnoTrend  -  TT  
//
///////////////////////////////////////////////////////////////////////////
//
//  Filename:     ProfilDlg.h
//
//  Project(s):   TestAppDvb
//
//  Author:       GRi
//
//  Purpose:      Profil Change Dialog
//   
//  Environment:  Win32
//
//  Dev. Tool(s): MSVC 6.0
//
//  Note(s):      
// 
///////////////////////////////////////////////////////////////////////////
// 
//  File History
//
//   $Workfile: ProfilDlg.h $
//   $Revision: 1 $  
//    $Modtime: 29.05.01 9:18 $
//
//   $Log: /DVB-PC/APP/TestAppUsbLcd/ProfilDlg.h $
//     >>   
//     >>   1     10.07.01 14:48 Guido
//     >>   
//     >>   1     6.06.01 10:55 Guido
//     >>   
//     >>   2     16.05.01 15:11 Guido
//
///////////////////////////////////////////////////////////////////////////

#if !defined(AFX_PROFILDLG_H__54778FA1_190C_11D3_A2D8_00D05CFFFF04__INCLUDED_)
#define AFX_PROFILDLG_H__54778FA1_190C_11D3_A2D8_00D05CFFFF04__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// ProfilDlg.h : Header-Datei
//

/////////////////////////////////////////////////////////////////////////////
// Dialogfeld CProfilDlg 

class CProfilDlg : public CDialog
{
// Konstruktion
public:
	CProfilDlg(CWnd* pParent = NULL);   // Standardkonstruktor

// Dialogfelddaten
	//{{AFX_DATA(CProfilDlg)
	enum { IDD = IDD_PROFIL_DIALOG };
	CComboBox	m_ctrlPropList;
	CString	m_strDDName;
	//}}AFX_DATA
	BOOL m_boolNewProfil;
	CStringArray m_StringArray;
	CString	m_strCpyName;
	CString	m_oldName;

// �berschreibungen
	// Vom Klassen-Assistenten generierte virtuelle Funktions�berschreibungen
	//{{AFX_VIRTUAL(CProfilDlg)
	public:
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV-Unterst�tzung
	//}}AFX_VIRTUAL

// Implementierung
protected:

	// Generierte Nachrichtenzuordnungsfunktionen
	//{{AFX_MSG(CProfilDlg)
	virtual BOOL OnInitDialog();
	virtual void OnOK();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

private:

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ f�gt unmittelbar vor der vorhergehenden Zeile zus�tzliche Deklarationen ein.

#endif // AFX_PROFILDLG_H__54778FA1_190C_11D3_A2D8_00D05CFFFF04__INCLUDED_
