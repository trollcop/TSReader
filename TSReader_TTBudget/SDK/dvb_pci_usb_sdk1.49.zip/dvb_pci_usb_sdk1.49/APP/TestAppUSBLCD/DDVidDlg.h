//  TT  -  TechnoTrend  -  TT  -  TechnoTrend  -  TT  -  TechnoTrend  -  TT  
//
//
//  (C) TechnoTrend AG 1999-2001
//
//  All rights are reserved. Reproduction in whole or in part is prohibited 
//  without the written consent of the copyright owner. TechnoTrend 
//  reserves the right to make changes without notice at any time.  
//
//
//  TT  -  TechnoTrend  -  TT  -  TechnoTrend  -  TT  -  TechnoTrend  -  TT  
//
///////////////////////////////////////////////////////////////////////////
//
//  Filename:     DDVidDlg.h
//
//  Project(s):   
//
//  Author:       GRi
//
//  Purpose:      Direct Draw Video Dialog
//   
//  Environment:  Win32
//
//  Dev. Tool(s): MSVC 6.0
//
//  Note(s):      
// 
///////////////////////////////////////////////////////////////////////////
// 
//  File History
//
//   $Workfile: DDVidDlg.h $
//   $Revision: 4 $  
//    $Modtime: 21.02.03 16:59 $
//
//   $Log: /DVB-PC/APP/TestAppUsbLcd/DDVidDlg.h $
//     >>   
//     >>   4     21.02.03 17:01 Guido
//     >>   
//     >>   3     25.03.02 18:13 Guido
//     >>   
//     >>   1     25.01.02 9:02 J�rg
//     >>   
//     >>   2     3.08.01 15:51 Guido
//     >>   
//     >>   1     10.07.01 14:48 Guido
//     >>   
//     >>   2     14.06.01 17:52 Guido
//     >>   
//     >>   1     6.06.01 10:55 Guido
//     >>   
//     >>   6     16.05.01 15:11 Guido
//
///////////////////////////////////////////////////////////////////////////
//{{AFX_INCLUDES()
#include "ttdvbctrl1.h"
//}}AFX_INCLUDES

#if !defined(AFX_DDVIDDLG_H__659F8731_EC86_4185_9FA1_45ADF053713B__INCLUDED_)
#define AFX_DDVIDDLG_H__659F8731_EC86_4185_9FA1_45ADF053713B__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

// DDVidDlg.h : Header-Datei
//

#include <DVBCommon.h>
#include <DVBTSFilter.h>

#include "MyRegistry.h"

class CDDVidDlg;

class CMyAudio : public CDVBTSFilter
{
public:
	CMyAudio();
	virtual ~CMyAudio();
	void OnDataArrival(BYTE* Buff, int len);
	CDDVidDlg* m_pDDVidDlg;
};
class CMyVideo : public CDVBTSFilter
{
public:
	CMyVideo();
	virtual ~CMyVideo();
	void OnDataArrival(BYTE* Buff, int len);
	CDDVidDlg* m_pDDVidDlg;

//	CFile m_File;
};

/////////////////////////////////////////////////////////////////////////////
// Dialogfeld CDDVidDlg 

class CDDVidDlg : public CDialog
{
// Konstruktion
public:
	CDDVidDlg(CWnd* pParent = NULL);   // Standardkonstruktor

	void ProfileEvent(const CString& newProfile, const CString& cpyProfile);

// Dialogfelddaten
	//{{AFX_DATA(CDDVidDlg)
	enum { IDD = IDD_DDVID_DLG };
	BOOL	m_bCheckChild;
	CString	m_strAudioPID;
	CString	m_strVideoPID;
	CTTDvbCtrl1	m_Video;
	//}}AFX_DATA


// �berschreibungen
	// Vom Klassen-Assistenten generierte virtuelle Funktions�berschreibungen
	//{{AFX_VIRTUAL(CDDVidDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV-Unterst�tzung
	//}}AFX_VIRTUAL

// Implementierung
protected:

	// Generierte Nachrichtenzuordnungsfunktionen
	//{{AFX_MSG(CDDVidDlg)
	virtual void OnOK();
	virtual void OnCancel();
	afx_msg void OnDDVid();
	virtual BOOL OnInitDialog();
	afx_msg void OnDestroy();
	afx_msg void OnCheckChild();
	afx_msg void OnPaint();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

private:
	HWND m_hVidWnd;

	CMyAudio	m_AudioFilter;
	CMyVideo	m_VideoFilter;

	void SettingsReadFromRegistry();
	void SettingsSaveToRegistry();
	CString m_strActProfile;
	CMyRegistry m_myReg;

public:
//	CFile m_File;
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ f�gt unmittelbar vor der vorhergehenden Zeile zus�tzliche Deklarationen ein.

#endif // AFX_DDVIDDLG_H__659F8731_EC86_4185_9FA1_45ADF053713B__INCLUDED_
