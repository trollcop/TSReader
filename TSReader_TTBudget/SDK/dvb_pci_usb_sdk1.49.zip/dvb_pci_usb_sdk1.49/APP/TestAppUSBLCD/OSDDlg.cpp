//  TT  -  TechnoTrend  -  TT  -  TechnoTrend  -  TT  -  TechnoTrend  -  TT  
//
//
//  (C) TechnoTrend AG 1999-2001
//
//  All rights are reserved. Reproduction in whole or in part is prohibited 
//  without the written consent of the copyright owner. TechnoTrend 
//  reserves the right to make changes without notice at any time.  
//
//
//  TT  -  TechnoTrend  -  TT  -  TechnoTrend  -  TT  -  TechnoTrend  -  TT  
//
///////////////////////////////////////////////////////////////////////////
//
//  Filename:     OSDDlg.cpp
//
//  Project(s):   TestAppDvb
//
//  Author:       GRi
//
//  Purpose:      OSDDlg.cpp
//   
//  Environment:  Win32
//
//  Dev. Tool(s): MSVC 6.0
//
//  Note(s):      
// 
///////////////////////////////////////////////////////////////////////////
// 
//  File History
//
//   $Workfile: OSDDlg.cpp $
//   $Revision: 8 $  
//    $Modtime: 29.11.02 14:58 $
//
//   $Log: /DVB-PC/APP/TestAppUsbLcd/OSDDlg.cpp $
//     >>   
//     >>   8     29.11.02 15:00 Guido
//     >>   
//     >>   7     29.11.02 14:50 Guido
//     >>   
//     >>   6     28.11.02 17:36 Guido
//     >>   
//     >>   5     27.05.02 14:56 Guido
//     >>   
//     >>   4     25.05.02 16:05 Guido
//     >>   
//     >>   3     27.03.02 15:54 Guido
//     >>   
//     >>   2     16.10.01 17:39 Guido
//     >>   
//     >>   1     10.07.01 14:48 Guido
//     >>   
//     >>   1     6.06.01 10:55 Guido
//     >>   
//     >>   9     16.05.01 15:11 Guido
//
///////////////////////////////////////////////////////////////////////////

// OSDDlg.cpp: Implementierungsdatei
//

#include "stdafx.h"
#include "dvbmpe.h"
#include "OSDDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// Dialogfeld COSDDlg 


COSDDlg::COSDDlg(CWnd* pParent /*=NULL*/)
	: CDialog(COSDDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(COSDDlg)
	m_strPipingPID = _T("");
	m_strFN = _T("C:\\TSData.bin");
	//}}AFX_DATA_INIT
}


void COSDDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(COSDDlg)
	DDX_Text(pDX, IDC_PIPING_PID, m_strPipingPID);
	DDX_Text(pDX, IDC_EDIT_FN, m_strFN);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(COSDDlg, CDialog)
	//{{AFX_MSG_MAP(COSDDlg)
	ON_WM_DESTROY()
	ON_BN_CLICKED(IDC_MAC_ADDR, OnMacAddr)
	ON_BN_CLICKED(IDC_MC_LIST, OnMcList)
	ON_BN_CLICKED(IDC_IP_SM, OnIpSm)
	ON_BN_CLICKED(IDC_BUTTON_START, OnButtonStart)
	ON_BN_CLICKED(IDC_BUTTON_STOP, OnButtonStop)
	ON_BN_CLICKED(IDC_BUTTON_IR_ON, OnButtonIrOn)
	ON_BN_CLICKED(IDC_BUTTON_IR_OFF, OnButtonIrOff)
	ON_BN_CLICKED(IDC_VERSIONS, OnGetVersions)
	ON_BN_CLICKED(IDC_BUTTON_TS_START, OnButtonTsStart)
	ON_BN_CLICKED(IDC_BUTTON_TS_STOP, OnButtonTsStop)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// Behandlungsroutinen f�r Nachrichten COSDDlg 

BOOL COSDDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();

	// TODO: Zus�tzliche Initialisierung hier einf�gen
	m_RemoteCtrl.m_pOSDDlg = this;
	
#ifndef _TTDVBLCD
	GetDlgItem( IDC_STATIC_TS )->ShowWindow(SW_HIDE);
	GetDlgItem( IDC_STATIC_FN )->ShowWindow(SW_HIDE);
	GetDlgItem( IDC_BUTTON_TS_START )->ShowWindow(SW_HIDE);
	GetDlgItem( IDC_BUTTON_TS_STOP )->ShowWindow(SW_HIDE);
	GetDlgItem( IDC_EDIT_FN )->ShowWindow(SW_HIDE);
	GetDlgItem( IDC_EDIT_LOST )->ShowWindow(SW_HIDE);
	GetDlgItem( IDC_STATIC_LOST )->ShowWindow(SW_HIDE);
#endif

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX-Eigenschaftenseiten sollten FALSE zur�ckgeben
}

void COSDDlg::OnDestroy() 
{
	CDialog::OnDestroy();
	
	// TODO: Code f�r die Behandlungsroutine f�r Nachrichten hier einf�gen
	
	m_RemoteCtrl.SetRemoteControl(CDVBRemoteControl::IR_NONE);

	m_FilterToFile.StopFilter();

#ifdef _TTDVBLCD
	m_TSRecord.Stop();
#endif
}

BOOL COSDDlg::TimerEvent(void)
{
#ifdef _TTDVBLCD
	static char str[20];
	static DWORD arr[17];
	
	m_BoardControl.GetDriverStatus(arr, 17);
	sprintf(str, "%u", arr[16]);
	SetDlgItemText(IDC_EDIT_LOST, str);
#endif
	return TRUE;
}

void COSDDlg::OnOK() 
{

}

void COSDDlg::OnCancel() 
{

}

BOOL COSDDlg::GetExePath(CString& ExePath)
{

	char path_buffer[_MAX_PATH];
	char drive[_MAX_DRIVE];
	char dir[_MAX_DIR];
   
	if(GetModuleFileName(NULL, path_buffer, _MAX_PATH) > 0)
	{
		_splitpath( path_buffer, drive, dir, NULL, NULL );

		ExePath = drive;
		ExePath += dir;
		return TRUE;
	}
	else
	{
		ExePath = "C:\\";
		return FALSE;
	}
}

void COSDDlg::OnMacAddr() 
{
	DWORD oid, snr;
	
	UpdateData(TRUE);

	if(m_BoardControl.GetMACAddress(oid, snr) != DVB_ERR_NONE)
		MessageBox("Could not get MAC!");
	else
	{
		CString str;
		str.Format("MAC: %06x%06x", oid, snr);
		MessageBox(str, "MAC-Address");
	}
}

void COSDDlg::OnMcList() 
{
	CString strA, strB;
	CDVBBoardControl::MULTICAST_LIST mcl;
	char pf[33];
	UINT i;

	if(m_BoardControl.GetMulticastList(mcl) == DVB_ERR_NONE)
	{
		strB.Format("Multicast-List Entries: %u\n\r", mcl.MulticastListInUse);
		for(i=0; i<mcl.MulticastListInUse; i++)
		{
			strA.Format("MC-MAC: %02x%02x%02x%02x%02x%02x\n\r", mcl.AddressList[i][0],mcl.AddressList[i][1],mcl.AddressList[i][2],mcl.AddressList[i][3],mcl.AddressList[i][4],mcl.AddressList[i][5]);
			strB += strA;
		}
		strA.Format("Packet-Filter: %u\n\r", mcl.PacketFilter);
		strB += strA;
		for(i=0; i<32; i++)
			pf[31-i] = ((mcl.PacketFilter>>i)&0x01) + 0x30;
		pf[32] = 0;
		strB += pf;
		MessageBox(strB);
	}
	else
	{
		MessageBox("Could not read Mulicast-List!");
	}
}

void COSDDlg::OnIpSm() 
{
	DWORD _ip, _sm;
	WORD bp;
	BYTE ip[4], sm[4];

	UpdateData(TRUE);

	if(m_BoardControl.Get_IP_SM_BP(_ip, _sm, bp) != DVB_ERR_NONE)
		MessageBox("Could not get IP!");
	else
	{
		CString str;
		*(DWORD*)ip = _ip;
		*(DWORD*)sm = _sm;
		str.Format("IP-Address: %u.%u.%u.%u, SubnetMask: %u.%u.%u.%u", ip[0],ip[1],ip[2],ip[3], sm[0],sm[1],sm[2],sm[3]);
		MessageBox(str, "IP-Address");
	}
}

void COSDDlg::OnGetVersions() 
{
	DWORD dwDllVer, dwDrvVer;
	
	UpdateData(TRUE);

#ifdef _TTDVBLCD

	if(m_BoardControl.GetVersions(dwDllVer, dwDrvVer) != DVB_ERR_NONE)
		MessageBox("Could not get Versions!");
	else
	{
		CString str;
		str.Format("API-DLL: %x, Driver: %x", dwDllVer, dwDrvVer);
		MessageBox(str, "Versions");
	}

#else // USB
	DWORD dwNwDrvVer;

	if(m_BoardControl.GetVersions(dwDllVer, dwDrvVer, dwNwDrvVer) != DVB_ERR_NONE)
		MessageBox("Could not get Versions!");
	else
	{
		CString str;
		str.Format("API-DLL: %x, Driver: %x, NW-Driver: %x", dwDllVer, dwDrvVer, dwNwDrvVer);
		MessageBox(str, "Versions");
	}

#endif

}

void COSDDlg::OnButtonStart() 
{
	DVB_ERROR err = DVB_ERR_NONE;
	
	UpdateData(TRUE);

	m_FilterToFile.SetFileParams("C:\\PipingData.bin");

	WORD wPID = (WORD)strtoul(m_strPipingPID, NULL, 10);

	err = m_FilterToFile.StartFilter(CDVBTSFilter::PIPING_FILTER, wPID, NULL, NULL, 0);
	//err = m_FilterToFile.StartFilter(CDVBTSFilter::PIPING_FILTER, wPID, NULL, NULL, PIPE_SIZE_1K);
	//err = m_FilterToFile.StartFilter(CDVBTSFilter::PIPING_FILTER, wPID, NULL, NULL, PIPE_SIZE_4K);

	if(err != DVB_ERR_NONE)
		MessageBox("Could not start Piping to File!");
	
}

void COSDDlg::OnButtonStop() 
{
	m_FilterToFile.StopFilter();
}

void COSDDlg::OnButtonIrOn() 
{
	DVB_ERROR err = m_RemoteCtrl.SetRemoteControl(CDVBRemoteControl::IR_RC5);

	if(err != DVB_ERR_NONE)
		MessageBox("RemoteControl wurde nicht eingeschaltet!", "Fehler");
}

void COSDDlg::OnButtonIrOff() 
{
	DVB_ERROR err = m_RemoteCtrl.SetRemoteControl(CDVBRemoteControl::IR_NONE);

	if(err != DVB_ERR_NONE)
		MessageBox("RemoteControl wurde nicht abgeschaltet!", "Fehler");
}

void CMyRemoteCtrl::OnRemoteControlCode(BYTE* Buff, int len)
{
	if(len >= sizeof(WORD))
	{
		WORD wCode = *((WORD*)Buff);

		m_strOut = "";
		m_pOSDDlg->GetDlgItemText(IDC_EDIT_IR_CODE, m_strOut);
		m_pOSDDlg->SetDlgItemText(IDC_EDIT_OLD_IR_CODE, m_strOut);
		
		//m_strOut.Format("%02x", wCode>>8);
		m_strOut.Format("Key(Addr:%u, Code:%x) %s.", RC5_DEVADDR(wCode), RC5_KEYCODE(wCode), (RC5_KEYPUSHED(wCode))?"pressed":"released");
		m_pOSDDlg->SetDlgItemText(IDC_EDIT_IR_CODE, m_strOut);
	}
}

#ifdef _TTDVBLCD

BOOL CMyTSRecord::Start(CString strFileName)
{
	Stop();
	
	if(m_File.Open(strFileName, CFile::modeCreate | CFile::modeWrite))
	{
		if(m_BoardControl.TSRecordOnOff(TRUE))
		{
			if(StartThread(/*THREAD_PRIORITY_HIGHEST*/))
			{
				return TRUE;
			}
		}
	}
	return FALSE;
}

BOOL CMyTSRecord::Stop(void)
{
	CFile f;
	CString s;
	DWORD sec;
	DWORD arr[17];

	m_BoardControl.TSRecordOnOff(FALSE);

	StopThread();

	if(m_cnt && m_tc)
	{
		s = m_File.GetFilePath();
		s += ".info";

		if(f.Open(s, CFile::modeCreate | CFile::modeWrite))
		{
			sec = (m_tc/1000)?(m_tc/1000):1;
			s.Format("Time (s): %u, Length (Byte): %u, DataRate (Byte/s): %u\r\n", sec, m_cnt, m_cnt/sec);
			f.Write((LPCSTR)s, s.GetLength());

			arr[16] = 0;
			m_BoardControl.GetDriverStatus(arr, 17);
			s.Format("Lost Blocks: %u, Lost Bytes: %u\r\n", arr[16], 96256*arr[16]);
			f.Write((LPCSTR)s, s.GetLength());

			f.Close();
		}
		m_cnt = m_tc = 0;
	}

	if(m_File.m_hFile != CFile::hFileNull)
		m_File.Close();

	return TRUE;
}

BOOL CMyTSRecord::Run()
{
	int retlen;
	BYTE* Buf;

	Buf = new BYTE[100000]; // 96256
	if(! Buf)
		return FALSE;

	m_cnt = 0;
	m_tc = GetTickCount();

	while(IsRunning())
	{
		retlen = m_BoardControl.TSRecordRead(Buf, 100000);
		
		if((retlen > 0) && (m_File.m_hFile != CFile::hFileNull))
		{
			m_File.Write(Buf, retlen);
			m_cnt += retlen;
		}
		else
			Sleep(20);
	}

	if(Buf)
		delete Buf;

	m_tc = GetTickCount() - m_tc;

	return FALSE;
}

#endif //_TTDVBLCD

void COSDDlg::OnButtonTsStart() 
{
	UpdateData(TRUE);
#ifdef _TTDVBLCD

	if( ! m_TSRecord.Start(m_strFN))
		MessageBox("TS-Record Start failed!", "Error");
#endif
}

void COSDDlg::OnButtonTsStop() 
{
#ifdef _TTDVBLCD
	m_TSRecord.Stop();
#endif
}

