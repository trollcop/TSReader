//  TT  -  TechnoTrend  -  TT  -  TechnoTrend  -  TT  -  TechnoTrend  -  TT  
//
//
//  (C) TechnoTrend AG 1999-2001
//
//  All rights are reserved. Reproduction in whole or in part is prohibited 
//  without the written consent of the copyright owner. TechnoTrend 
//  reserves the right to make changes without notice at any time.  
//
//
//  TT  -  TechnoTrend  -  TT  -  TechnoTrend  -  TT  -  TechnoTrend  -  TT  
//
///////////////////////////////////////////////////////////////////////////
//
//  Filename:     LnbDlg.cpp
//
//  Project(s):   TestAppDvb
//
//  Author:       GRi
//
//  Purpose:      LnbDlg.cpp
//   
//  Environment:  Win32
//
//  Dev. Tool(s): MSVC 6.0
//
//  Note(s):      
// 
///////////////////////////////////////////////////////////////////////////
// 
//  File History
//
//   $Workfile: LnbDlg.cpp $
//   $Revision: 1 $  
//    $Modtime: 29.05.01 9:18 $
//
//   $Log: /DVB-PC/APP/TestAppUsbLcd/LnbDlg.cpp $
//     >>   
//     >>   1     10.07.01 14:48 Guido
//     >>   
//     >>   1     6.06.01 10:55 Guido
//     >>   
//     >>   2     16.05.01 15:11 Guido
//
///////////////////////////////////////////////////////////////////////////

// LnbDlg.cpp: Implementierungsdatei
//

#include "stdafx.h"
#include "dvbmpe.h"
#include "LnbDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// Dialogfeld CLnbDlg 


CLnbDlg::CLnbDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CLnbDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CLnbDlg)
	m_iDiseqc = 0;
	m_iSimplePosition = 0;
	m_iMultiOption = 0;
	m_iMultiPosition = 0;
	m_strLOF1 = _T("9750000");
	m_strLOF2 = _T("10600000");
	m_strLOFSW = _T("11700000");
	m_boolLNBPower = TRUE;
	//}}AFX_DATA_INIT
}

void CLnbDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CLnbDlg)
	DDX_Radio(pDX, IDC_NONE, m_iDiseqc);
	DDX_Radio(pDX, IDC_SIMPLE_A, m_iSimplePosition);
	DDX_Radio(pDX, IDC_MULTI_OA, m_iMultiOption);
	DDX_Radio(pDX, IDC_MULTI_PA, m_iMultiPosition);
	DDX_Text(pDX, IDC_LOF1, m_strLOF1);
	DDX_Text(pDX, IDC_LOF2, m_strLOF2);
	DDX_Text(pDX, IDC_LOF_SW, m_strLOFSW);
	DDX_Check(pDX, IDC_LNB_POWER, m_boolLNBPower);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CLnbDlg, CDialog)
	//{{AFX_MSG_MAP(CLnbDlg)
	ON_BN_CLICKED(IDC_NONE, OnDiseqcNone)
	ON_BN_CLICKED(IDC_SIMPLE, OnDiseqcSimple)
	ON_BN_CLICKED(IDC_MULTI, OnDiseqcMulti)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// Behandlungsroutinen f�r Nachrichten CLnbDlg 

BOOL CLnbDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Zus�tzliche Initialisierung hier einf�gen

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX-Eigenschaftenseiten sollten FALSE zur�ckgeben
}

void CLnbDlg::OnDiseqcNone() // DiSEqC
{
	GetDlgItem( IDC_STATIC_POS )->EnableWindow(FALSE);
	GetDlgItem( IDC_STATIC_OPT )->EnableWindow(FALSE);
	GetDlgItem( IDC_MULTI_PA )->EnableWindow(FALSE);
	GetDlgItem( IDC_MULTI_OA )->EnableWindow(FALSE);
	GetDlgItem( IDC_MULTI_PB )->EnableWindow(FALSE);
	GetDlgItem( IDC_MULTI_OB )->EnableWindow(FALSE);
	GetDlgItem( IDC_SIMPLE_A )->EnableWindow(FALSE);
	GetDlgItem( IDC_SIMPLE_B )->EnableWindow(FALSE);
}

void CLnbDlg::OnDiseqcSimple() // DiSEqC
{
	GetDlgItem( IDC_STATIC_POS )->EnableWindow(FALSE);
	GetDlgItem( IDC_STATIC_OPT )->EnableWindow(FALSE);
	GetDlgItem( IDC_MULTI_PA )->EnableWindow(FALSE);
	GetDlgItem( IDC_MULTI_OA )->EnableWindow(FALSE);
	GetDlgItem( IDC_MULTI_PB )->EnableWindow(FALSE);
	GetDlgItem( IDC_MULTI_OB )->EnableWindow(FALSE);
	GetDlgItem( IDC_SIMPLE_A )->EnableWindow(TRUE);
	GetDlgItem( IDC_SIMPLE_B )->EnableWindow(TRUE);
}

void CLnbDlg::OnDiseqcMulti() // DiSEqC
{
	GetDlgItem( IDC_STATIC_POS )->EnableWindow(TRUE);
	GetDlgItem( IDC_STATIC_OPT )->EnableWindow(TRUE);
	GetDlgItem( IDC_MULTI_PA )->EnableWindow(TRUE);
	GetDlgItem( IDC_MULTI_OA )->EnableWindow(TRUE);
	GetDlgItem( IDC_MULTI_PB )->EnableWindow(TRUE);
	GetDlgItem( IDC_MULTI_OB )->EnableWindow(TRUE);
	GetDlgItem( IDC_SIMPLE_A )->EnableWindow(FALSE);
	GetDlgItem( IDC_SIMPLE_B )->EnableWindow(FALSE);
}

void CLnbDlg::OnOK() 
{

}

void CLnbDlg::OnCancel() 
{

}

void CLnbDlg::GetValues(int& iDiseqc, int& iSPos, int& iMOpt, int& iMPos, DWORD& dwLOF1, DWORD& dwLOF2, DWORD& dwLOFSW, BOOL& bLNBPwr)
{
	UpdateData(TRUE);

	iDiseqc = m_iDiseqc;
	iSPos   = m_iSimplePosition;
	iMOpt   = m_iMultiOption;
	iMPos   = m_iMultiPosition;
	dwLOF1  = strtoul(m_strLOF1, NULL, 10);
	dwLOF2  = strtoul(m_strLOF2, NULL, 10);
	dwLOFSW = strtoul(m_strLOFSW, NULL, 10);
	bLNBPwr = m_boolLNBPower;
}

void CLnbDlg::SetValues(int iDiseqc, int iSPos, int iMOpt, int iMPos, DWORD dwLOF1, DWORD dwLOF2, DWORD dwLOFSW, BOOL bLNBPwr)
{
	m_iDiseqc = iDiseqc;
	m_iSimplePosition = iSPos;
	m_iMultiOption = iMOpt;
	m_iMultiPosition = iMPos;
	m_strLOF1.Format("%u", dwLOF1);
	m_strLOF2.Format("%u", dwLOF2);
	m_strLOFSW.Format("%u", dwLOFSW);
	m_boolLNBPower = bLNBPwr;

	if(m_iDiseqc == 0)
		OnDiseqcNone();
	else if(m_iDiseqc == 1)
		OnDiseqcSimple();
	else if(m_iDiseqc == 2)
		OnDiseqcMulti();

	UpdateData(FALSE);
}

