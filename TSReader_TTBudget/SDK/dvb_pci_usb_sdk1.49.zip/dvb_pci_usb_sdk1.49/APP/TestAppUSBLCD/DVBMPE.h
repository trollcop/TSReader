//  TT  -  TechnoTrend  -  TT  -  TechnoTrend  -  TT  -  TechnoTrend  -  TT  
//
//
//  (C) TechnoTrend AG 1999-2001
//
//  All rights are reserved. Reproduction in whole or in part is prohibited 
//  without the written consent of the copyright owner. TechnoTrend 
//  reserves the right to make changes without notice at any time.  
//
//
//  TT  -  TechnoTrend  -  TT  -  TechnoTrend  -  TT  -  TechnoTrend  -  TT  
//
///////////////////////////////////////////////////////////////////////////
//
//  Filename:     DVBMPE.h
//
//  Project(s):   TestAppDvb
//
//  Author:       GRi
//
//  Purpose:      Main Application
//   
//  Environment:  Win32
//
//  Dev. Tool(s): MSVC 6.0
//
//  Note(s):      
// 
///////////////////////////////////////////////////////////////////////////
// 
//  File History
//
//   $Workfile: DVBMPE.h $
//   $Revision: 1 $  
//    $Modtime: 29.05.01 9:18 $
//
//   $Log: /DVB-PC/APP/TestAppUsbLcd/DVBMPE.h $
//     >>   
//     >>   1     10.07.01 14:48 Guido
//     >>   
//     >>   1     6.06.01 10:55 Guido
//     >>   
//     >>   2     16.05.01 15:11 Guido
//
///////////////////////////////////////////////////////////////////////////

// DVBMPE.h : Haupt-Header-Datei f�r die Anwendung DVBMPESAT
//

#if !defined(AFX_DVBMPESAT_H__413A6E02_F8D0_11D2_A2D8_00104B48BC54__INCLUDED_)
#define AFX_DVBMPESAT_H__413A6E02_F8D0_11D2_A2D8_00104B48BC54__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// Hauptsymbole

//#define DVBMPE_REGISTRY_START_STRING "SOFTWARE\\TechnoTrend\\DVBMPE\\"
//CString DVBMPE_REGISTRY_START_STRING = "SOFTWARE\\TechnoTrend\\DVBMPE";
#define DVBMPE_REGISTRY_DEFAULT_PROFILE "Standard"


/////////////////////////////////////////////////////////////////////////////
// CDVBMPEApp:
// Siehe DVBMPESAT.cpp f�r die Implementierung dieser Klasse
//
class CDVBMPEApp : public CWinApp
{
public:
	CDVBMPEApp();

// �berladungen
	// Vom Klassenassistenten generierte �berladungen virtueller Funktionen
	//{{AFX_VIRTUAL(CDVBMPEApp)
	public:
	virtual BOOL InitInstance();
	virtual void WinHelp(DWORD dwData, UINT nCmd = HELP_CONTEXT);
	//}}AFX_VIRTUAL

// Implementierung

	//{{AFX_MSG(CDVBMPEApp)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ f�gt unmittelbar vor der vorhergehenden Zeile zus�tzliche Deklarationen ein.

#endif // !defined(AFX_DVBMPESAT_H__413A6E02_F8D0_11D2_A2D8_00104B48BC54__INCLUDED_)
