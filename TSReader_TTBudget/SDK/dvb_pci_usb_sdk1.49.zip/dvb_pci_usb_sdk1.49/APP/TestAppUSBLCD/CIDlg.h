#if !defined(AFX_CIDLG_H__C7EA9978_DE17_4D92_B23A_4D1EFEDA824A__INCLUDED_)
#define AFX_CIDLG_H__C7EA9978_DE17_4D92_B23A_4D1EFEDA824A__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// CIDlg.h : Header-Datei
//

#ifdef _TTDVBLCD

#include "MyCommonInterface.h"

/////////////////////////////////////////////////////////////////////////////
// Dialogfeld CCIDlg 

class CCIDlg : public CDialog
{
	friend CMyCommonInterface;

// Konstruktion
public:
	CCIDlg(CWnd* pParent = NULL);   // Standardkonstruktor

// Dialogfelddaten
	//{{AFX_DATA(CCIDlg)
	enum { IDD = IDD_CI_DLG };
	CString	m_strPNR;
	BOOL	m_bVideoPort;
	//}}AFX_DATA


// �berschreibungen
	// Vom Klassen-Assistenten generierte virtuelle Funktions�berschreibungen
	//{{AFX_VIRTUAL(CCIDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV-Unterst�tzung
	//}}AFX_VIRTUAL

// Implementierung
protected:

	// Generierte Nachrichtenzuordnungsfunktionen
	//{{AFX_MSG(CCIDlg)
	virtual void OnOK();
	virtual void OnCancel();
	afx_msg void OnOpenCi();
	afx_msg void OnCloseCi();
	afx_msg void OnSendAns();
	afx_msg void OnCancelSend();
	afx_msg void OnSetProgramme();
	afx_msg void OnSlot0();
	afx_msg void OnSlot1();
	virtual BOOL OnInitDialog();
	afx_msg void OnDestroy();
	//}}AFX_MSG
	afx_msg	void OnKeyPressed(UINT nID);

	DECLARE_MESSAGE_MAP()

private:
	void MarkActiveCAM();

	CMyCommonInterface m_CI;
	int	m_ActCAM;
};

#endif // _TTDVBLCD


//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ f�gt unmittelbar vor der vorhergehenden Zeile zus�tzliche Deklarationen ein.

#endif // AFX_CIDLG_H__C7EA9978_DE17_4D92_B23A_4D1EFEDA824A__INCLUDED_
