# Microsoft Developer Studio Project File - Name="TestAppUsbLcd" - Package Owner=<4>
# Microsoft Developer Studio Generated Build File, Format Version 6.00
# ** NICHT BEARBEITEN **

# TARGTYPE "Win32 (x86) Application" 0x0101

CFG=TestAppUsbLcd - Win32 TestAppUSB Debug
!MESSAGE Dies ist kein g�ltiges Makefile. Zum Erstellen dieses Projekts mit NMAKE
!MESSAGE verwenden Sie den Befehl "Makefile exportieren" und f�hren Sie den Befehl
!MESSAGE 
!MESSAGE NMAKE /f "TestAppUsbLcd.mak".
!MESSAGE 
!MESSAGE Sie k�nnen beim Ausf�hren von NMAKE eine Konfiguration angeben
!MESSAGE durch Definieren des Makros CFG in der Befehlszeile. Zum Beispiel:
!MESSAGE 
!MESSAGE NMAKE /f "TestAppUsbLcd.mak" CFG="TestAppUsbLcd - Win32 TestAppUSB Debug"
!MESSAGE 
!MESSAGE F�r die Konfiguration stehen zur Auswahl:
!MESSAGE 
!MESSAGE "TestAppUsbLcd - Win32 TestAppLCD Release" (basierend auf  "Win32 (x86) Application")
!MESSAGE "TestAppUsbLcd - Win32 TestAppLCD Debug" (basierend auf  "Win32 (x86) Application")
!MESSAGE "TestAppUsbLcd - Win32 TestAppUSB Release" (basierend auf  "Win32 (x86) Application")
!MESSAGE "TestAppUsbLcd - Win32 TestAppUSB Debug" (basierend auf  "Win32 (x86) Application")
!MESSAGE 

# Begin Project
# PROP AllowPerConfigDependencies 0
# PROP Scc_ProjName ""
# PROP Scc_LocalPath ""
CPP=cl.exe
MTL=midl.exe
RSC=rc.exe

!IF  "$(CFG)" == "TestAppUsbLcd - Win32 TestAppLCD Release"

# PROP BASE Use_MFC 6
# PROP BASE Use_Debug_Libraries 0
# PROP BASE Output_Dir "TestAppUsbLcd___Win32_TestAppLCD_Release"
# PROP BASE Intermediate_Dir "TestAppUsbLcd___Win32_TestAppLCD_Release"
# PROP BASE Ignore_Export_Lib 0
# PROP BASE Target_Dir ""
# PROP Use_MFC 6
# PROP Use_Debug_Libraries 0
# PROP Output_Dir "TestAppLCD_Release"
# PROP Intermediate_Dir "TestAppLCD_Release"
# PROP Ignore_Export_Lib 0
# PROP Target_Dir ""
# ADD BASE CPP /nologo /MD /W3 /GX /O2 /I "..\..\API\HighEnd\include" /I "..\..\API\Common\include" /D "WIN32" /D "NDEBUG" /D "_WINDOWS" /D "_MBCS" /D "_TECHNOTREND_" /D "_AFXDLL" /FAcs /FR /Yu"stdafx.h" /FD /c
# ADD CPP /nologo /MD /W3 /GX /O2 /I "..\..\API\Budget\include" /I "..\..\API\Common\include" /D "WIN32" /D "NDEBUG" /D "_WINDOWS" /D "_MBCS" /D "_TECHNOTREND_" /D "_AFXDLL" /D "_TTDVBLCD" /FAcs /FR /Yu"stdafx.h" /FD /c
# ADD BASE MTL /nologo /D "NDEBUG" /mktyplib203 /win32
# ADD MTL /nologo /D "NDEBUG" /mktyplib203 /win32
# ADD BASE RSC /l 0x407 /d "NDEBUG" /d "_TECHNOTREND_" /d "_AFXDLL"
# ADD RSC /l 0x407 /d "NDEBUG" /d "_TECHNOTREND_" /d "_AFXDLL"
BSC32=bscmake.exe
# ADD BASE BSC32 /nologo
# ADD BSC32 /nologo
LINK32=link.exe
# ADD BASE LINK32 ..\..\API\HighEnd\lib\ttdvbacc.lib winmm.lib rasapi32.lib /nologo /subsystem:windows /map /machine:I386 /out:".\Release/testappUsbLcd.exe"
# ADD LINK32 ..\..\API\Budget\lib\ttlcdacc.lib winmm.lib rasapi32.lib /nologo /subsystem:windows /map /machine:I386 /out:".\TestAppLCD_Release/testappLcd2.exe"
# Begin Special Build Tool
SOURCE="$(InputPath)"
PostBuild_Cmds=copy .\TestAppLCD_Release\testappLcd2.exe ..\..\BIN\Budget\release
# End Special Build Tool

!ELSEIF  "$(CFG)" == "TestAppUsbLcd - Win32 TestAppLCD Debug"

# PROP BASE Use_MFC 6
# PROP BASE Use_Debug_Libraries 1
# PROP BASE Output_Dir "TestAppUsbLcd___Win32_TestAppLCD_Debug"
# PROP BASE Intermediate_Dir "TestAppUsbLcd___Win32_TestAppLCD_Debug"
# PROP BASE Ignore_Export_Lib 0
# PROP BASE Target_Dir ""
# PROP Use_MFC 6
# PROP Use_Debug_Libraries 1
# PROP Output_Dir "TestAppLCD_Debug"
# PROP Intermediate_Dir "TestAppLCD_Debug"
# PROP Ignore_Export_Lib 0
# PROP Target_Dir ""
# ADD BASE CPP /nologo /MDd /W3 /Gm /GX /ZI /Od /I "..\..\API\HighEnd\include" /I "..\..\API\Common\include" /D "WIN32" /D "_DEBUG" /D "_WINDOWS" /D "_AFXDLL" /D "_MBCS" /D "_TECHNOTREND_" /FR /Yu"stdafx.h" /FD /GZ /c
# ADD CPP /nologo /MDd /W3 /Gm /GX /ZI /Od /I "..\..\API\Budget\include" /I "..\..\API\Common\include" /D "WIN32" /D "_DEBUG" /D "_WINDOWS" /D "_AFXDLL" /D "_MBCS" /D "_TECHNOTREND_" /D "_TTDVBLCD" /FR /Yu"stdafx.h" /FD /GZ /c
# ADD BASE MTL /nologo /D "_DEBUG" /mktyplib203 /win32
# ADD MTL /nologo /D "_DEBUG" /mktyplib203 /win32
# ADD BASE RSC /l 0x407 /d "_DEBUG" /d "_AFXDLL" /d "_TECHNOTREND_"
# ADD RSC /l 0x407 /d "_DEBUG" /d "_AFXDLL" /d "_TECHNOTREND_"
BSC32=bscmake.exe
# ADD BASE BSC32 /nologo
# ADD BSC32 /nologo
LINK32=link.exe
# ADD BASE LINK32 ..\..\API\HighEnd\lib\ttdvbacc.lib winmm.lib rasapi32.lib /nologo /subsystem:windows /debug /machine:I386 /out:".\Debug/testappUsbLcd.exe" /pdbtype:sept
# ADD LINK32 ..\..\API\Budget\lib\ttlcdacc.lib winmm.lib rasapi32.lib /nologo /subsystem:windows /debug /machine:I386 /out:".\TestAppLCD_Debug/testappLcd2.exe" /pdbtype:sept
# Begin Special Build Tool
SOURCE="$(InputPath)"
PostBuild_Cmds=copy .\TestAppLCD_Debug\testappLcd2.exe ..\..\BIN\Budget\debug
# End Special Build Tool

!ELSEIF  "$(CFG)" == "TestAppUsbLcd - Win32 TestAppUSB Release"

# PROP BASE Use_MFC 6
# PROP BASE Use_Debug_Libraries 0
# PROP BASE Output_Dir "TestAppUsbLcd___Win32_TestAppUSB_Release"
# PROP BASE Intermediate_Dir "TestAppUsbLcd___Win32_TestAppUSB_Release"
# PROP BASE Ignore_Export_Lib 0
# PROP BASE Target_Dir ""
# PROP Use_MFC 6
# PROP Use_Debug_Libraries 0
# PROP Output_Dir "TestAppUSB_Release"
# PROP Intermediate_Dir "TestAppUSB_Release"
# PROP Ignore_Export_Lib 0
# PROP Target_Dir ""
# ADD BASE CPP /nologo /MD /W3 /GX /O2 /I "..\..\API\HighEnd\include" /I "..\..\API\Common\include" /D "WIN32" /D "NDEBUG" /D "_WINDOWS" /D "_MBCS" /D "_TECHNOTREND_" /D "_AFXDLL" /FAcs /FR /Yu"stdafx.h" /FD /c
# ADD CPP /nologo /MD /W3 /GX /O2 /I "..\..\API\USB\include" /I "..\..\API\Common\include" /D "WIN32" /D "NDEBUG" /D "_WINDOWS" /D "_MBCS" /D "_TECHNOTREND_" /D "_AFXDLL" /D "_TTDVBUSB" /FAcs /FR /Yu"stdafx.h" /FD /c
# ADD BASE MTL /nologo /D "NDEBUG" /mktyplib203 /win32
# ADD MTL /nologo /D "NDEBUG" /mktyplib203 /win32
# ADD BASE RSC /l 0x407 /d "NDEBUG" /d "_TECHNOTREND_" /d "_AFXDLL"
# ADD RSC /l 0x407 /d "NDEBUG" /d "_TECHNOTREND_" /d "_AFXDLL"
BSC32=bscmake.exe
# ADD BASE BSC32 /nologo
# ADD BSC32 /nologo
LINK32=link.exe
# ADD BASE LINK32 ..\..\API\HighEnd\lib\ttdvbacc.lib winmm.lib rasapi32.lib /nologo /subsystem:windows /map /machine:I386 /out:".\Release/testappUsbLcd.exe"
# ADD LINK32 ..\..\API\USB\lib\ttusbacc.lib winmm.lib rasapi32.lib /nologo /subsystem:windows /map /machine:I386 /out:".\TestAppUSB_Release/testappUsb2.exe"
# Begin Special Build Tool
SOURCE="$(InputPath)"
PostBuild_Cmds=copy .\TestAppUSB_Release\testappUsb2.exe ..\..\BIN\USB\release
# End Special Build Tool

!ELSEIF  "$(CFG)" == "TestAppUsbLcd - Win32 TestAppUSB Debug"

# PROP BASE Use_MFC 6
# PROP BASE Use_Debug_Libraries 1
# PROP BASE Output_Dir "TestAppUsbLcd___Win32_TestAppUSB_Debug"
# PROP BASE Intermediate_Dir "TestAppUsbLcd___Win32_TestAppUSB_Debug"
# PROP BASE Ignore_Export_Lib 0
# PROP BASE Target_Dir ""
# PROP Use_MFC 6
# PROP Use_Debug_Libraries 1
# PROP Output_Dir "TestAppUSB_Debug"
# PROP Intermediate_Dir "TestAppUSB_Debug"
# PROP Ignore_Export_Lib 0
# PROP Target_Dir ""
# ADD BASE CPP /nologo /MDd /W3 /Gm /GX /ZI /Od /I "..\..\API\HighEnd\include" /I "..\..\API\Common\include" /D "WIN32" /D "_DEBUG" /D "_WINDOWS" /D "_AFXDLL" /D "_MBCS" /D "_TECHNOTREND_" /FR /Yu"stdafx.h" /FD /GZ /c
# ADD CPP /nologo /MDd /W3 /Gm /GX /ZI /Od /I "..\..\API\USB\include" /I "..\..\API\Common\include" /D "WIN32" /D "_DEBUG" /D "_WINDOWS" /D "_AFXDLL" /D "_MBCS" /D "_TECHNOTREND_" /D "_TTDVBUSB" /FR /Yu"stdafx.h" /FD /GZ /c
# ADD BASE MTL /nologo /D "_DEBUG" /mktyplib203 /win32
# ADD MTL /nologo /D "_DEBUG" /mktyplib203 /win32
# ADD BASE RSC /l 0x407 /d "_DEBUG" /d "_AFXDLL" /d "_TECHNOTREND_"
# ADD RSC /l 0x407 /d "_DEBUG" /d "_AFXDLL" /d "_TECHNOTREND_"
BSC32=bscmake.exe
# ADD BASE BSC32 /nologo
# ADD BSC32 /nologo
LINK32=link.exe
# ADD BASE LINK32 ..\..\API\HighEnd\lib\ttdvbacc.lib winmm.lib rasapi32.lib /nologo /subsystem:windows /debug /machine:I386 /out:".\Debug/testappUsbLcd.exe" /pdbtype:sept
# ADD LINK32 ..\..\API\USB\lib\ttusbacc.lib winmm.lib rasapi32.lib /nologo /subsystem:windows /debug /machine:I386 /out:".\TestAppUSB_Debug/testappUsb2.exe" /pdbtype:sept
# Begin Special Build Tool
SOURCE="$(InputPath)"
PostBuild_Cmds=copy .\TestAppUSB_Debug\testappUsb2.exe ..\..\BIN\USB\debug
# End Special Build Tool

!ENDIF 

# Begin Target

# Name "TestAppUsbLcd - Win32 TestAppLCD Release"
# Name "TestAppUsbLcd - Win32 TestAppLCD Debug"
# Name "TestAppUsbLcd - Win32 TestAppUSB Release"
# Name "TestAppUsbLcd - Win32 TestAppUSB Debug"
# Begin Group "Quellcodedateien"

# PROP Default_Filter "cpp;c;cxx;rc;def;r;odl;idl;hpj;bat"
# Begin Source File

SOURCE=.\CIDlg.cpp
# End Source File
# Begin Source File

SOURCE=.\DDVidDlg.cpp
# End Source File
# Begin Source File

SOURCE=.\DeviceSelection.cpp
# End Source File
# Begin Source File

SOURCE=.\DVBMPE.cpp
# End Source File
# Begin Source File

SOURCE=.\DVBMPE.rc
# End Source File
# Begin Source File

SOURCE=.\DVBMPEDlg.cpp
# End Source File
# Begin Source File

SOURCE=.\FilterDlg.cpp
# End Source File
# Begin Source File

SOURCE=.\GradientProgressCtrl.cpp
# End Source File
# Begin Source File

SOURCE=.\LnbDlg.cpp
# End Source File
# Begin Source File

SOURCE=.\MultiDLG.cpp
# End Source File
# Begin Source File

SOURCE=.\MyCommonInterface.cpp
# End Source File
# Begin Source File

SOURCE=.\MyRegistry.cpp
# End Source File
# Begin Source File

SOURCE=.\OSDDlg.cpp
# End Source File
# Begin Source File

SOURCE=.\ProfilDlg.cpp
# End Source File
# Begin Source File

SOURCE=.\StdAfx.cpp
# ADD BASE CPP /Yc"stdafx.h"
# ADD CPP /Yc"stdafx.h"
# End Source File
# Begin Source File

SOURCE=.\TeletextDlg.cpp
# End Source File
# Begin Source File

SOURCE=.\ttdvbctrl1.cpp
# End Source File
# Begin Source File

SOURCE=.\TunerDlg.cpp
# End Source File
# Begin Source File

SOURCE=.\WorkerThread.cpp
# End Source File
# Begin Source File

SOURCE=.\XTabCtrl.cpp
# End Source File
# End Group
# Begin Group "Header-Dateien"

# PROP Default_Filter "h;hpp;hxx;hm;inl"
# Begin Source File

SOURCE=.\CIDlg.h
# End Source File
# Begin Source File

SOURCE=.\DDVidDlg.h
# End Source File
# Begin Source File

SOURCE=.\DeviceSelection.h
# End Source File
# Begin Source File

SOURCE=.\DVBMPE.h
# End Source File
# Begin Source File

SOURCE=.\DVBMPEDlg.h
# End Source File
# Begin Source File

SOURCE=.\FilterDlg.h
# End Source File
# Begin Source File

SOURCE=.\GradientProgressCtrl.h
# End Source File
# Begin Source File

SOURCE=.\LnbDlg.h
# End Source File
# Begin Source File

SOURCE=.\MultiDLG.h
# End Source File
# Begin Source File

SOURCE=.\MyCommonInterface.h
# End Source File
# Begin Source File

SOURCE=.\MyRegistry.h
# End Source File
# Begin Source File

SOURCE=.\OSDDlg.h
# End Source File
# Begin Source File

SOURCE=.\ProfilDlg.h
# End Source File
# Begin Source File

SOURCE=.\Resource.h
# End Source File
# Begin Source File

SOURCE=.\StdAfx.h
# End Source File
# Begin Source File

SOURCE=.\TeletextDlg.h
# End Source File
# Begin Source File

SOURCE=.\ttdvbctrl1.h
# End Source File
# Begin Source File

SOURCE=.\TunerDlg.h
# End Source File
# Begin Source File

SOURCE=.\WorkerThread.h
# End Source File
# Begin Source File

SOURCE=.\XTabCtrl.h
# End Source File
# End Group
# Begin Group "Ressourcendateien"

# PROP Default_Filter "ico;cur;bmp;dlg;rc2;rct;bin;rgs;gif;jpg;jpeg;jpe"
# Begin Source File

SOURCE=.\res\DVBMPE.rc2
# End Source File
# Begin Source File

SOURCE=.\RES\DVBSample.ico
# End Source File
# Begin Source File

SOURCE=.\res\icon_data.ico
# End Source File
# Begin Source File

SOURCE=.\res\icon_err.ico
# End Source File
# Begin Source File

SOURCE=.\res\icon_ok.ico
# End Source File
# End Group
# End Target
# End Project
# Section TestAppUsbLcd : {6EA1B9C1-F41E-4F0B-AA05-C504BD12BEB9}
# 	2:21:DefaultSinkHeaderFile:ttdvbctrl.h
# 	2:16:DefaultSinkClass:CTTDvbCtrl
# End Section
# Section TestAppUsbLcd : {0FC8C2D4-7FF8-4D22-803C-EFB14D522F16}
# 	2:5:Class:CTTDvbCtrl
# 	2:10:HeaderFile:ttdvbctrl.h
# 	2:8:ImplFile:ttdvbctrl.cpp
# End Section
