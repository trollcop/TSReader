//  TT  -  TechnoTrend  -  TT  -  TechnoTrend  -  TT  -  TechnoTrend  -  TT  
//
//
//  (C) TechnoTrend AG 1999-2001
//
//  All rights are reserved. Reproduction in whole or in part is prohibited 
//  without the written consent of the copyright owner. TechnoTrend 
//  reserves the right to make changes without notice at any time.  
//
//
//  TT  -  TechnoTrend  -  TT  -  TechnoTrend  -  TT  -  TechnoTrend  -  TT  
//
///////////////////////////////////////////////////////////////////////////
//
//  Filename:     DVBMPEDlg.cpp
//
//  Project(s):   TestAppDvb
//
//  Author:       GRi
//
//  Purpose:      DVBMPEDlg.cpp
//   
//  Environment:  Win32
//
//  Dev. Tool(s): MSVC 6.0
//
//  Note(s):      
// 
///////////////////////////////////////////////////////////////////////////
// 
//  File History
//
//   $Workfile: DVBMPEDlg.cpp $
//   $Revision: 7 $  
//    $Modtime: 21.02.03 16:48 $
//
//   $Log: /DVB-PC/APP/TestAppUsbLcd/DVBMPEDlg.cpp $
//     >>   
//     >>   7     21.02.03 17:01 Guido
//     >>   
//     >>   6     6.02.03 16:39 Guido
//     >>   
//     >>   5     28.11.02 17:36 Guido
//     >>   
//     >>   4     28.03.02 17:12 Guido
//     >>   
//     >>   3     13.03.02 14:10 Oleh
//     >>   
//     >>   2     3.08.01 15:51 Guido
//     >>   
//     >>   1     10.07.01 14:48 Guido
//     >>   
//     >>   1     6.06.01 10:55 Guido
//     >>   
//     >>   16    17.05.01 14:07 Guido
//     >>   
//     >>   15    16.05.01 15:11 Guido
//
///////////////////////////////////////////////////////////////////////////

// DVBMPEDlg.cpp : Implementierungsdatei
//

#include "stdafx.h"
#include "DVBMPE.h"
#include "DVBMPEDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

extern CString DVBMPE_REGISTRY_START_STRING;

/////////////////////////////////////////////////////////////////////////////
// CDVBMPEDlg Dialogfeld

CDVBMPEDlg::CDVBMPEDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CDVBMPEDlg::IDD, pParent)
{
	m_pTunerDlg    = NULL;
	m_pLnbDlg      = NULL;
	m_pFilterDlg   = NULL;
	m_pTeletextDlg = NULL;
	m_pMultiDlg    = NULL;
	m_pOsdDlg      = NULL;
	m_pDDVidDlg    = NULL;
#ifdef _TTDVBLCD
	m_pCIDlg       = NULL;
#endif

	m_FE_Type = CDVBFrontend::FE_UNKNOWN;

	m_nSelfTest = 0;

	m_hHandleNotification = NULL;
	m_hDevice = INVALID_HANDLE_VALUE;

	//{{AFX_DATA_INIT(CDVBMPEDlg)
	//}}AFX_DATA_INIT
	// Beachten Sie, dass LoadIcon unter Win32 keinen nachfolgenden DestroyIcon-Aufruf ben�tigt
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CDVBMPEDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDVBMPEDlg)
	DDX_Control(pDX, IDC_STATE_ICON, m_ctrlStateIcon);
	DDX_Control(pDX, IDC_PROFILE_LIST, m_ctrlProfileList);
	DDX_Control(pDX, IDC_TAB, m_ctrlTab);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CDVBMPEDlg, CDialog)
	ON_WM_DEVICECHANGE()
	//{{AFX_MSG_MAP(CDVBMPEDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_WM_TIMER()
	ON_WM_DESTROY()
	ON_BN_CLICKED(IDC_ADD_PROFILE, OnProfileAdd)
	ON_BN_CLICKED(IDC_EDIT_PROFILE, OnProfileEdit)
	ON_BN_CLICKED(IDC_DEL_PROFILE, OnProfileDel)
	ON_CBN_SELCHANGE(IDC_PROFILE_LIST, OnSelChangeProfileList)
	ON_BN_CLICKED(IDC_HIDE, OnHide)
	ON_WM_MOVE()
	ON_WM_SHOWWINDOW()
	ON_COMMAND(IDR_APP_MENU_EXIT, OnOK)
	ON_COMMAND(IDR_APP_MENU_SHOW, OnShowDVBData)
	ON_WM_CANCELMODE()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDVBMPEDlg Nachrichten-Handler

BOOL CDVBMPEDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Hinzuf�gen des Men�befehls "Info..." zum Systemmen�.

	// IDM_ABOUTBOX muss sich im Bereich der Systembefehle befinden.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{	
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Symbol f�r dieses Dialogfeld festlegen. Wird automatisch erledigt
	//  wenn das Hauptfenster der Anwendung kein Dialogfeld ist
	SetIcon(m_hIcon, TRUE);			// Gro�es Symbol verwenden
	SetIcon(m_hIcon, FALSE);		// Kleines Symbol verwenden
	
	// ZU ERLEDIGEN: Hier zus�tzliche Initialisierung einf�gen
	OSVERSIONINFO vi = {sizeof(OSVERSIONINFO)};
	GetVersionEx(&vi);
	win98 = vi.dwPlatformId == VER_PLATFORM_WIN32_WINDOWS;

	DVB_ERROR error;
	CString s;

	WORD wNrOfDev = CDVBCommon::GetNumberOfDevices();
	WORD wDevIdx = 0;
	if(wNrOfDev > 1)
	{
		CDeviceSelection DDlg(this);
		CString DevName, DevMAC, DevIP, s;
	
		for(int i=0; i<wNrOfDev; i++)
		{
			CDVBCommon::GetDeviceInfo(i, DevName, DevMAC, DevIP);
			s.Format("Nr: %u, Name: %s, MAC: %s", i+1, DevName, DevMAC);
			DDlg.m_strArr.Add(s);
		}
		if(IDOK == DDlg.DoModal())
		{
			wDevIdx = (WORD)DDlg.m_dwItemData;
		}
		s.Format("Device %u", wDevIdx);
		GetDlgItem(IDC_STATIC_DEV_NO)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_EDIT_DEVICE)->ShowWindow(SW_SHOW);
		GetDlgItem(IDC_EDIT_DEVICE)->SetWindowText(s);
	}
	s.Format("%u\\", wDevIdx);
	DVBMPE_REGISTRY_START_STRING += s;

	if(! CDVBCommon::OpenDevice(wDevIdx))
	{
		MessageBox("CDVBCommon::OpenDevice not successful.", "Error");
		m_nSelfTest = 1; // f�hrt zum Beenden der App.
	}
	else
	{
#ifdef _TTDVBUSB
		m_hDevice = CDVBCommon::GetActDeviceHandle();
		if(m_hDevice != INVALID_HANDLE_VALUE)
		{
			DEV_BROADCAST_HANDLE filter = {0};
			filter.dbch_size = sizeof(filter);
			filter.dbch_devicetype = DBT_DEVTYP_HANDLE;
			filter.dbch_handle = m_hDevice;
			m_hHandleNotification = RegisterDeviceNotification(m_hWnd, &filter, 0);
		}
#endif
	}

#ifndef _MMJOKER
	m_BoardControl.ResetInit();

	Sleep(100);
	
	error = m_Frontend.Init();
	if (error != DVB_ERR_NONE)
	{	TRACE("Error Init Frontend(1)\n");
		MessageBox("Frontend.Init not successful.", "Error");
		m_nSelfTest = 1; // f�hrt zum Beenden der App.
	}
//	Sleep(100);
	m_FE_Type = m_Frontend.GetType(); // erst hier erlaubt!
#endif

#ifndef _MMJOKER
#ifdef _TTDVBUSB
	CString r,u,t;
	GetExePath(r,u,t);
	if((r.Right(1) != '/') && (r.Right(1) != '\\'))
		r += "\\";
	r += "Boot\\dsp_usb.bin";

	error = m_BoardControl.BootDSP(r);

	if (error != DVB_ERR_NONE)
	{
		MessageBox("BoardControl.BootDSP not successful.", "Error");
		m_nSelfTest = 1; // f�hrt zum Beenden der App.
	}
	Sleep(100);
#endif
#endif


#ifdef _TTDVBUSB
	CDVBBoardControl::BANDWIDTH retBW;
	error = m_BoardControl.EnableIsoStream(retBW, CDVBBoardControl::BANDWIDTH_FULL);
//	error = m_BoardControl.EnableIsoStream(retBW, CDVBBoardControl::BANDWIDTH_5_82);
	if( error != DVB_ERR_NONE )
	{
		MessageBox("BoardControl.EnableIsoStream not successful.", "Error");
		m_nSelfTest = 1; // f�hrt zum Beenden der App.
	}
#else
	error = m_BoardControl.EnableDataDMA(TRUE);
	if (error != DVB_ERR_NONE)
	{
		MessageBox("BoardControl.EnableDataDMA not successful.", "Error");
		m_nSelfTest = 1; // f�hrt zum Beenden der App.
	}
#endif

#ifndef _MMJOKER
	switch(m_FE_Type)
	{
	case CDVBFrontend::FE_SATELLITE: // Sat-Frontend   
		m_pLnbDlg = new CLnbDlg; // wird von CTunerDlg gesteuert
		break;
	default:
		break;
	}
	m_pTunerDlg = new CTunerDlg(m_pLnbDlg, m_Frontend);
#endif
	m_pFilterDlg = new CFilterDlg;
	m_pTeletextDlg = new CTeletextDlg;
	m_pMultiDlg    = new CMultiDlg;
	m_pOsdDlg = new COSDDlg;
	m_pDDVidDlg = new CDDVidDlg;
#ifdef _TTDVBLCD
	m_pCIDlg = new CCIDlg;
#endif

	if(m_pTunerDlg != NULL)
	{	m_pTunerDlg->Create(IDD_TUNER_DLG, &m_ctrlTab);
		m_ctrlTab.AddTab(m_pTunerDlg, "Status/Tuner", 0);
	}
	if(m_pLnbDlg != NULL)
	{	m_pLnbDlg->Create(IDD_LNB_DLG, &m_ctrlTab);
		m_ctrlTab.AddTab(m_pLnbDlg, "DiSEqC/LNB", 0);
	}
	if(m_pFilterDlg != NULL)
	{	m_pFilterDlg->Create(IDD_FILTER_DLG, &m_ctrlTab);
		m_ctrlTab.AddTab(m_pFilterDlg, "MPE-Filter", 0);
	}
	if(m_pTeletextDlg != NULL)
	{	m_pTeletextDlg->Create(IDD_TELETEXT_DLG, &m_ctrlTab);
		m_ctrlTab.AddTab(m_pTeletextDlg, "Teletext/Section", 0);
	}
	if(m_pMultiDlg != NULL)
	{	m_pMultiDlg->Create(IDD_MULTI_DLG, &m_ctrlTab);
		m_ctrlTab.AddTab(m_pMultiDlg, "Multi-Multi-Filter", 0);
	}
	if(m_pOsdDlg != NULL)
	{	m_pOsdDlg->Create(IDD_OSD_DLG, &m_ctrlTab);
		m_ctrlTab.AddTab(m_pOsdDlg, "OSD/Remote", 0);
	}
	if(m_pDDVidDlg != NULL)
	{	m_pDDVidDlg->Create(IDD_DDVID_DLG, &m_ctrlTab);
		m_ctrlTab.AddTab(m_pDDVidDlg, "TV-Picture", 0);
	}
#ifdef _TTDVBLCD
	if(m_pCIDlg != NULL)
	{	m_pCIDlg->Create(IDD_CI_DLG, &m_ctrlTab);
		m_ctrlTab.AddTab(m_pCIDlg, "CI", 0);
	}
#endif

	//	m_ctrlTab.SetCurSel(0); m_ctrlTab.SetCurFocus(1); m_ctrlTab.SetCurFocus(0);

	m_strActProfile = DVBMPE_REGISTRY_DEFAULT_PROFILE;
	
	ProfilesReadFromRegistry();
	if(m_nSelfTest == 0)
		ProfileChange(m_strActProfile, ""); // letztes Profil wieder einstellen

	// register a message for system tray actions
	m_uNIFMessage = RegisterWindowMessage("DVBMPE Notify Icon Message");

	// add an icon to the system tray
	if(wNrOfDev > 1)
		s.Format("DVBData (Device %u)", wDevIdx);
	else
		s.Format("DVBData");
	m_hStateIcon = AfxGetApp()->LoadIcon(IDI_ICON_OK);
	m_nd.cbSize = sizeof(m_nd);
	m_nd.hWnd = m_hWnd;
	m_nd.uCallbackMessage = m_uNIFMessage;
	m_nd.uID = 1;
	m_nd.hIcon = m_hStateIcon; // m_nd.hIcon = m_hIcon;
	lstrcpyn(m_nd.szTip, s, min(s.GetLength()+1, 64));
	m_nd.uFlags = NIF_MESSAGE | NIF_ICON | NIF_TIP;
	Shell_NotifyIcon(NIM_ADD, &m_nd);

	m_bOK = FALSE;
	// Timer initialisieren
	m_boolFirstTime = TRUE;
	SetTimer(42, 1000, NULL);

	return TRUE;  // Geben Sie TRUE zur�ck, au�er ein Steuerelement soll den Fokus erhalten
}
 
void CDVBMPEDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	CDialog::OnSysCommand(nID, lParam);
}

// Wollen Sie Ihrem Dialogfeld eine Schaltfl�che "Minimieren" hinzuf�gen, ben�tigen Sie 
//  den nachstehenden Code, um das Symbol zu zeichnen. F�r MFC-Anwendungen, die das 
//  Dokument/Ansicht-Modell verwenden, wird dies automatisch f�r Sie erledigt.

void CDVBMPEDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // Ger�tekontext f�r Zeichnen

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Symbol in Client-Rechteck zentrieren
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Symbol zeichnen
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// Die Systemaufrufe fragen den Cursorform ab, die angezeigt werden soll, w�hrend der Benutzer
//  das zum Symbol verkleinerte Fenster mit der Maus zieht.
HCURSOR CDVBMPEDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CDVBMPEDlg::OnTimer(UINT nIDEvent) 
{
	BOOL bLock, bData;

	if(m_nSelfTest != 0)
		OnOK();

	if(nIDEvent == 42)
	{
		m_pOsdDlg->TimerEvent();

		bData = m_pFilterDlg->TimerEvent(); // Filter l�schen/setzen
		if(m_pTunerDlg != NULL)
			bLock = m_pTunerDlg->TimerEvent();  // Frontend-Status anzeigen
		else
			bLock = TRUE;

		if(bLock)
		{	if(bData)
			{	m_hStateIcon = AfxGetApp()->LoadIcon(IDI_ICON_DATA);
				if(m_nd.hIcon != m_hStateIcon)
				{	m_nd.hIcon = m_hStateIcon;
					Shell_NotifyIcon(NIM_MODIFY, &m_nd);
					m_ctrlStateIcon.SetIcon(m_nd.hIcon);
				}
			}
			else
			{	m_hStateIcon = AfxGetApp()->LoadIcon(IDI_ICON_OK);
				if(m_nd.hIcon != m_hStateIcon)
				{	m_nd.hIcon = m_hStateIcon;
					Shell_NotifyIcon(NIM_MODIFY, &m_nd);
					m_ctrlStateIcon.SetIcon(m_nd.hIcon);
				}
			}
		}
		else // (!Lock)
		{	m_hStateIcon = AfxGetApp()->LoadIcon(IDI_ICON_ERROR);
			if(m_nd.hIcon != m_hStateIcon)
			{	m_nd.hIcon = m_hStateIcon;
				Shell_NotifyIcon(NIM_MODIFY, &m_nd);
				m_ctrlStateIcon.SetIcon(m_nd.hIcon);
			}
		}

		if(m_boolFirstTime)
		{
			if(m_bHideOnStart)
			{
				ShowWindow(SW_HIDE);
				UpdateWindow();
			}
			m_boolFirstTime = FALSE;
		}
	}

	CDialog::OnTimer(nIDEvent);
}

void CDVBMPEDlg::OnDestroy() 
{
	//TRACE("\nOnDestroy <-->");

	CDialog::OnDestroy();

	// remove the Icon from the system tray
	m_nd.cbSize = sizeof(m_nd);
	m_nd.hWnd = m_hWnd;
	m_nd.uID = 1;
	Shell_NotifyIcon(NIM_DELETE, &m_nd);	

	// stop the timer 
	KillTimer(42);
 
	if(m_pTunerDlg != NULL)
	{	m_pTunerDlg->DestroyWindow();
		delete m_pTunerDlg;
	}
	if(m_pLnbDlg != NULL)
	{	m_pLnbDlg->DestroyWindow();
		delete m_pLnbDlg;
	}
	if(m_pFilterDlg != NULL)
	{	m_pFilterDlg->DestroyWindow();
		delete m_pFilterDlg;
	}
	if(m_pTeletextDlg != NULL)
	{	m_pTeletextDlg->DestroyWindow();
		delete m_pTeletextDlg;
	}
	if(m_pMultiDlg != NULL)
	{	m_pMultiDlg->DestroyWindow();
		delete m_pMultiDlg;
	}
	if(m_pOsdDlg != NULL)
	{	m_pOsdDlg->DestroyWindow();
		delete m_pOsdDlg;
	}
	if(m_pDDVidDlg != NULL)
	{	m_pDDVidDlg->DestroyWindow();
		delete m_pDDVidDlg;
	}
#ifdef _TTDVBLCD
	if(m_pCIDlg != NULL)
	{	m_pCIDlg->DestroyWindow();
		delete m_pCIDlg;
	}
#endif

#ifdef _TTDVBUSB
	CDVBBoardControl::BANDWIDTH retBW;
	m_BoardControl.EnableIsoStream(retBW, CDVBBoardControl::BANDWIDTH_NONE);
#else
	m_BoardControl.EnableDataDMA(FALSE);
#endif

	
#ifdef _TTDVBUSB
	if(m_hHandleNotification && !win98)
		UnregisterDeviceNotification(m_hHandleNotification);
	m_hHandleNotification = NULL;
#endif
	
	CDVBCommon::CloseDevice();
	m_hDevice = INVALID_HANDLE_VALUE;
}

void CDVBMPEDlg::OnOK() 
{
	CString strMBox;
	int res;

	if(m_bOK) // verhindern, das Funktion zum 2.mal aus SysTray-Menu aufgerufen wird
	{
		OnShowDVBData(); // Fenster mit "Beenden"-Dialogbox in Vordergrund bringen
		return;
	}
	else
	{
		m_bOK = TRUE;
		GetWindowText(strMBox);
		strMBox = "Are you sure to quit the " + strMBox + "?";
		res = MessageBox(strMBox, "Attention", MB_YESNO | MB_ICONQUESTION);

		if(res == IDYES)
		{
			CDialog::OnOK();
		}
	}
	m_bOK = FALSE;
}

void CDVBMPEDlg::OnCancel() 
{

}

void CDVBMPEDlg::OnHide() 
{
	ShowWindow(SW_HIDE);
	UpdateWindow();
}

LRESULT CDVBMPEDlg::WindowProc(UINT message, WPARAM wParam, LPARAM lParam)
{
	// TODO: Speziellen Code hier einf�gen und/oder Basisklasse aufrufen
	if (message == m_uNIFMessage) 
	{
		return OnNotifyIcon(wParam, lParam);
	}
	// all other messages are handled by default
	return CDialog::WindowProc(message, wParam, lParam);
}

LRESULT CDVBMPEDlg::OnNotifyIcon(WPARAM wParam, LPARAM lParam)
{
    UINT uMouseMsg = (UINT) lParam; 
	
	switch (uMouseMsg)
	{
	case WM_LBUTTONDBLCLK:
		OnShowDVBData();
		break;
	case WM_RBUTTONUP:
		{
			POINT p;
			GetCursorPos(&p);
			PopupMenu(p.x,p.y);
		}
		break;
	}
	return 1;
}

void CDVBMPEDlg::OnShowDVBData()
{
	ShowWindow(SW_SHOWNORMAL);
	UpdateWindow();		// sends a WM_PAINT
	BringWindowToTop();
}

void CDVBMPEDlg::PopupMenu(int x, int y)
{
	CMenu menu;

	UINT nIDResource;

	nIDResource = IDR_APP_MENU;

	if(menu.LoadMenu(nIDResource))
	{
		CMenu* pPopup = menu.GetSubMenu(0);
		ASSERT(pPopup != NULL);
		pPopup->SetDefaultItem(IDR_APP_MENU_SHOW);
		pPopup->TrackPopupMenu(TPM_LEFTALIGN | TPM_RIGHTBUTTON, x, y, this); // use main window for cmds
	}
}

void CDVBMPEDlg::ProfilesReadFromRegistry()
{
	CString key, subkey;
	HKEY hKey1;
	DWORD dwIndex = 0;
	DWORD len = 100;
	int sel;

	key = DVBMPE_REGISTRY_START_STRING;
	if(ERROR_SUCCESS == RegOpenKeyEx(HKEY_LOCAL_MACHINE, key, 0, KEY_ALL_ACCESS, &hKey1))
	{
		while(ERROR_SUCCESS == RegEnumKeyEx(hKey1, dwIndex,
									 subkey.GetBuffer(len), &len,
									 NULL, NULL, NULL, NULL))
		{
			subkey.ReleaseBuffer();
			dwIndex++;
			len = 100;
			m_ctrlProfileList.AddString(subkey);
		}
		RegCloseKey(hKey1);
	}
	subkey.ReleaseBuffer();

	m_strActProfile = DVBMPE_REGISTRY_DEFAULT_PROFILE;
	m_myReg.ReadFromRegistry(DVBMPE_REGISTRY_START_STRING, "__ActProfileName__", m_strActProfile);

	sel = m_ctrlProfileList.FindStringExact(-1, m_strActProfile);
	if(sel != CB_ERR)
		m_ctrlProfileList.SetCurSel(sel);
	else
	{
		if(m_ctrlProfileList.SetCurSel(0) != CB_ERR)
		{
			m_ctrlProfileList.GetLBText(0, m_strActProfile);
		}
		else
		{
			m_strActProfile = DVBMPE_REGISTRY_DEFAULT_PROFILE;
			m_ctrlProfileList.InsertString(0, m_strActProfile);
			m_ctrlProfileList.SetCurSel(0);
		}
	}
}

void CDVBMPEDlg::OnProfileAdd() 
{
	CProfilDlg PDlg(this);
	CString strText;
	int sel;

	//UpdateData(TRUE);

	for(sel=0; sel<m_ctrlProfileList.GetCount(); sel++)
	{
		m_ctrlProfileList.GetLBText(sel, strText);
		PDlg.m_StringArray.Add(strText);
	}
	PDlg.m_boolNewProfil = TRUE;
	if(IDOK == PDlg.DoModal())
	{
		sel = m_ctrlProfileList.AddString(PDlg.m_strDDName);
		if(sel >= 0)
		{	m_ctrlProfileList.SetCurSel(sel);
			m_myReg.SaveToRegistry(DVBMPE_REGISTRY_START_STRING + PDlg.m_strDDName, "", "");
			ProfileChange(PDlg.m_strDDName, PDlg.m_strCpyName);
		}
	}
}

void CDVBMPEDlg::OnProfileEdit() 
{
	CProfilDlg PDlg(this);
	CString strText;
	int sel, i;

	//UpdateData(TRUE);

	sel = m_ctrlProfileList.GetCurSel();
	if(sel != CB_ERR)
	{
		for(i=0; i<m_ctrlProfileList.GetCount(); i++)
		{
			m_ctrlProfileList.GetLBText(i, strText);
			PDlg.m_StringArray.Add(strText);
		}
		m_ctrlProfileList.GetLBText(sel, PDlg.m_strDDName);
		PDlg.m_boolNewProfil = FALSE;
		if(IDOK == PDlg.DoModal())
		{
			m_ctrlProfileList.GetLBText(sel, strText);
			m_ctrlProfileList.DeleteString(sel);
			m_ctrlProfileList.InsertString(sel, PDlg.m_strDDName);
			m_ctrlProfileList.SetCurSel(sel);
			m_myReg.SaveToRegistry(DVBMPE_REGISTRY_START_STRING + PDlg.m_strDDName, "", "");
			ProfileChange(PDlg.m_strDDName, strText);
			m_myReg.DelFromRegistry(DVBMPE_REGISTRY_START_STRING, strText);
		}
	}
	else
	{
		MessageBox("No data service selected!", "Error");
	}
}

void CDVBMPEDlg::OnProfileDel() 
{
	CProfilDlg PDlg(this);
	CString strText, strMBox;
	int sel, res;

	//UpdateData(TRUE);

	sel = m_ctrlProfileList.GetCurSel();
	if(sel != CB_ERR)
	{
		m_ctrlProfileList.GetLBText(sel, strText);
		strMBox = "Are you sure to delete the selected\nservice (" + strText + ")?";
		res = MessageBox(strMBox, "Attention", MB_YESNO | MB_ICONQUESTION);
		if(res == IDYES)
		{
			m_myReg.DelFromRegistry(DVBMPE_REGISTRY_START_STRING, strText);
			m_ctrlProfileList.DeleteString(sel);

			if(m_ctrlProfileList.SetCurSel(0) != CB_ERR)
			{
				m_ctrlProfileList.GetLBText(0, strText);
				ProfileChange(strText, "");
			}
			else
			{
				strText = DVBMPE_REGISTRY_DEFAULT_PROFILE;
				sel = m_ctrlProfileList.AddString(strText);
				if(sel >= 0)
				{	m_ctrlProfileList.SetCurSel(sel);
					m_myReg.SaveToRegistry(DVBMPE_REGISTRY_START_STRING + strText, "", "");
					ProfileChange(strText, "");
				}
			}
		}
	}
	else
	{
		MessageBox("No data service selected!", "Error");
	}
}

void CDVBMPEDlg::OnSelChangeProfileList() 
{
	CString strText;
	int sel;

	sel = m_ctrlProfileList.GetCurSel();
	if(sel != CB_ERR)
	{
		m_ctrlProfileList.GetLBText(sel, strText);
		ProfileChange(strText, "");
	}
}

void CDVBMPEDlg::ProfileChange(const CString& newProfile, const CString& cpyProfile)
{

	BeginWaitCursor();
	m_pFilterDlg->ProfileEvent(newProfile, cpyProfile);
	if(m_pTunerDlg != NULL)
		m_pTunerDlg->ProfileEvent(newProfile, cpyProfile);
	m_pDDVidDlg->ProfileEvent(newProfile, cpyProfile);
	m_pTeletextDlg->ProfileEvent(newProfile, cpyProfile);
//	m_pMultiDlg->ProfileEvent(newProfile, cpyProfile);
	m_strActProfile = newProfile;
	m_myReg.SaveToRegistry(DVBMPE_REGISTRY_START_STRING, "__ActProfileName__", m_strActProfile);
	EndWaitCursor();
}

void CDVBMPEDlg::GetExePath(CString &ExePath, CString &ExeName, CString &WindowsPath)
{

	char path[_MAX_PATH];
	char drive[_MAX_DRIVE];
	char dir[_MAX_DIR];
	char name[_MAX_FNAME];
	//LPTSTR lpBuffer;
	//DWORD RequiredSize;

	if(GetModuleFileName(NULL, path, _MAX_PATH) > 0)
	{
		_splitpath( path, drive, dir, name, NULL );

		ExePath = drive;
		ExePath += dir;
		ExeName = name;
	}
	else
	{
		ExePath = "C:\\";
		ExeName = "";
	}
	
	if(GetWindowsDirectory(path, _MAX_PATH) > 0)
	{
		WindowsPath = path;
	}
	else
	{
		WindowsPath = "";
	}
}

BOOL CDVBMPEDlg::OnDeviceChange(UINT nEventType, DWORD dwData)
{							// CTestDlg::OnDeviceChange
	if (!dwData)
		return TRUE;

	_DEV_BROADCAST_HEADER* p = (_DEV_BROADCAST_HEADER*) dwData;

	//if (p->dbcd_devicetype == DBT_DEVTYP_DEVICEINTERFACE)
	//	return HandleDeviceChange(nEventType, (PDEV_BROADCAST_DEVICEINTERFACE) p);
	//else
	if (p->dbcd_devicetype == DBT_DEVTYP_HANDLE)
		return HandleDeviceChange(nEventType, (PDEV_BROADCAST_HANDLE) p);
	else
		return TRUE;
}							// CTestDlg::OnDeviceChange

BOOL CDVBMPEDlg::HandleDeviceChange(DWORD evtype, PDEV_BROADCAST_HANDLE dhp)
{							// CTestDlg::HandleDeviceChange
	CString MBText, MBTitle;

//	if (dhp->dbch_handle != m_hDevice)
//		return TRUE;			// notification for some other handle

	switch (evtype)
	{						// process handle notification

	case DBT_DEVICEQUERYREMOVE:
		//if (MessageBox(_T("Okay to remove the device?"), _T("Removal Query"), MB_YESNO) != IDYES)
		//	return BROADCAST_QUERY_DENY;

		//MessageBox("DBT_DEVICEQUERYREMOVE");
		break;

//	case DBT_DEVICEREMOVEPENDING:
	case DBT_DEVICEREMOVECOMPLETE:
	
		//if(m_hDevice != INVALID_HANDLE_VALUE)
		//	CDVBCommon::CloseDevice();
		//m_hDevice = INVALID_HANDLE_VALUE;
	
		MessageBox(_T("Device removed. Close Application."));
		
		EndDialog(1);
		
		break;
		
	}						// process handle notification

	return TRUE;
}							// CTestDlg::HandleDeviceChange

