//  TT  -  TechnoTrend  -  TT  -  TechnoTrend  -  TT  -  TechnoTrend  -  TT  
//
//
//  (C) TechnoTrend AG 1999-2001
//
//  All rights are reserved. Reproduction in whole or in part is prohibited 
//  without the written consent of the copyright owner. TechnoTrend 
//  reserves the right to make changes without notice at any time.  
//
//
//  TT  -  TechnoTrend  -  TT  -  TechnoTrend  -  TT  -  TechnoTrend  -  TT  
//
///////////////////////////////////////////////////////////////////////////
//
//  Filename:     FilterDlg.h
//
//  Project(s):   TestAppDvb
//
//  Author:       GRi
//
//  Purpose:      Filter Dialog
//   
//  Environment:  Win32
//
//  Dev. Tool(s): MSVC 6.0
//
//  Note(s):      
// 
///////////////////////////////////////////////////////////////////////////
// 
//  File History
//
//   $Workfile: FilterDlg.h $
//   $Revision: 1 $  
//    $Modtime: 6.06.01 10:46 $
//
//   $Log: /DVB-PC/APP/TestAppUsbLcd/FilterDlg.h $
//     >>   
//     >>   1     10.07.01 14:48 Guido
//     >>   
//     >>   1     6.06.01 10:55 Guido
//     >>   
//     >>   5     16.05.01 15:11 Guido
//
///////////////////////////////////////////////////////////////////////////

#if !defined(AFX_FILTERDLG_H__66849563_8178_11D3_A2D9_00D05CFFFF04__INCLUDED_)
#define AFX_FILTERDLG_H__66849563_8178_11D3_A2D9_00D05CFFFF04__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// FilterDlg.h : Header-Datei
//
#include <DVBTSFilter.h>
#include <DVBBoardControl.h>

#include "MyRegistry.h"

//#define MAX_MCF 16 // max. 16 Multicast-Filter
#define MAX_MCF 64 // max. 64 Multicast-Filter
//#define MAX_FTR 32 // max. 32 Filter insgesamt
#define MAX_FTR 255 // max. 255 Filter insgesamt

/////////////////////////////////////////////////////////////////////////////
// Dialogfeld CFilterDlg 

class CFilterDlg : public CDialog
{
// Konstruktion
public:
	CFilterDlg(CWnd* pParent = NULL);   // Standardkonstruktor
	
	BOOL TimerEvent(void);
	void ProfileEvent(const CString& newProfile, const CString& cpyProfile);

// Dialogfelddaten
	//{{AFX_DATA(CFilterDlg)
	enum { IDD = IDD_FILTER_DLG };
	CListCtrl	m_ctrlFilterList;
	CString	m_strDefUCPID;
	CString	m_strDefMCPID;
	CString	m_strDefBCPID;
	BOOL	m_bMCtoPID;
	//}}AFX_DATA


// �berschreibungen
	// Vom Klassen-Assistenten generierte virtuelle Funktions�berschreibungen
	//{{AFX_VIRTUAL(CFilterDlg)
	public:
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV-Unterst�tzung
	//}}AFX_VIRTUAL

// Implementierung
protected:

	// Generierte Nachrichtenzuordnungsfunktionen
	//{{AFX_MSG(CFilterDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnDestroy();
	virtual void OnOK();
	virtual void OnCancel();
	afx_msg void OnCheckEOLMCPID();
	afx_msg void OnButtonApply();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

private:
	void SetValuesEvent();

	BOOL PIDFilterSet(CDVBTSFilter* f, WORD PID, CString& MAC, BYTE Range, BOOL HighSpeed);
	BOOL PIDFilterUnset(CDVBTSFilter* f);
	void CheckSetFilters(CDVBBoardControl::MULTICAST_LIST& MCI);
	void CheckDelFilters(CDVBBoardControl::MULTICAST_LIST& MCI);

	void SettingsReadFromRegistry();
	void SettingsSaveToRegistry();

	CMyRegistry m_myReg;

	CDVBBoardControl m_BoardControl;
	CDVBBoardControl::MULTICAST_LIST m_MCI;
	CDVBTSFilter m_UCFilter;	// unicast
	CDVBTSFilter m_BCFilter;	// broadcast

	class MCFTYPE
	{
	public:
		CDVBTSFilter* pF;
		CString		strMAC;
		CString		strPID;
	};
	MCFTYPE m_FMCArr[MAX_MCF]; // max. MAX_MCF (64) MulticastFilter

	MCFTYPE m_FUC; // Unicast Filter
	MCFTYPE m_FBC; // Broadcast Filter

	CString m_strActProfile;
	CString m_strUCIP;
	CString m_strUCMAC;

	WORD	m_wDefBCPID;
	WORD	m_wDefMCPID;
	WORD	m_wDefUCPID;

	BOOL CalcAndFillStatistics();

	DWORD m_dwArrStatistik[MAX_FTR];
	DWORD m_dwArrStatistik2[MAX_FTR];
	__int64 m_dwArrStatistikS[MAX_FTR];
	float m_fArrkBit[MAX_FTR][3];
	DWORD m_dwOldTime;
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ f�gt unmittelbar vor der vorhergehenden Zeile zus�tzliche Deklarationen ein.

#endif // AFX_FILTERDLG_H__66849563_8178_11D3_A2D9_00D05CFFFF04__INCLUDED_
