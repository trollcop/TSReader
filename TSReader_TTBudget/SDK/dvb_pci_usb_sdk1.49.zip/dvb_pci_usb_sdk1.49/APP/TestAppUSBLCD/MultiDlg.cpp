// MultiDlg.cpp: Implementierungsdatei
//

#include "stdafx.h"
#include "dvbmpe.h"
#include "MultiDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// Dialogfeld CMultiDlg

CMultiDlg * pCMultiDlg;

CMultiDlg::CMultiDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CMultiDlg::IDD, pParent)
{
	CurrMult = -1;

	//{{AFX_DATA_INIT(CMultiDlg)
	m_sPID1 = _T("");
	m_sPID2 = _T("");
	m_sPID3 = _T("");
	m_sPID4 = _T("");
	m_sPID5 = _T("");
	m_sData = _T("");
	m_sFilt1 = _T("");
	m_sFilt2 = _T("");
	m_sFilt3 = _T("");
	m_sMask1 = _T("");
	m_sMask2 = _T("");
	m_sMask3 = _T("");
	m_nMasterID = 65535;
	m_MidNum = 0;
	m_nError = 0;
	m_nFID1 = 0;
	m_nFID2 = 0;
	m_nFID3 = 0;
	m_nLen = 0;
	//}}AFX_DATA_INIT
}


void CMultiDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CMultiDlg)
	DDX_Control(pDX, IDC_ADD_MAC3, m_BuAddMac3);
	DDX_Control(pDX, IDC_ADD_MAC2, m_BuAddMac2);
	DDX_Control(pDX, IDC_ADD_MAC1, m_BuAddMac1);
	DDX_Control(pDX, IDC_DEL_MAC3, m_BuDelMac3);
	DDX_Control(pDX, IDC_DEL_MAC2, m_BuDelMac2);
	DDX_Control(pDX, IDC_DEL_MAC1, m_BuDelMac1);
	DDX_Control(pDX, IDC_MULTI_DEL, m_ButDelMult);
	DDX_Text(pDX, IDC_PID1, m_sPID1);
	DDX_Text(pDX, IDC_PID2, m_sPID2);
	DDX_Text(pDX, IDC_PID3, m_sPID3);
	DDX_Text(pDX, IDC_PID4, m_sPID4);
	DDX_Text(pDX, IDC_PID5, m_sPID5);
	DDX_Text(pDX, IDC_DATA, m_sData);
	DDX_Text(pDX, IDC_FILTR1, m_sFilt1);
	DDX_Text(pDX, IDC_FILTR2, m_sFilt2);
	DDX_Text(pDX, IDC_FILTR3, m_sFilt3);
	DDX_Text(pDX, IDC_MASK1, m_sMask1);
	DDX_Text(pDX, IDC_MASK2, m_sMask2);
	DDX_Text(pDX, IDC_MASK3, m_sMask3);
	DDX_Text(pDX, IDC_MID, m_nMasterID);
	DDX_Text(pDX, IDC_MID_NUM, m_MidNum);
	DDX_Text(pDX, IDC_ERROR, m_nError);
	DDX_Text(pDX, IDC_FID1, m_nFID1);
	DDX_Text(pDX, IDC_FID2, m_nFID2);
	DDX_Text(pDX, IDC_FID3, m_nFID3);
	DDX_Text(pDX, IDC_LEN, m_nLen);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CMultiDlg, CDialog)
	//{{AFX_MSG_MAP(CMultiDlg)
	ON_BN_CLICKED(IDC_MULTI_SET, OnMultiSet)
	ON_BN_CLICKED(IDC_MULTI_DEL, OnMultiDel)
	ON_BN_CLICKED(IDC_ADD_MAC1, OnAddMac1)
	ON_BN_CLICKED(IDC_ADD_MAC2, OnAddMac2)
	ON_BN_CLICKED(IDC_ADD_MAC3, OnAddMac3)
	ON_BN_CLICKED(IDC_DEL_MAC1, OnDelMac1)
	ON_BN_CLICKED(IDC_DEL_MAC2, OnDelMac2)
	ON_BN_CLICKED(IDC_DEL_MAC3, OnDelMac3)
	ON_BN_CLICKED(IDC_RESETLEN, OnResetlen)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// Behandlungsroutinen f�r Nachrichten CMultiDlg 

void CTestFilter::OnDataArrival(BYTE* Buff, int len)
{
	pCMultiDlg->OnData(Buff, len);
}

void CMultiDlg::OnData(BYTE * Buff, int len)
{
	m_nLen += len;
	SetDlgItemInt(IDC_LEN, m_nLen);
//	m_sData = Buff;
	m_sData = "";
	// Testhalber in TextBox ausgeben
	for(int i=0; i<((len>100)?100:len); i++)
	{
		if(isprint(Buff[i]))
			m_sData += Buff[i];
		else
			m_sData += " ";
		if((i>0) && (i%20 == 0))
			m_sData += "\r\n";
	}
	SetDlgItemText(IDC_DATA, m_sData);
}

void CMultiDlg::OnMultiSet() 
{
	int i;
	if (!pCMultiDlg) pCMultiDlg = this;

	if (++CurrMult >= MAX_MULTI)
	{
		m_nError = 99;  return;
	}
	UpdateData(TRUE);
	pMULT[CurrMult] = new CTestFilter;
	for (i=0; i < 5; i++)
		PIDs[CurrMult][i] = 0xFFFF;
	i = 0;
	if (m_sPID1 != "")
		i++, PIDs[CurrMult][0] = (WORD)strtoul(m_sPID1, NULL, 10);
	if (m_sPID2 != "")
		i++, PIDs[CurrMult][1] = (WORD)strtoul(m_sPID2, NULL, 10);
	if (m_sPID3 != "")
		i++, PIDs[CurrMult][2] = (WORD)strtoul(m_sPID3, NULL, 10);
	if (m_sPID4 != "")
		i++, PIDs[CurrMult][3] = (WORD)strtoul(m_sPID4, NULL, 10);
	if (m_sPID5 != "")
		i++, PIDs[CurrMult][4] = (WORD)strtoul(m_sPID5, NULL, 10);
	i = (int)pMULT[CurrMult]->SetMultiMultiFilter(&(PIDs[CurrMult][0]), i);  //OF
	m_nError = i;
	if (!i)
	{
		m_nMasterID = MasterID[CurrMult] = PIDs[CurrMult][0];
		m_BuAddMac1.EnableWindow(TRUE);
		m_BuAddMac2.EnableWindow(TRUE);
		m_BuAddMac3.EnableWindow(TRUE);
		m_BuDelMac1.EnableWindow(FALSE);
		m_BuDelMac2.EnableWindow(FALSE);
		m_BuDelMac3.EnableWindow(FALSE);
//		m_sFilt1 = m_sFilt2 = m_sFilt3 = "";
//		m_sMask1 = m_sMask2 = m_sMask3 = "";
		m_nFID1 = m_nFID2 = m_nFID3 = 0;
		bFID1[CurrMult] = bFID2[CurrMult] = bFID3[CurrMult] = 0;
		pMAC1[CurrMult] = pMAC2[CurrMult] = pMAC3[CurrMult] = 0;
		IsMac1[CurrMult] = IsMac2[CurrMult] = IsMac3[CurrMult] = 0;
		m_ButDelMult.EnableWindow(TRUE);
	}
	else
		CurrMult--;
	m_MidNum = CurrMult + 1;
	UpdateData(FALSE);
}

void CMultiDlg::OnMultiDel() 
{
	int i;
	BYTE b[16];
	UpdateData(TRUE);
	if (pMAC1[CurrMult]) OnDelMac1();
	if (pMAC2[CurrMult]) OnDelMac2();
	if (pMAC3[CurrMult]) OnDelMac3();
	i = (int)pMULT[CurrMult]->ResetMultiMultiFilter();  //OF i=0;
	if (!i) delete pMULT[CurrMult--];
	m_MidNum = CurrMult + 1;
	if (CurrMult >= 0)
	{
		itoa(PIDs[CurrMult][0], (char *)b, 10); 
		if (PIDs[CurrMult][0] == 0xFFFF) m_sPID1 = ""; else m_sPID1 = b; 
		itoa(PIDs[CurrMult][1], (char *)b, 10);
		if (PIDs[CurrMult][1] == 0xFFFF) m_sPID2 = ""; else m_sPID2 = b; 
		itoa(PIDs[CurrMult][2], (char *)b, 10);
		if (PIDs[CurrMult][2] == 0xFFFF) m_sPID3 = ""; else m_sPID3 = b; 
		itoa(PIDs[CurrMult][3], (char *)b, 10);
		if (PIDs[CurrMult][3] == 0xFFFF) m_sPID4 = ""; else m_sPID4 = b; 
		itoa(PIDs[CurrMult][4], (char *)b, 10);
		if (PIDs[CurrMult][4] == 0xFFFF) m_sPID5 = ""; else m_sPID5 = b; 
		m_nMasterID = MasterID[CurrMult];
		m_nFID1 = (short) bFID1[CurrMult];
		m_nFID2 = (short) bFID2[CurrMult];
		m_nFID3 = (short) bFID3[CurrMult];
		m_sFilt1 = m_sFilt2 = m_sFilt3 = "";
		m_sMask1 = m_sMask2 = m_sMask3 = "";
		ConvI2T(Filt1[CurrMult], m_sFilt1, L1[CurrMult]);
		ConvI2T(Mask1[CurrMult], m_sMask1, L1[CurrMult]);
		ConvI2T(Filt2[CurrMult], m_sFilt2, L2[CurrMult]);
		ConvI2T(Mask2[CurrMult], m_sMask2, L2[CurrMult]);
		ConvI2T(Filt3[CurrMult], m_sFilt3, L3[CurrMult]);
		ConvI2T(Mask3[CurrMult], m_sMask3, L3[CurrMult]);
		if (IsMac1[CurrMult]) m_BuAddMac1.EnableWindow(FALSE), m_BuDelMac1.EnableWindow(TRUE);
		else m_BuAddMac1.EnableWindow(TRUE), m_BuDelMac1.EnableWindow(FALSE);
		if (IsMac2[CurrMult]) m_BuAddMac2.EnableWindow(FALSE), m_BuDelMac2.EnableWindow(TRUE);
		else m_BuAddMac2.EnableWindow(TRUE), m_BuDelMac2.EnableWindow(FALSE);
		if (IsMac3[CurrMult]) m_BuAddMac3.EnableWindow(FALSE), m_BuDelMac3.EnableWindow(TRUE);
		else m_BuAddMac3.EnableWindow(TRUE), m_BuDelMac3.EnableWindow(FALSE);
//		if (!IsMac1[CurrMult] && !IsMac2[CurrMult] && !IsMac3[CurrMult])
			m_ButDelMult.EnableWindow(TRUE);
//		else m_ButDelMult.EnableWindow(FALSE);
	}
	else 
	{
		m_sPID1 = m_sPID2 = m_sPID3 = m_sPID4 = m_sPID5 = "";
		m_nMasterID = 65565;
		m_ButDelMult.EnableWindow(FALSE);
		m_BuAddMac1.EnableWindow(FALSE);
		m_BuAddMac2.EnableWindow(FALSE);
		m_BuAddMac3.EnableWindow(FALSE);
		m_BuDelMac1.EnableWindow(FALSE);
		m_BuDelMac2.EnableWindow(FALSE);
		m_BuDelMac3.EnableWindow(FALSE);
	}
	m_nError = 0;
	UpdateData(FALSE);
}

void CMultiDlg::ConvI2T(BYTE * Sour, CString & Targ, int l)
{
	int i; BYTE b;
	for (i = 0; i < l; i++)
	{
		b = Sour[i] >> 4;
		if (b > 9) Targ += (BYTE)(0x37 + b);
		else Targ += (BYTE)(0x30 + b);
		b = Sour[i] &0xF;
		if (b > 9) Targ += (BYTE)(0x37 + b);
		else Targ += (BYTE)(0x30 + b);
	}
}

int CMultiDlg::ConvT2I(CString & Sour, BYTE * Targ, int l)
{
	int i; BYTE b;
	for (i = 0; i < l && i < 16; i++)
	{
		if (Sour[2*i] > 0x46 || Sour[2*i] < 0x30) return 1;
		if (Sour[2*i] <= 0x39) b = Sour[2*i] - 0x30;
		else  b = Sour[2*i] - 0x37;
		Targ[i] = b << 4;
		if (Sour[2*i+1] > 0x46 || Sour[2*i+1] < 0x30) return 1;
		if (Sour[2*i+1] <= 0x39) b = Sour[2*i+1] - 0x30;
		else  b = Sour[2*i+1] - 0x37;
		Targ[i] += b;
	}
	return 0;
}



void CMultiDlg::OnAddMac1() 
{
	int i, len1, len2; 
	UpdateData(TRUE);
	m_nError = 99;
	pMAC1[CurrMult] = new CTestFilter;
	for (i = 0; i < 16; i++)
		Filt1[CurrMult][i] = Mask1[CurrMult][i] = 0;
	len1 = m_sFilt1.GetLength() >> 1;
	if (ConvT2I(m_sFilt1, Filt1[CurrMult], len1)) goto err;
	len2 = m_sMask1.GetLength() >> 1;
	if (ConvT2I(m_sMask1, Mask1[CurrMult], len2)) goto err;
	if (len1 > len2) len1 = len2; if (len1 > 16) len1 = 16;
	L1[CurrMult] = len1;
	m_nError = (int)pMAC1[CurrMult]->SetFilter(CDVBTSFilter::MULTI_MPE_FILTER, MasterID[CurrMult], Filt1[CurrMult], Mask1[CurrMult], (BYTE) len1); //OF
	if (!m_nError)
	{
		IsMac1[CurrMult] = 1;
		m_BuAddMac1.EnableWindow(FALSE);
//		m_ButDelMult.EnableWindow(FALSE);
		m_BuDelMac1.EnableWindow(TRUE);
		m_nFID1 = (short) (bFID1[CurrMult] = pMAC1[CurrMult]->GetFilterID());
	}
err:UpdateData(FALSE);
}

void CMultiDlg::OnAddMac2() 
{
	int i, len1, len2; 
	UpdateData(TRUE);
	m_nError = 99;
	pMAC2[CurrMult] = new CTestFilter;
	for (i = 0; i < 16; i++)
		Filt2[CurrMult][i] = Mask2[CurrMult][i] = 0;
	len1 = m_sFilt2.GetLength() >> 1;
	if (ConvT2I(m_sFilt2, Filt2[CurrMult], len1)) goto err;;
	len2 = m_sMask2.GetLength() >> 1;
	if (ConvT2I(m_sMask2, Mask2[CurrMult], len2)) goto err;
	if (len1 > len2) len1 = len2; if (len1 > 16) len1 = 16;
	L2[CurrMult] = len1;
	m_nError = (int)pMAC2[CurrMult]->SetFilter(CDVBTSFilter::MULTI_MPE_FILTER, MasterID[CurrMult], Filt2[CurrMult], Mask2[CurrMult], (BYTE) len1); //OF
	if (!m_nError)
	{
		IsMac2[CurrMult] = 1;
		m_BuAddMac2.EnableWindow(FALSE);
//		m_ButDelMult.EnableWindow(FALSE);
		m_BuDelMac2.EnableWindow(TRUE);
		m_nFID2 = (short) (bFID2[CurrMult] = pMAC2[CurrMult]->GetFilterID());
	}
err:UpdateData(FALSE);
}

void CMultiDlg::OnAddMac3() 
{
	int i, len1, len2; 
	UpdateData(TRUE);
	m_nError = 99;
	pMAC3[CurrMult] = new CTestFilter;
	for (i = 0; i < 16; i++)
		Filt3[CurrMult][i] = Mask3[CurrMult][i] = 0;
	len1 = m_sFilt3.GetLength() >> 1;
	if (ConvT2I(m_sFilt3, Filt3[CurrMult], len1)) goto err;
	len2 = m_sMask3.GetLength() >> 1;
	if (ConvT2I(m_sMask3, Mask3[CurrMult], len2)) goto err;
	if (len1 > len2) len1 = len2; if (len1 > 16) len1 = 16;
	L3[CurrMult] = len1;
	m_nError = (int)pMAC3[CurrMult]->SetFilter(CDVBTSFilter::MULTI_MPE_FILTER, MasterID[CurrMult], Filt3[CurrMult], Mask3[CurrMult], (BYTE) len1); //OF
	if (!m_nError)
	{
		IsMac3[CurrMult] = 1;
		m_BuAddMac3.EnableWindow(FALSE);
//		m_ButDelMult.EnableWindow(FALSE);
		m_BuDelMac3.EnableWindow(TRUE);
		m_nFID3 = (short) (bFID3[CurrMult] = pMAC3[CurrMult]->GetFilterID());
	}
err:UpdateData(FALSE);
}

void CMultiDlg::OnDelMac1() 
{
	UpdateData(TRUE);
	m_nError = (int)pMAC1[CurrMult]->ResetFilter();
	if (!m_nError)
	{
		delete pMAC1[CurrMult];
		pMAC1[CurrMult] = 0;
		m_BuAddMac1.EnableWindow(TRUE);
		m_BuDelMac1.EnableWindow(FALSE);
		bFID1[CurrMult] = 0;
		m_nFID1 = 0;
		IsMac1[CurrMult] = 0;
	}
	if (!IsMac1[CurrMult] && !IsMac2[CurrMult] && !IsMac3[CurrMult])
		m_ButDelMult.EnableWindow(TRUE);
	UpdateData(FALSE);
}

void CMultiDlg::OnDelMac2() 
{
	UpdateData(TRUE);
	m_nError = (int)pMAC2[CurrMult]->ResetFilter();
	if (!m_nError)
	{
		delete pMAC2[CurrMult];
		pMAC2[CurrMult] = 0;
		m_BuAddMac2.EnableWindow(TRUE);
		m_BuDelMac2.EnableWindow(FALSE);
		bFID2[CurrMult] = 0;
		m_nFID2 = 0;
		IsMac2[CurrMult] = 0;
	}
	if (!IsMac1[CurrMult] && !IsMac2[CurrMult] && !IsMac3[CurrMult])
		m_ButDelMult.EnableWindow(TRUE);
	UpdateData(FALSE);
}

void CMultiDlg::OnDelMac3() 
{
	UpdateData(TRUE);
	m_nError = (int)pMAC3[CurrMult]->ResetFilter();
	if (!m_nError)
	{
		delete pMAC3[CurrMult];
		pMAC3[CurrMult] = 0;
		m_BuAddMac3.EnableWindow(TRUE);
		m_BuDelMac3.EnableWindow(FALSE);
		bFID3[CurrMult] = 0;
		m_nFID3 = 0;
		IsMac3[CurrMult] = 0;
	}
	if (!IsMac1[CurrMult] && !IsMac2[CurrMult] && !IsMac3[CurrMult])
		m_ButDelMult.EnableWindow(TRUE);
	UpdateData(FALSE);
}

void CMultiDlg::OnResetlen() 
{
	UpdateData(TRUE);
	m_sData = "";
	m_nLen = 0;
	UpdateData(FALSE);
}	
