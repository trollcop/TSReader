//  TT  -  TechnoTrend  -  TT  -  TechnoTrend  -  TT  -  TechnoTrend  -  TT  
//
//
//  (C) TechnoTrend AG 1999-2001
//
//  All rights are reserved. Reproduction in whole or in part is prohibited 
//  without the written consent of the copyright owner. TechnoTrend 
//  reserves the right to make changes without notice at any time.  
//
//
//  TT  -  TechnoTrend  -  TT  -  TechnoTrend  -  TT  -  TechnoTrend  -  TT  
//
///////////////////////////////////////////////////////////////////////////
//
//  Filename:     MyRegistry.h
//
//  Project(s):   TestAppDvb
//
//  Author:       GRi
//
//  Purpose:      Helper class for Registry access
//   
//  Environment:  Win32
//
//  Dev. Tool(s): MSVC 6.0
//
//  Note(s):      
// 
///////////////////////////////////////////////////////////////////////////
// 
//  File History
//
//   $Workfile: MyRegistry.h $
//   $Revision: 1 $  
//    $Modtime: 29.05.01 9:18 $
//
//   $Log: /DVB-PC/APP/TestAppUsbLcd/MyRegistry.h $
//     >>   
//     >>   1     10.07.01 14:48 Guido
//     >>   
//     >>   1     6.06.01 10:55 Guido
//     >>   
//     >>   2     16.05.01 15:11 Guido
//
///////////////////////////////////////////////////////////////////////////

// MyRegistry.h: Schnittstelle f�r die Klasse CMyRegistry.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_MYREGISTRY_H__670ADEE3_199A_11D3_A2D8_00D05CFFFF04__INCLUDED_)
#define AFX_MYREGISTRY_H__670ADEE3_199A_11D3_A2D8_00D05CFFFF04__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CMyRegistry  
{
public:
	CMyRegistry();
	virtual ~CMyRegistry();
	BOOL SaveToRegistry(const CString& to, const CString& name, const CString& value);
	BOOL SaveToRegistry(const CString& to, const CString& name, const DWORD& value);
	BOOL SaveToRegistry(const CString& to, const CString& name, const WORD& value);
	BOOL SaveToRegistry(const CString& to, const CString& name, const int& value);
	BOOL ReadFromRegistry(const CString& from, const CString& name, CString& value);
	BOOL ReadFromRegistry(const CString& from, const CString& name, DWORD& value);
	BOOL ReadFromRegistry(const CString& from, const CString& name, WORD& value);
	BOOL ReadFromRegistry(const CString& from, const CString& name, int& value);
	BOOL DelFromRegistry(const CString& key, const CString& subkey);

private:
	BOOL DelKey(LPCTSTR pszKeyName, HKEY hParentKey = 0);

};

#endif // !defined(AFX_MYREGISTRY_H__670ADEE3_199A_11D3_A2D8_00D05CFFFF04__INCLUDED_)
