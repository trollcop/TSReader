//  TT  -  TechnoTrend  -  TT  -  TechnoTrend  -  TT  -  TechnoTrend  -  TT  
//
//
//  (C) TechnoTrend AG 1999-2001
//
//  All rights are reserved. Reproduction in whole or in part is prohibited 
//  without the written consent of the copyright owner. TechnoTrend 
//  reserves the right to make changes without notice at any time.  
//
//
//  TT  -  TechnoTrend  -  TT  -  TechnoTrend  -  TT  -  TechnoTrend  -  TT  
//
///////////////////////////////////////////////////////////////////////////
//
//  Filename:     ProfilDlg.cpp
//
//  Project(s):   TestAppDvb
//
//  Author:       GRi
//
//  Purpose:      ProfilDlg.cpp
//   
//  Environment:  Win32
//
//  Dev. Tool(s): MSVC 6.0
//
//  Note(s):      
// 
///////////////////////////////////////////////////////////////////////////
// 
//  File History
//
//   $Workfile: ProfilDlg.cpp $
//   $Revision: 1 $  
//    $Modtime: 29.05.01 9:18 $
//
//   $Log: /DVB-PC/APP/TestAppUsbLcd/ProfilDlg.cpp $
//     >>   
//     >>   1     10.07.01 14:48 Guido
//     >>   
//     >>   1     6.06.01 10:55 Guido
//     >>   
//     >>   2     16.05.01 15:11 Guido
//
///////////////////////////////////////////////////////////////////////////

// ProfilDlg.cpp: Implementierungsdatei
//

#include "stdafx.h"
#include "dvbmpe.h"
#include "ProfilDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// Dialogfeld CProfilDlg 


CProfilDlg::CProfilDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CProfilDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CProfilDlg)
	m_strDDName = _T("");
	//}}AFX_DATA_INIT
	m_boolNewProfil = FALSE;
	m_strCpyName = _T("");
}


void CProfilDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CProfilDlg)
	DDX_Control(pDX, IDC_COMBO1, m_ctrlPropList);
	DDX_Text(pDX, IDC_DDNAME, m_strDDName);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CProfilDlg, CDialog)
	//{{AFX_MSG_MAP(CProfilDlg)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// Behandlungsroutinen f�r Nachrichten CProfilDlg 

BOOL CProfilDlg::OnInitDialog() 
{
	CRect rect;
	int i;
	
	CDialog::OnInitDialog();
	
	// TODO: Zus�tzliche Initialisierung hier einf�gen
	if(!m_boolNewProfil)
	{
		GetWindowRect(&rect);
		rect.bottom = rect.bottom - 50;
		MoveWindow(&rect, TRUE);
	}
	
	for(i=0; i<m_StringArray.GetSize(); i++)
		m_ctrlPropList.AddString(m_StringArray.GetAt(i));

	i = m_ctrlPropList.FindStringExact(-1, DVBMPE_REGISTRY_DEFAULT_PROFILE);
	if(i != CB_ERR)
		m_ctrlPropList.SetCurSel(i);
	else
		m_ctrlPropList.SetCurSel(0);

	m_oldName = m_strDDName;

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX-Eigenschaftenseiten sollten FALSE zur�ckgeben
}

void CProfilDlg::OnOK() 
{
	int sel;
	BOOL wrongName = FALSE;

	// TODO: Zus�tzliche Pr�fung hier einf�gen
	UpdateData(TRUE);

	sel = m_ctrlPropList.GetCurSel();
	if(sel != CB_ERR)
		m_ctrlPropList.GetLBText(sel, m_strCpyName);

	for(sel=0; sel<m_StringArray.GetSize(); sel++)
		if(m_StringArray.GetAt(sel) == m_strDDName)
			if(m_oldName != m_strDDName)
				wrongName = TRUE;

	if(wrongName)
		MessageBox("The list contains this name already.\n\rPlease insert an other name!", "Error");
	else if(m_strDDName.GetLength() == 0)
		MessageBox("Please insert an valid name!", "Error");
	else
		CDialog::OnOK();
}


