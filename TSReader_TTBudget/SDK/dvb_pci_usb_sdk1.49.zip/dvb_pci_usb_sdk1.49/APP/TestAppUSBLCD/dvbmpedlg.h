//  TT  -  TechnoTrend  -  TT  -  TechnoTrend  -  TT  -  TechnoTrend  -  TT  
//
//
//  (C) TechnoTrend AG 1999-2001
//
//  All rights are reserved. Reproduction in whole or in part is prohibited 
//  without the written consent of the copyright owner. TechnoTrend 
//  reserves the right to make changes without notice at any time.  
//
//
//  TT  -  TechnoTrend  -  TT  -  TechnoTrend  -  TT  -  TechnoTrend  -  TT  
//
///////////////////////////////////////////////////////////////////////////
//
//  Filename:     dvbmpedlg.h
//
//  Project(s):   TestAppDvb
//
//  Author:       GRi
//
//  Purpose:      Main Dialog
//   
//  Environment:  Win32
//
//  Dev. Tool(s): MSVC 6.0
//
//  Note(s):      
// 
///////////////////////////////////////////////////////////////////////////
// 
//  File History
//
//   $Workfile: dvbmpedlg.h $
//   $Revision: 5 $  
//    $Modtime: 6.02.03 16:39 $
//
//   $Log: /DVB-PC/APP/TestAppUsbLcd/dvbmpedlg.h $
//     >>   
//     >>   5     6.02.03 16:39 Guido
//     >>   
//     >>   4     28.03.02 17:12 Guido
//     >>   
//     >>   3     13.03.02 14:10 Oleh
//     >>   
//     >>   2     3.08.01 15:51 Guido
//     >>   
//     >>   1     10.07.01 14:48 Guido
//     >>   
//     >>   1     6.06.01 10:55 Guido
//     >>   
//     >>   12    16.05.01 15:11 Guido
//
///////////////////////////////////////////////////////////////////////////

// DVBMPEDlg.h : Header-Datei
//

#if !defined(AFX_DVBMPESATDLG_H__413A6E04_F8D0_11D2_A2D8_00104B48BC54__INCLUDED_)
#define AFX_DVBMPESATDLG_H__413A6E04_F8D0_11D2_A2D8_00104B48BC54__INCLUDED_
 
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
  
#include <DVBBoardControl.h>
#include "ProfilDlg.h"
#include "MyRegistry.h"

#include "XTabCtrl.h"
#include "TunerDlg.h"
#include "LnbDlg.h"
#include "FilterDlg.h"
#include "TeletextDlg.h"
#include "MultiDlg.h"
//#include "AVOSDDlg.h"
#include "OSDDlg.h"
//#include "RecPlayDlg.h"
//#include "CIDlg.h"
//#include "PsiDlg.h"
#include "DDVidDlg.h"
#include "CIDlg.h"

#include "DeviceSelection.h"

//#include "PsiDecoder.h"

#include <dbt.h>

//#define _MMJOKER

/////////////////////////////////////////////////////////////////////////////
// CDVBMPEDlg Dialogfeld

class CDVBMPEDlg : public CDialog
{
// Konstruktion
public:
	//CMPEGDecoder m_MPEGDecoder;
	void GetExePath(CString& ExePath, CString& ExeName, CString& WindowsPath);
	BOOL m_bHideOnStart;
	int m_nSelfTest;
	CDVBMPEDlg(CWnd* pParent = NULL);	// Standard-Konstruktor

// Dialogfelddaten
	//{{AFX_DATA(CDVBMPEDlg)
	enum { IDD = IDD_DVBMPE_DIALOG };
	CStatic	m_ctrlStateIcon;
	CComboBox	m_ctrlProfileList;
	CXTabCtrl	m_ctrlTab;
	//}}AFX_DATA

	// Vom Klassenassistenten generierte �berladungen virtueller Funktionen
	//{{AFX_VIRTUAL(CDVBMPEDlg)
	public:
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV-Unterst�tzung
	virtual LRESULT WindowProc(UINT message, WPARAM wParam, LPARAM lParam);
	//}}AFX_VIRTUAL

// Implementierung
protected:
	HICON m_hIcon;

	afx_msg BOOL OnDeviceChange(UINT nEventType, DWORD dwData);

	// Generierte Message-Map-Funktionen
	//{{AFX_MSG(CDVBMPEDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg void OnDestroy();
	virtual void OnOK();
	virtual void OnCancel();
	afx_msg void OnProfileAdd();
	afx_msg void OnProfileEdit();
	afx_msg void OnProfileDel();
	afx_msg void OnSelChangeProfileList();
	afx_msg void OnHide();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

private:
	void ProfileChange(const CString& newProfile, const CString& cpyProfile);

	void ProfilesReadFromRegistry();

	CString m_strActProfile;
	CMyRegistry m_myReg;
	
	CDVBBoardControl m_BoardControl;
	CDVBFrontend m_Frontend;

	CDVBFrontend::FRONTEND_TYPE m_FE_Type;

	void PopupMenu(int x, int y);
	void OnShowDVBData();
	LRESULT OnNotifyIcon(WPARAM wParam, LPARAM lParam);
	UINT m_uNIFMessage;
	NOTIFYICONDATA m_nd;
	HICON m_hStateIcon;

	int m_iTimerID;
	CString m_strBN;

	BOOL m_bOK;
	BOOL m_boolFirstTime;

	CTunerDlg*     m_pTunerDlg;
	CLnbDlg*       m_pLnbDlg;
	CFilterDlg*    m_pFilterDlg;
	CTeletextDlg*  m_pTeletextDlg;
	COSDDlg*		m_pOsdDlg;
	CDDVidDlg*		m_pDDVidDlg;
#ifdef _TTDVBLCD
	CCIDlg*			m_pCIDlg;
#endif
	CMultiDlg*		m_pMultiDlg;


	BOOL HandleDeviceChange(DWORD evtype, PDEV_BROADCAST_HANDLE dhp);
	HDEVNOTIFY m_hHandleNotification;
	HANDLE m_hDevice;
	BOOL win98;
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ f�gt unmittelbar vor der vorhergehenden Zeile zus�tzliche Deklarationen ein.

#endif // !defined(AFX_DVBMPESATDLG_H__413A6E04_F8D0_11D2_A2D8_00104B48BC54__INCLUDED_)
