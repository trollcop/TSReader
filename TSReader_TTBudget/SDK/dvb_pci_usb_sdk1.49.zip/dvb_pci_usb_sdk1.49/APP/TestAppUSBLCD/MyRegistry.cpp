//  TT  -  TechnoTrend  -  TT  -  TechnoTrend  -  TT  -  TechnoTrend  -  TT  
//
//
//  (C) TechnoTrend AG 1999-2001
//
//  All rights are reserved. Reproduction in whole or in part is prohibited 
//  without the written consent of the copyright owner. TechnoTrend 
//  reserves the right to make changes without notice at any time.  
//
//
//  TT  -  TechnoTrend  -  TT  -  TechnoTrend  -  TT  -  TechnoTrend  -  TT  
//
///////////////////////////////////////////////////////////////////////////
//
//  Filename:     MyRegistry.cpp
//
//  Project(s):   TestAppDvb
//
//  Author:       GRi
//
//  Purpose:      MyRegistry.cpp
//   
//  Environment:  Win32
//
//  Dev. Tool(s): MSVC 6.0
//
//  Note(s):      
// 
///////////////////////////////////////////////////////////////////////////
// 
//  File History
//
//   $Workfile: MyRegistry.cpp $
//   $Revision: 1 $  
//    $Modtime: 29.05.01 9:18 $
//
//   $Log: /DVB-PC/APP/TestAppUsbLcd/MyRegistry.cpp $
//     >>   
//     >>   1     10.07.01 14:48 Guido
//     >>   
//     >>   1     6.06.01 10:55 Guido
//     >>   
//     >>   2     16.05.01 15:11 Guido
//
///////////////////////////////////////////////////////////////////////////

// MyRegistry.cpp: Implementierung der Klasse CMyRegistry.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "stdafx.h"
#include "MyRegistry.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Konstruktion/Destruktion
//////////////////////////////////////////////////////////////////////

CMyRegistry::CMyRegistry()
{

}

CMyRegistry::~CMyRegistry()
{

}

BOOL CMyRegistry::ReadFromRegistry(const CString& from, const CString& name, CString& value)
{
	HKEY hKey1;
	BOOL res = FALSE;
	DWORD type;
	DWORD len = 200;

	if(ERROR_SUCCESS == RegOpenKeyEx(HKEY_LOCAL_MACHINE, from, 0, KEY_ALL_ACCESS, &hKey1))
	{
		if(ERROR_SUCCESS == RegQueryValueEx(hKey1, name, 0, &type, (BYTE*)value.GetBuffer(len), &len))
			if(type == REG_SZ)
				res = TRUE;

		value.ReleaseBuffer();
		RegCloseKey(hKey1);
	}
	return res;
}

BOOL CMyRegistry::ReadFromRegistry(const CString& from, const CString& name, DWORD& value)
{
	HKEY hKey1;
	BOOL res = FALSE;
	DWORD type;
	DWORD len = sizeof(DWORD);

	if(ERROR_SUCCESS == RegOpenKeyEx(HKEY_LOCAL_MACHINE, from, 0, KEY_ALL_ACCESS, &hKey1))
	{
		if(ERROR_SUCCESS == RegQueryValueEx(hKey1, name, 0, &type, (BYTE*)&value, &len))
			if(type == REG_DWORD)
				res = TRUE;

		RegCloseKey(hKey1);
	}
	return res;
}

BOOL CMyRegistry::ReadFromRegistry(const CString& from, const CString& name, int& value)
{
	DWORD dw;
	
	if(ReadFromRegistry(from, name, dw))
	{
		value = (int)dw;
		return TRUE;
	}
	return FALSE;
}

BOOL CMyRegistry::ReadFromRegistry(const CString& from, const CString& name, WORD& value)
{
	DWORD dw;
	
	if(ReadFromRegistry(from, name, dw))
	{
		value = (WORD)dw;
		return TRUE;
	}
	return FALSE;
}

BOOL CMyRegistry::SaveToRegistry(const CString& to, const CString& name, const CString& value)
{
	DWORD dwDisposition;
	HKEY hKey1;
	BOOL res = FALSE;

	if(ERROR_SUCCESS == RegCreateKeyEx(HKEY_LOCAL_MACHINE, to, 0, NULL,
										REG_OPTION_NON_VOLATILE, KEY_ALL_ACCESS,
										NULL, &hKey1, &dwDisposition))
	{
		if((name == "") && (value == ""))
			res = TRUE;
		else if(ERROR_SUCCESS == RegSetValueEx(hKey1, name, 0, REG_SZ, (const BYTE*)(LPCTSTR)value, value.GetLength()))
			res = TRUE;
		
		RegCloseKey(hKey1);
	}
	return res;
}

BOOL CMyRegistry::SaveToRegistry(const CString& to, const CString& name, const DWORD& value)
{
	DWORD dwDisposition;
	HKEY hKey1;
	BOOL res = FALSE;

	if(ERROR_SUCCESS == RegCreateKeyEx(HKEY_LOCAL_MACHINE, to, 0, NULL,
										REG_OPTION_NON_VOLATILE, KEY_ALL_ACCESS,
										NULL, &hKey1, &dwDisposition))
	{
		if((name == "") && (value == 0))
			res = TRUE;
		else if(ERROR_SUCCESS == RegSetValueEx(hKey1, name, 0, REG_DWORD, (const BYTE*)&value, sizeof(DWORD)))
			res = TRUE;
		
		RegCloseKey(hKey1);
	}
	return res;
}

BOOL CMyRegistry::SaveToRegistry(const CString& to, const CString& name, const int& value)
{
	DWORD dw = value;
	return SaveToRegistry(to, name, dw);
}

BOOL CMyRegistry::SaveToRegistry(const CString& to, const CString& name, const WORD& value)
{
	DWORD dw = value;
	return SaveToRegistry(to, name, dw);
}

BOOL CMyRegistry::DelFromRegistry(const CString& key, const CString& subkey)
{
	HKEY hKey1;
	BOOL res = FALSE;

	
	if(ERROR_SUCCESS == RegOpenKeyEx(HKEY_LOCAL_MACHINE, key, 0, KEY_ALL_ACCESS, &hKey1))
	{
		if(DelKey(subkey, hKey1)) // geht rekursiv vor (wegen Windows-NT)
			res = TRUE;

		//if(ERROR_SUCCESS == RegDeleteKey(hKey1, subkey))
		//	res = TRUE;
		//else if(ERROR_SUCCESS == RegDeleteValue(hKey1, subkey))
		//	res = TRUE;
		RegCloseKey(hKey1);			
	}
	return res;
}

// geht rekursiv vor (wegen Windows-NT)
BOOL CMyRegistry::DelKey(LPCTSTR pszKeyName, HKEY hParentKey)
{
	HKEY hSubKey;
	DWORD dwSubKeyCnt;
	DWORD dwMaxSubKey;
	LPTSTR pszSubKeyName;
	DWORD dwSubKeyNameLen;

	//if(m_hSubKey == 0)
	//	return FALSE;
	
	//if(hParentKey == 0)
	//	hParentKey = m_hSubKey;

	if(ERROR_SUCCESS != RegOpenKeyEx(hParentKey, pszKeyName, 0, KEY_WRITE | KEY_READ, &hSubKey))
		return FALSE;

	// delete the entire key. NOTE: Windows NT cannot delete
	// subkeys of the key, so we have to handle it ourself, so
	// the code will work on both: NT and 95.
	dwSubKeyCnt = 0;
	do 
	{	// first get an info about this subkey ...
		if(ERROR_SUCCESS != RegQueryInfoKey(hSubKey, 0,0,0, &dwSubKeyCnt, &dwMaxSubKey, 0,0,0,0,0,0))
		{
			RegCloseKey(hSubKey);
			return FALSE;
		}

		if(dwSubKeyCnt > 0) 
		{	// retrieve the first subkey and call DeleteKey() recursivly.
			// if such a call fails we have to break the deletion !
			// NOTE: that the initially key may stay "half removed" ...
			pszSubKeyName = new TCHAR [dwMaxSubKey + 1];
			dwSubKeyNameLen = dwMaxSubKey;
			if(ERROR_SUCCESS != RegEnumKey(hSubKey, 0, pszSubKeyName, dwSubKeyNameLen+1))
			{
				delete [] pszSubKeyName;
				RegCloseKey( hSubKey);
				return FALSE;
			}
			// Rekursion !!!
			if(! DelKey( pszSubKeyName, hSubKey))
			{
				delete [] pszSubKeyName;
				RegCloseKey(hSubKey);
				return FALSE;
			}
			delete [] pszSubKeyName;
		}
	} 
	while(dwSubKeyCnt > 0);
	
	RegCloseKey(hSubKey);

	if(ERROR_SUCCESS != RegDeleteKey(hParentKey, pszKeyName))
		return FALSE;

	return TRUE;
}

