//  TT  -  TechnoTrend  -  TT  -  TechnoTrend  -  TT  -  TechnoTrend  -  TT  
//
//
//  (C) TechnoTrend AG 1999-2001
//
//  All rights are reserved. Reproduction in whole or in part is prohibited 
//  without the written consent of the copyright owner. TechnoTrend 
//  reserves the right to make changes without notice at any time.  
//
//
//  TT  -  TechnoTrend  -  TT  -  TechnoTrend  -  TT  -  TechnoTrend  -  TT  
//
///////////////////////////////////////////////////////////////////////////
//
//  Filename:     OSDDlg.h
//
//  Project(s):   TestAppDvb
//
//  Author:       GRi
//
//  Purpose:      OSD/Remote-Control Dialog
//   
//  Environment:  Win32
//
//  Dev. Tool(s): MSVC 6.0
//
//  Note(s):      
// 
///////////////////////////////////////////////////////////////////////////
// 
//  File History
//
//   $Workfile: OSDDlg.h $
//   $Revision: 5 $  
//    $Modtime: 29.11.02 13:24 $
//
//   $Log: /DVB-PC/APP/TestAppUsbLcd/OSDDlg.h $
//     >>   
//     >>   5     29.11.02 14:50 Guido
//     >>   
//     >>   4     28.11.02 17:36 Guido
//     >>   
//     >>   3     25.05.02 16:05 Guido
//     >>   
//     >>   2     16.10.01 17:39 Guido
//     >>   
//     >>   1     10.07.01 14:48 Guido
//     >>   
//     >>   1     6.06.01 10:55 Guido
//     >>   
//     >>   9     16.05.01 15:11 Guido
//
///////////////////////////////////////////////////////////////////////////

#if !defined(AFX_OSDDLG_H__9415CFE5_A28E_4C24_B36E_EAF8B28AB33A__INCLUDED_)
#define AFX_OSDDLG_H__9415CFE5_A28E_4C24_B36E_EAF8B28AB33A__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// OSDDlg.h : Header-Datei
//

//#include <DVBOsd.h>
#include <DVBBoardControl.h>
#include <DVBRemoteControl.h>
#include <DVBFilterToFile.h>
#include "WorkerThread.h"

/////////////////////////////////////////////////////////////////////////////

class COSDDlg;

class CMyRemoteCtrl : public CDVBRemoteControl
{
public:
	COSDDlg* m_pOSDDlg;
private:
	void OnRemoteControlCode(BYTE* Buff, int len);
	CString m_strOut;
};

#ifdef _TTDVBLCD

class CMyTSRecord : protected CWorkerThread
{
public:
	BOOL Start(CString strFileName);
	BOOL Stop(void);

private:
	BOOL Run();
	CFile m_File;
	CDVBBoardControl m_BoardControl;
	DWORD m_tc, m_cnt;
};

#endif

/////////////////////////////////////////////////////////////////////////////
// Dialogfeld COSDDlg 

class COSDDlg : public CDialog
{
// Konstruktion
public:
	COSDDlg(CWnd* pParent = NULL);   // Standardkonstruktor

	BOOL TimerEvent(void);

// Dialogfelddaten
	//{{AFX_DATA(COSDDlg)
	enum { IDD = IDD_OSD_DLG };
	CString	m_strPipingPID;
	CString	m_strFN;
	//}}AFX_DATA


// �berschreibungen
	// Vom Klassen-Assistenten generierte virtuelle Funktions�berschreibungen
	//{{AFX_VIRTUAL(COSDDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV-Unterst�tzung
	//}}AFX_VIRTUAL

// Implementierung
protected:

	// Generierte Nachrichtenzuordnungsfunktionen
	//{{AFX_MSG(COSDDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnDestroy();
	afx_msg void OnMacAddr();
	afx_msg void OnMcList();
	afx_msg void OnIpSm();
	virtual void OnOK();
	virtual void OnCancel();
	afx_msg void OnButtonStart();
	afx_msg void OnButtonStop();
	afx_msg void OnButtonIrOn();
	afx_msg void OnButtonIrOff();
	afx_msg void OnGetVersions();
	afx_msg void OnButtonTsStart();
	afx_msg void OnButtonTsStop();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

private:
	BOOL GetExePath(CString& ExePath);

//	CDVBOsd m_OSD;
	CDVBBoardControl m_BoardControl;
	CMyRemoteCtrl m_RemoteCtrl;
	CDVBFilterToFile m_FilterToFile;
#ifdef _TTDVBLCD	
	CMyTSRecord m_TSRecord;
#endif
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ f�gt unmittelbar vor der vorhergehenden Zeile zus�tzliche Deklarationen ein.

#endif // AFX_OSDDLG_H__9415CFE5_A28E_4C24_B36E_EAF8B28AB33A__INCLUDED_
