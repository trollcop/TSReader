//  TT  -  TechnoTrend  -  TT  -  TechnoTrend  -  TT  -  TechnoTrend  -  TT  
//
//
//  (C) TechnoTrend AG 1999-2001
//
//  All rights are reserved. Reproduction in whole or in part is prohibited 
//  without the written consent of the copyright owner. TechnoTrend 
//  reserves the right to make changes without notice at any time.  
//
//
//  TT  -  TechnoTrend  -  TT  -  TechnoTrend  -  TT  -  TechnoTrend  -  TT  
//
///////////////////////////////////////////////////////////////////////////
//
//  Filename:     FilterDlg.cpp
//
//  Project(s):   TestAppDvb
//
//  Author:       GRi
//
//  Purpose:      FilterDlg.cpp
//   
//  Environment:  Win32
//
//  Dev. Tool(s): MSVC 6.0
//
//  Note(s):      
// 
///////////////////////////////////////////////////////////////////////////
// 
//  File History
//
//   $Workfile: FilterDlg.cpp $
//   $Revision: 2 $  
//    $Modtime: 19.07.01 9:43 $
//
//   $Log: /DVB-PC/APP/TestAppUsbLcd/FilterDlg.cpp $
//     >>   
//     >>   2     19.07.01 11:31 Guido
//     >>   
//     >>   1     10.07.01 14:48 Guido
//     >>   
//     >>   1     6.06.01 10:55 Guido
//     >>   
//     >>   5     16.05.01 15:11 Guido
//
///////////////////////////////////////////////////////////////////////////

// FilterDlg.cpp: Implementierungsdatei
//

#include "stdafx.h"
#include "dvbmpe.h"
#include "FilterDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

extern CString DVBMPE_REGISTRY_START_STRING;

/////////////////////////////////////////////////////////////////////////////
// Dialogfeld CFilterDlg 

CFilterDlg::CFilterDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CFilterDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CFilterDlg)
	m_strDefBCPID = _T("512");
	m_strDefMCPID = _T("785");
	m_strDefUCPID = _T("512");
	m_bMCtoPID = TRUE;
	//}}AFX_DATA_INIT
}

void CFilterDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CFilterDlg)
	DDX_Control(pDX, IDC_FLIST, m_ctrlFilterList);
	DDX_Text(pDX, IDC_EDIT_UCPID, m_strDefUCPID);
	DDX_Text(pDX, IDC_EDIT_MCPID, m_strDefMCPID);
	DDX_Text(pDX, IDC_EDIT_BCPID, m_strDefBCPID);
	DDX_Check(pDX, IDC_CHECK_EOL_MCPID, m_bMCtoPID);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CFilterDlg, CDialog)
	//{{AFX_MSG_MAP(CFilterDlg)
	ON_WM_DESTROY()
	ON_BN_CLICKED(IDC_CHECK_EOL_MCPID, OnCheckEOLMCPID)
	ON_BN_CLICKED(IDC_BUTTON_APPLY, OnButtonApply)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// Behandlungsroutinen f�r Nachrichten CFilterDlg 

BOOL CFilterDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Zus�tzliche Initialisierung hier einf�gen

	DVB_ERROR error;
	CString s;
	int i;
	DWORD oid, l3b, _ip, _sm;
	WORD bp;
	BYTE ip[4];

	error = m_BoardControl.GetMulticastList(m_MCI);
	if (error != DVB_ERR_NONE)
		MessageBox("BoardControl.GetMulticastList not successful.", "Error");

	error = m_BoardControl.GetMACAddress(oid, l3b);
	if (error == DVB_ERR_NONE)
	{
		m_strUCMAC.Format("%06x%06x", oid, l3b);
		m_strUCMAC.MakeUpper();
	}
	else
	{
		m_strUCMAC.Format("000000000000");
		MessageBox("BoardControl.GetMAC not successful.", "Error");
	}
	
	error = m_BoardControl.Get_IP_SM_BP(_ip, _sm, bp);
	if (error == DVB_ERR_NONE)
	{
		*(DWORD*)ip = _ip;
		m_strUCIP.Format("%u.%u.%u.%u", ip[0],ip[1],ip[2],ip[3]);
	}
	else
	{
		MessageBox("BoardControl.GetIP not successful.", "Error");
		m_strUCIP = "0.0.0.0";
	}


	DWORD dwStyle;
	RECT rect;
	LONG width;

	dwStyle = m_ctrlFilterList.GetExtendedStyle();
	dwStyle |= LVS_EX_FULLROWSELECT;
	m_ctrlFilterList.SetExtendedStyle(dwStyle);

	m_ctrlFilterList.GetClientRect(&rect);
	width = rect.right;
	m_ctrlFilterList.InsertColumn( 0, "PID",   LVCFMT_LEFT, 9*width/100); //40
	m_ctrlFilterList.InsertColumn( 1, "Set",   LVCFMT_LEFT, 9*width/100); //40
	m_ctrlFilterList.InsertColumn( 2, "MAC",   LVCFMT_LEFT, 24*width/100); //100
	m_ctrlFilterList.InsertColumn( 3, "IP",    LVCFMT_LEFT, 24*width/100); //105
	m_ctrlFilterList.InsertColumn( 4, "Bytes", LVCFMT_LEFT, 15*width/100); //50
	m_ctrlFilterList.InsertColumn( 5, "kBit/s",LVCFMT_LEFT, 14*width/100); //50

	for(i=0; i<MAX_MCF; i++) // Multicast-Filter-Arrays initialisieren
	{
		m_FMCArr[i].pF = NULL;
		m_FMCArr[i].strPID = ""; m_FMCArr[i].strMAC = "";
	}
	m_FUC.pF = &m_UCFilter;		// unicast
	m_FUC.strPID = ""; m_FUC.strMAC = "";
	m_FBC.pF = &m_BCFilter;		// broadcast
	m_FBC.strPID = ""; m_FBC.strMAC = "";
	
	m_dwOldTime = GetTickCount();
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX-Eigenschaftenseiten sollten FALSE zur�ckgeben
}

void CFilterDlg::OnDestroy() 
{
	CDialog::OnDestroy();
	
	// TODO: Code f�r die Behandlungsroutine f�r Nachrichten hier einf�gen
	if(m_FUC.pF->GetFilterID() != 0)
		PIDFilterUnset(m_FUC.pF);

	if(m_FBC.pF->GetFilterID() != 0)
		PIDFilterUnset(m_FBC.pF);

	for(int k=0; k<MAX_MCF; k++)
	{
		if(m_FMCArr[k].pF != NULL)
		{
			PIDFilterUnset(m_FMCArr[k].pF);
			delete m_FMCArr[k].pF;
		}
	}
}

void CFilterDlg::CheckDelFilters(CDVBBoardControl::MULTICAST_LIST& MCI)
{
	int i, k;
	DWORD j;
	BOOL found, found2;
	CString strMAC, strIP, strPID;
	
	strPID.Format("%u", m_wDefUCPID);

	// Unicast-Filter l�schen, wenn nicht gefordert und bereits gesetzt
	if(!(MCI.PacketFilter & DVB_PACKET_DIRECTED) && (m_FUC.pF->GetFilterID() != 0))
		for(i=0; i<m_ctrlFilterList.GetItemCount(); i++)
			if(m_ctrlFilterList.GetItemText(i, 1) == "UC")
				if(PIDFilterUnset(m_FUC.pF))
				{	m_ctrlFilterList.SetItemText(i, 1, "");
					m_FUC.strPID = "";
					m_FUC.strMAC = "";
				}

	// Broadcast-Filter l�schen, wenn nicht gefordert und bereits gesetzt
	if(!(MCI.PacketFilter & DVB_PACKET_BROADCAST) && (m_FBC.pF->GetFilterID() != 0))
		for(i=0; i<m_ctrlFilterList.GetItemCount(); i++)
			if(m_ctrlFilterList.GetItemText(i, 1) == "BC")
				if(PIDFilterUnset(m_FBC.pF))
				{	m_ctrlFilterList.SetItemText(i, 1, "");
					m_FBC.strPID = "";
					m_FBC.strMAC = "";
				}
	
	// alle Multicast-Filter l�schen, wenn nicht gefordert
	if(!(MCI.PacketFilter & DVB_PACKET_MULTICAST))
	{	for(i=0; i<MAX_MCF; i++) // alle Filter l�schen
		{	if(m_FMCArr[i].pF != NULL)
			{	PIDFilterUnset(m_FMCArr[i].pF);
				delete m_FMCArr[i].pF;
				m_FMCArr[i].pF = NULL;
				m_FMCArr[i].strPID = "";
				m_FMCArr[i].strMAC = "";
			}
		}
		// aus Liste entfernen
		for(i=m_ctrlFilterList.GetItemCount()-1; i>=0; i--)
		{	if(m_ctrlFilterList.GetItemText(i, 1) == "MC")
			{	m_ctrlFilterList.SetItemText(i, 1, "");
			}
		}
	}
	else // nur nicht mehr geforderte Multicast-Filter l�schen
	{	for(i=0; i<MAX_MCF; i++)
		{	if(m_FMCArr[i].pF != NULL)
			{	found = FALSE;
				for(j=0; j<MCI.MulticastListInUse; j++)
				{	strMAC.Format("%02X%02X%02X%02X%02X%02X", MCI.AddressList[j][0], MCI.AddressList[j][1], MCI.AddressList[j][2], MCI.AddressList[j][3], MCI.AddressList[j][4], MCI.AddressList[j][5]);
					if(m_FMCArr[i].strMAC == strMAC)
					{	found = TRUE;
						break;
					}
				}
				if(!found) // nicht mehr in Multicast-Liste, also l�schen!
				{	if(PIDFilterUnset(m_FMCArr[i].pF)) // aus Liste entfernen
					{	found2 = FALSE;
						for(k=0; k<m_ctrlFilterList.GetItemCount(); k++)
						{	if((m_FMCArr[i].strMAC == m_ctrlFilterList.GetItemText(k, 2)) && (m_ctrlFilterList.GetItemText(k, 1) == "MC"))
							{	m_ctrlFilterList.SetItemText(k, 1, "");
								found2 = TRUE;
								break;
							}
						}
						// Filter l�schen
						delete m_FMCArr[i].pF;
						m_FMCArr[i].pF = NULL;
						m_FMCArr[i].strPID = "";
						m_FMCArr[i].strMAC = "";
					}
				}
			}
		}
	}
}

void CFilterDlg::CheckSetFilters(CDVBBoardControl::MULTICAST_LIST& MCI)
{
	CString regstr, strPID, strMAC, strIP, strMCMAC, strSet; //, strRange, strOnOff;
	DWORD j;
	BOOL found;
	in_addr IP;
	int i, k;
	WORD wFH, wPID;

	// Unicast-Filter setzen, wenn gefordert und nicht bereits gesetzt
	if((MCI.PacketFilter & DVB_PACKET_DIRECTED)  && (m_FUC.pF->GetFilterID() == 0))
	{
		found = FALSE;
		for(i=0; i<m_ctrlFilterList.GetItemCount(); i++)
		{
			strMAC = m_ctrlFilterList.GetItemText(i, 2);

			if(strMAC == m_strUCMAC)
			{
				strPID   = m_ctrlFilterList.GetItemText(i, 0);
				strSet   = m_ctrlFilterList.GetItemText(i, 1);
				found = TRUE;
				break;
			}
		}
		if(!found)
		{
			if(m_wDefUCPID != 0)
				strPID.Format("%u", m_wDefUCPID);
			else
				strPID = "-";

			strSet = "";
			strMAC = m_strUCMAC;
			strIP  = m_strUCIP;
			m_ctrlFilterList.InsertItem(0,  strPID);
			m_ctrlFilterList.SetItemText(0,1, strSet);
			m_ctrlFilterList.SetItemText(0,2, strMAC);
			m_ctrlFilterList.SetItemText(0,3, strIP );
		}

		if((strPID != "-") && (PIDFilterSet(m_FUC.pF, (WORD)atoi(strPID), strMAC, 6, TRUE)))
		{
			m_FUC.strPID = strPID;
			m_FUC.strMAC = strMAC;
			wFH = m_FUC.pF->GetFilterID();
			
			if(wFH < MAX_FTR)
			{
				m_dwArrStatistik[wFH] = m_dwArrStatistik2[wFH];
				m_fArrkBit[wFH][0] = m_fArrkBit[wFH][1] = m_fArrkBit[wFH][2] = 0;
				m_dwArrStatistikS[wFH] = 0;
			}
			else
			{
				TRACE("UC-Filter-Handle out of range (%u)\n", wFH);
			}

			if(found)
				m_ctrlFilterList.SetItemText(i,1, "UC");
			else
				m_ctrlFilterList.SetItemText(0,1, "UC");
		}
	}
	
	// Broadcast-Filter setzen, wenn gefordert und nicht bereits gesetzt
	if((MCI.PacketFilter & DVB_PACKET_BROADCAST) && (m_FBC.pF->GetFilterID() == 0))
	{
		found = FALSE;
		for(i=0; i<m_ctrlFilterList.GetItemCount(); i++)
		{
			strMAC   = m_ctrlFilterList.GetItemText(i, 2);

			if(strMAC == "FFFFFFFFFFFF")
			{
				strPID   = m_ctrlFilterList.GetItemText(i, 0);
				strSet   = m_ctrlFilterList.GetItemText(i, 1);
				found = TRUE;
				break;
			}
		}
		if(!found)
		{
			if(m_wDefBCPID != 0)
				strPID.Format("%u", m_wDefBCPID);
			else
				strPID = "-";

			strSet = "";
			strMAC = "FFFFFFFFFFFF";
			strIP  = "255.255.255.255";
			m_ctrlFilterList.InsertItem(0,  strPID);
			m_ctrlFilterList.SetItemText(0,1, strSet);
			m_ctrlFilterList.SetItemText(0,2, strMAC);
			m_ctrlFilterList.SetItemText(0,3, strIP );
		}

		if((strPID != "-") && (PIDFilterSet(m_FBC.pF, (WORD)atoi(strPID), strMAC, 6, FALSE)))
		{
			m_FBC.strPID = strPID;
			m_FBC.strMAC = strMAC;
			wFH = m_FBC.pF->GetFilterID();
			
			if(wFH < MAX_FTR)
			{
				m_dwArrStatistik[wFH] = m_dwArrStatistik2[wFH];
				m_fArrkBit[wFH][0] = m_fArrkBit[wFH][1] = m_fArrkBit[wFH][2] = 0;
				m_dwArrStatistikS[wFH] = 0;
			}
			else
			{
				TRACE("BC-Filter-Handle out of range (%u)\n", wFH);
			}
			
			if(found)
				m_ctrlFilterList.SetItemText(i,1, "BC");
			else
				m_ctrlFilterList.SetItemText(0,1, "BC");
		}
	}

	// Multicast-Filter setzen, wenn gefordert und nicht bereits gesetzt
	if(MCI.PacketFilter & DVB_PACKET_MULTICAST)
	{
		for(j=0; j<MCI.MulticastListInUse; j++)
		{
			strMCMAC.Format("%02X%02X%02X%02X%02X%02X", MCI.AddressList[j][0], MCI.AddressList[j][1], MCI.AddressList[j][2], MCI.AddressList[j][3], MCI.AddressList[j][4], MCI.AddressList[j][5]);
			found = FALSE;
			for(i=0; i<m_ctrlFilterList.GetItemCount(); i++)
			{
				strMAC =   m_ctrlFilterList.GetItemText(i, 2);
				if(strMAC == strMCMAC)
				{
					strPID   = m_ctrlFilterList.GetItemText(i, 0);
					strSet   = m_ctrlFilterList.GetItemText(i, 1);
					found = TRUE;
					break;
				}
			}
			if(!found)
			{
				if(m_bMCtoPID) // NEU MCtoPID
				{	
					wPID = (((WORD)(MCI.AddressList[j][4])<<8) | MCI.AddressList[j][5]) & 0x1fff;
					
					if((wPID > 15) && (wPID < 8191)) // g�ltiger PID Bereich
						strPID.Format("%u", wPID);
					else
						strPID = "-";
				}
				else if(m_wDefMCPID != 0) // if(((WORD)strtoul(m_strMCPID, NULL, 0)) != 0)
				{	
					strPID.Format("%u", m_wDefMCPID);
				}
				else
				{	
					strPID = "-";
				}
				strSet = "";
				strMAC = strMCMAC;
				IP.S_un.S_addr = 0xe0000000 | (strtoul(strMCMAC.Right(8), NULL, 16) & 0x7fffff);
				IP.S_un.S_addr = htonl(IP.S_un.S_addr);
				strIP = inet_ntoa(IP);
				m_ctrlFilterList.InsertItem(0,  strPID);
				m_ctrlFilterList.SetItemText(0,1, strSet);
				m_ctrlFilterList.SetItemText(0,2, strMAC);
				m_ctrlFilterList.SetItemText(0,3, strIP ); 
			}

			if((!found) || (found && (strSet == "") && (strPID != "-")))
			{
				for(k=0; k<MAX_MCF; k++)
					if(m_FMCArr[k].pF == NULL)
						break;

				if(k<MAX_MCF)
				{
					m_FMCArr[k].pF = new CDVBTSFilter();

					if(m_FMCArr[k].pF != NULL)
					{
						if(PIDFilterSet(m_FMCArr[k].pF, (WORD)atoi(strPID), strMAC, 6, FALSE))
						{
							m_FMCArr[k].strPID = strPID; 
							m_FMCArr[k].strMAC = strMAC;
							wFH = m_FMCArr[k].pF->GetFilterID();
							
							if(wFH < MAX_FTR)
							{
								m_dwArrStatistik[wFH] = m_dwArrStatistik2[wFH];
								m_fArrkBit[wFH][0] = m_fArrkBit[wFH][1] = m_fArrkBit[wFH][2] = 0;
								m_dwArrStatistikS[wFH] = 0;
							}
							else
							{
								TRACE("MC-Filter-Handle out of range (%u)\n", wFH);
							}
							
							if(found)
								m_ctrlFilterList.SetItemText(i,1, "MC");
							else
								m_ctrlFilterList.SetItemText(0,1, "MC");
						}
						else
						{
							delete m_FMCArr[k].pF;
							m_FMCArr[k].pF = NULL;
							m_FMCArr[k].strPID = "";
							m_FMCArr[k].strMAC = "";
						}
					}
				}
			}
		}
	}
}

BOOL CFilterDlg::PIDFilterSet(CDVBTSFilter* f, WORD PID, CString& MAC, BYTE Range, BOOL HighSpeed)
{
	DVB_ERROR err;
	BYTE bFilterData[12] = {0,0,0,0,0,0,0,0,0,0,0,0};
	BYTE bFilterMask[12] = {0xff,00,00,0xff,0xff,00,00,00,0xff,0xff,0xff,0xff};
	BYTE bFilterLength = 12;
	BYTE MacAddress[6];
	char SABuf[] = "00";
	
	if((Range > 6) || (MAC.GetLength() < 12))
		return FALSE;

	if((PID < 16) || (PID > 8190))
		return FALSE;

	bFilterLength = (Range>2)?(Range+6):(Range>0)?(Range+3):(Range+1);

	for (int j=0; j<6; j++)
	{	
		SABuf[0] = MAC[j*2]; SABuf[1] = MAC[j*2+1];
		MacAddress[j] = (BYTE)(strtoul(SABuf, NULL, 16));
	}
	bFilterData[0] = 0x3e;
	bFilterData[3] = MacAddress[5]; bFilterData[4] = MacAddress[4];
	bFilterData[8] = MacAddress[3]; bFilterData[9] = MacAddress[2];
	bFilterData[10]= MacAddress[1]; bFilterData[11]= MacAddress[0];
	
	//if(!HighSpeed){
		err = f->SetFilter(CDVBTSFilter::MPE_SECTION_FILTER, PID, bFilterData, bFilterMask, bFilterLength);
	//}
	//else{
	//	err = f->SetFilter(CDVBTSFilter::MPE_SECTION_HIGHSPEED, PID, bFilterData, bFilterMask, bFilterLength);
	//}
	
	//TRACE("PIDFilterSet\n");
	
	if (err == DVB_ERR_NONE)
	{ 
		return TRUE;
	}
	else
	{
		TRACE("SetBitFilter(...) failed (%i).\n", err);
		return FALSE;
	}
}

BOOL CFilterDlg::PIDFilterUnset(CDVBTSFilter* f)
{
	DVB_ERROR err;

	if(f != NULL)
	{
		err = f->ResetFilter();

		//TRACE("PIDFilterUnset\n");
		
		if(err == DVB_ERR_NONE)
		{
			return TRUE;
		}
		else
		{
			TRACE("ShutDownFilter() failed (%i).\n", err);
			return FALSE;
		}
	}
	TRACE("Filter already down (f == NULL) !!!");
	return FALSE;
}

void CFilterDlg::OnOK() 
{

}

void CFilterDlg::OnCancel() 
{

}

BOOL CFilterDlg::TimerEvent(void)
{
	DVB_ERROR err1, err2;
	BOOL ret = FALSE;

	err1 = CDVBTSFilter::GetFiltersByteCount(m_dwArrStatistik2, MAX_FTR);

	err2 = m_BoardControl.GetMulticastList(m_MCI);

	if (err2 == DVB_ERR_NONE)
	{
		CheckDelFilters(m_MCI);
		CheckSetFilters(m_MCI);
	}

	if (err1 == DVB_ERR_NONE)
	{
		ret = CalcAndFillStatistics();
	}
	
	return ret;
}

BOOL CFilterDlg::CalcAndFillStatistics()
{
	int i, j;
	CString strSet, strkBit, strMAC, strPID;
	WORD wFH;
	float fkBit, sum_fkBit;
	DWORD dwActTime, diff;
	BOOL visible;

	dwActTime = GetTickCount();
	diff = dwActTime - m_dwOldTime;
	m_dwOldTime = dwActTime;

	visible = this->IsWindowVisible();


	sum_fkBit = 0;

	for(i=m_ctrlFilterList.GetItemCount()-1; i>=0; i--)
	{
		wFH = 1000;
		strSet = m_ctrlFilterList.GetItemText(i, 1);
		if((strSet == "UC") || (strSet == "BC") || (strSet == "MC"))
		{
			strPID = m_ctrlFilterList.GetItemText(i, 0);
			strMAC = m_ctrlFilterList.GetItemText(i, 2);

			if(strSet == "UC")
			{
				wFH = m_FUC.pF->GetFilterID();
			}
			else if(strSet == "BC")
			{
				wFH = m_FBC.pF->GetFilterID();
			}
			else if(strSet == "MC")
			{
				for(j=0; j<MAX_MCF; j++)
				{
					if(m_FMCArr[j].pF != NULL)
					{
						if((m_FMCArr[j].strPID == strPID) && (m_FMCArr[j].strMAC == strMAC))
						{
							wFH = m_FMCArr[j].pF->GetFilterID();
							break;
						}
					}
				}
			}
			if(wFH < MAX_FTR)
			{
				m_dwArrStatistikS[wFH] += (m_dwArrStatistik2[wFH] - m_dwArrStatistik[wFH]);
				if(visible)
				{
					strkBit.Format("%I64i", m_dwArrStatistikS[wFH]);
					m_ctrlFilterList.SetItemText(i,4, strkBit);
				}
				m_fArrkBit[wFH][2] = m_fArrkBit[wFH][1];
				m_fArrkBit[wFH][1] = m_fArrkBit[wFH][0];
				m_fArrkBit[wFH][0] = (float)(m_dwArrStatistik2[wFH] - m_dwArrStatistik[wFH]) * (float)8 / (float)diff;
				fkBit = (m_fArrkBit[wFH][0] + m_fArrkBit[wFH][1] + m_fArrkBit[wFH][2]) / 3;
				sum_fkBit += fkBit;
				if(visible)
				{
					strkBit.Format("%.3f", fkBit);
					m_ctrlFilterList.SetItemText(i,5, strkBit);
				}
			}
		}
		else
		{
			m_ctrlFilterList.SetItemText(i,4, "");
			m_ctrlFilterList.SetItemText(i,5, "");
		}
	}
	if(visible)
	{
		strkBit.Format("%.3f", sum_fkBit);
		this->GetDlgItem(IDC_DATA_RATE)->SetWindowText(strkBit);
	}
	for(i=0; i<MAX_FTR; i++)
		m_dwArrStatistik[i] = m_dwArrStatistik2[i];

	if(sum_fkBit > 0)
		return TRUE;
	else
		return FALSE;
}

void CFilterDlg::SettingsSaveToRegistry()
{
	CString s, to;

	to = DVBMPE_REGISTRY_START_STRING;
	to += m_strActProfile + "\\Settings";

	// FilterOptions-Dialog
//	m_myReg.SaveToRegistry(to, "UC_IP", m_strUCIP);
	
	m_myReg.SaveToRegistry(to, "DefBC_PID", m_wDefBCPID);	
	m_myReg.SaveToRegistry(to, "DefMC_PID", m_wDefMCPID);	
	m_myReg.SaveToRegistry(to, "DefUC_PID", m_wDefUCPID);	
	m_myReg.SaveToRegistry(to, "MCtoPID",     m_bMCtoPID);
}

void CFilterDlg::SettingsReadFromRegistry()
{
	CString from;

	from = DVBMPE_REGISTRY_START_STRING;
	from += m_strActProfile + "\\Settings";

	// FilterOptions-Dialog
//	if(! m_myReg.ReadFromRegistry(from, "UC_IP", m_strUCIP))
//		m_strUCIP = "0.0.0.0";
	
	if(! m_myReg.ReadFromRegistry(from, "DefUC_PID", m_wDefUCPID))
		m_wDefUCPID = 512;

	if(! m_myReg.ReadFromRegistry(from, "DefBC_PID", m_wDefBCPID))
		m_wDefBCPID = 512;
	
	if(! m_myReg.ReadFromRegistry(from, "DefMC_PID", m_wDefMCPID))
		m_wDefMCPID = 0;
	
	if(! m_myReg.ReadFromRegistry(from, "MCtoPID", m_bMCtoPID))
		m_bMCtoPID = TRUE;
}

void CFilterDlg::ProfileEvent(const CString& newProfile, const CString& cpyProfile)
{
	if(cpyProfile == "")
	{
		m_strActProfile = newProfile;
		SettingsReadFromRegistry();

		m_strDefBCPID.Format("%u", m_wDefBCPID);
		m_strDefMCPID.Format("%u", m_wDefMCPID);
		m_strDefUCPID.Format("%u", m_wDefUCPID);

		UpdateData(FALSE); // Dialog aktualisieren
		
		SetValuesEvent(); // gelesende Werte setzen, Settings speichern
	}
	else
	{
		m_strActProfile = cpyProfile;
		SettingsReadFromRegistry();

		m_strDefBCPID.Format("%u", m_wDefBCPID);
		m_strDefMCPID.Format("%u", m_wDefMCPID);
		m_strDefUCPID.Format("%u", m_wDefUCPID);

		UpdateData(FALSE); // Dialog aktualisieren

		m_strActProfile = newProfile;
		SetValuesEvent(); // gelesende Werte setzen, Settings speichern
	}
}

void CFilterDlg::SetValuesEvent()
{
	UpdateData(TRUE);

	m_wDefBCPID = (WORD)strtoul(m_strDefBCPID, NULL, 10);
	m_wDefMCPID = (WORD)strtoul(m_strDefMCPID, NULL, 10);
	m_wDefUCPID = (WORD)strtoul(m_strDefUCPID, NULL, 10);

	// Werte in der Registry merken (f�r den n�chsten Start)
	SettingsSaveToRegistry();

	m_strDefBCPID.Format("%u", m_wDefBCPID);
	m_strDefMCPID.Format("%u", m_wDefMCPID);
	m_strDefUCPID.Format("%u", m_wDefUCPID);

	UpdateData(FALSE);

	OnCheckEOLMCPID();


	if(m_FUC.pF->GetFilterID() != 0)
	{
		PIDFilterUnset(m_FUC.pF);
		m_FUC.strPID = ""; m_FUC.strMAC = "";
	}
	if(m_FBC.pF->GetFilterID() != 0)
	{
		PIDFilterUnset(m_FBC.pF);
		m_FBC.strPID = ""; m_FBC.strMAC = "";
	}
	for(int i=0; i<MAX_MCF; i++)
	{
		if(m_FMCArr[i].pF != NULL)
		{
			PIDFilterUnset(m_FMCArr[i].pF);
			delete m_FMCArr[i].pF;
			m_FMCArr[i].pF = NULL;
			m_FMCArr[i].strPID = ""; m_FMCArr[i].strMAC = "";
		}
	}
	m_ctrlFilterList.DeleteAllItems();

	for(i=0; i<MAX_FTR; i++) // Statistik Array l�schen
	{
		m_dwArrStatistik[i] = 0;
		m_fArrkBit[i][0] = m_fArrkBit[i][1] = m_fArrkBit[i][2] = 0;
		m_dwArrStatistikS[i] = 0;
	}
}

void CFilterDlg::OnCheckEOLMCPID() 
{
	UpdateData(TRUE);
	if(m_bMCtoPID)
		GetDlgItem(IDC_EDIT_MCPID)->EnableWindow(FALSE);
	else
		GetDlgItem(IDC_EDIT_MCPID)->EnableWindow(TRUE);
}

void CFilterDlg::OnButtonApply() 
{
	BeginWaitCursor();
	SetValuesEvent(); // gelesende Werte setzen, Settings speichern
	EndWaitCursor();
}

