// CIDlg.cpp: Implementierungsdatei
//

#include "stdafx.h"
#include "dvbmpe.h"
#include "CIDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


#ifdef _TTDVBLCD

/////////////////////////////////////////////////////////////////////////////
// Dialogfeld CCIDlg 


CCIDlg::CCIDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CCIDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CCIDlg)
	m_strPNR = _T("");
	m_bVideoPort = FALSE;
	//}}AFX_DATA_INIT
	m_ActCAM = 0;
}


void CCIDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CCIDlg)
	DDX_Text(pDX, IDC_PNR, m_strPNR);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CCIDlg, CDialog)
	//{{AFX_MSG_MAP(CCIDlg)
	ON_BN_CLICKED(IDC_OPEN_CI, OnOpenCi)
	ON_BN_CLICKED(IDC_CLOSE_CI, OnCloseCi)
	ON_BN_CLICKED(IDC_SEND_ANS, OnSendAns)
	ON_BN_CLICKED(IDC_CANCEL_SEND, OnCancelSend)
	ON_BN_CLICKED(IDC_SET_PROGRAMME, OnSetProgramme)
	ON_BN_CLICKED(IDC_SLOT0, OnSlot0)
	ON_BN_CLICKED(IDC_SLOT1, OnSlot1)
	ON_WM_DESTROY()
	//}}AFX_MSG_MAP
	ON_COMMAND_RANGE(IDC_BUTTON_K0,IDC_BUTTON_K9,OnKeyPressed)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// Behandlungsroutinen f�r Nachrichten CCIDlg 

BOOL CCIDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Zus�tzliche Initialisierung hier einf�gen

	CEdit	*pEdit;
	pEdit=(CEdit*)(GetDlgItem(IDC_ANS));
	pEdit->SetWindowText("1234");
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX-Eigenschaftenseiten sollten FALSE zur�ckgeben
}

void CCIDlg::OnDestroy() 
{
	CDialog::OnDestroy();
	
	m_CI.Close();
}

void CCIDlg::OnOK() 
{

}

void CCIDlg::OnCancel() 
{

}

void CCIDlg::OnOpenCi() 
{
	m_CI.Open(this);
	m_CI.GetSlotStatus(m_ActCAM); // 0 ???
}

void CCIDlg::OnCloseCi() 
{
	m_CI.Close();
}

void CCIDlg::OnSetProgramme() 
{
	UpdateData(TRUE);
	WORD wPNR = (WORD)strtoul(m_strPNR, NULL, 0);

	//m_CI.SetProgram(WORD(wPNR));
	if(m_CI.ReadPSIFast(wPNR) != DVB_ERR_NONE)
		MessageBox("Error in ReadPSIFast!");
}

void CCIDlg::MarkActiveCAM()
{
	switch(m_ActCAM){
	 case 0:
			SetDlgItemText(IDC_CAM1_ACTIVE,"");
			SetDlgItemText(IDC_CAM0_ACTIVE,"active");
		 break;
	 case 1:
			SetDlgItemText(IDC_CAM1_ACTIVE,"active");
			SetDlgItemText(IDC_CAM0_ACTIVE,"");
		 break;
	 default:
			SetDlgItemText(IDC_CAM1_ACTIVE,"");
			SetDlgItemText(IDC_CAM0_ACTIVE,"");
		break;
	}
}

void CCIDlg::OnSlot0() 
{
	m_ActCAM = 0;
	MarkActiveCAM();
	m_CI.EnterModuleMenu(0);
}

void CCIDlg::OnSlot1() 
{
	m_ActCAM = 1;
	MarkActiveCAM();
	m_CI.EnterModuleMenu(1);
}

void CCIDlg::OnSendAns() 
{
	char	answer[32],i;
	CEdit	*pEdit;
	CString	string;
	
	pEdit=(CEdit*)(GetDlgItem(IDC_ANS));
	pEdit->GetWindowText(string);
	if(string.GetLength() != m_CI.GetAnswerLength())
	{
		TRACE("OnSendAns wrong answer length %d",string.GetLength());
		SetDlgItemText(IDC_INFOS,"OnSendAns wrong answer length");
		return;
	}
	for(i=0;i<m_CI.GetAnswerLength();i++){
		answer[i]=string.GetAt(i);
	}
	answer[i]=0;
	TRACE("answer = %s  ",string);
	MarkActiveCAM();
	m_CI.Answer(m_ActCAM, answer, m_CI.GetAnswerLength());	
}

void CCIDlg::OnCancelSend() 
{
	char dummy[32];
	MarkActiveCAM();
	m_CI.Answer(m_ActCAM, dummy, 0);	
}

void CCIDlg::OnKeyPressed(UINT nID)
{
CString s="",s2;
/*
	//if key in valid range
	if(m_CI.m_nKeyBufferIndex == m_CI.GetAnswerLength())
	{
		TRACE("key events not valid at this time\n");
		return;
	}

	m_CI.m_nKeyBuffer[m_CI.m_nKeyBufferIndex++]=nID - IDC_k0;

	for(int i=0;i<m_CI.m_nKeyBufferIndex;i++)
	{
		if(m_CI.m_bBlindAnswer)
			s2="* ";
		else
			s2.Format("%02X ",m_CI.m_nKeyBuffer[i]);

		s += s2;
	}

	SetDlgItemText(IDC_KEYBOARD,s);

	if(m_CI.m_nKeyBufferIndex == m_CI.GetAnswerLength())
		m_CI.InputReply(1,m_CI.m_nKeyBuffer,m_CI.m_nKeyBufferIndex);
*/
	MarkActiveCAM();
	m_CI.MenuAnswer(m_ActCAM, nID - IDC_BUTTON_K0);

};

#endif // _TTDVBLCD

