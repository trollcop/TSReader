//  TT  -  TechnoTrend  -  TT  -  TechnoTrend  -  TT  -  TechnoTrend  -  TT  
//
//
//  (C) TechnoTrend AG 1999-2001
//
//  All rights are reserved. Reproduction in whole or in part is prohibited 
//  without the written consent of the copyright owner. TechnoTrend 
//  reserves the right to make changes without notice at any time.  
//
//
//  TT  -  TechnoTrend  -  TT  -  TechnoTrend  -  TT  -  TechnoTrend  -  TT  
//
///////////////////////////////////////////////////////////////////////////
//
//  Filename:     LnbDlg.h
//
//  Project(s):   TestAppDvb
//
//  Author:       GRi
//
//  Purpose:      LNB/Diseqc Settings Dialog
//   
//  Environment:  Win32
//
//  Dev. Tool(s): MSVC 6.0
//
//  Note(s):      
// 
///////////////////////////////////////////////////////////////////////////
// 
//  File History
//
//   $Workfile: LnbDlg.h $
//   $Revision: 1 $  
//    $Modtime: 29.05.01 9:18 $
//
//   $Log: /DVB-PC/APP/TestAppUsbLcd/LnbDlg.h $
//     >>   
//     >>   1     10.07.01 14:48 Guido
//     >>   
//     >>   1     6.06.01 10:55 Guido
//     >>   
//     >>   2     16.05.01 15:11 Guido
//
///////////////////////////////////////////////////////////////////////////

#if !defined(AFX_LNBDLG_H__66849562_8178_11D3_A2D9_00D05CFFFF04__INCLUDED_)
#define AFX_LNBDLG_H__66849562_8178_11D3_A2D9_00D05CFFFF04__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// LnbDlg.h : Header-Datei
//

/////////////////////////////////////////////////////////////////////////////
// Dialogfeld CLnbDlg 

class CLnbDlg : public CDialog
{
// Konstruktion
public:
	CLnbDlg(CWnd* pParent = NULL);   // Standardkonstruktor
	void SetValues(int iDiseqc, int iSPos, int iMOpt, int iMPos, DWORD dwLOF1, DWORD dwLOF2, DWORD dwLOFSW, BOOL bLNBPwr);
	void GetValues(int& iDiseqc, int& iSPos, int& iMOpt, int& iMPos, DWORD& dwLOF1, DWORD& dwLOF2, DWORD& dwLOFSW, BOOL& bLNBPwr);

// Dialogfelddaten
	//{{AFX_DATA(CLnbDlg)
	enum { IDD = IDD_LNB_DLG };
	int		m_iDiseqc;
	int		m_iSimplePosition;
	int		m_iMultiOption;
	int		m_iMultiPosition;
	CString	m_strLOF1;
	CString	m_strLOF2;
	CString	m_strLOFSW;
	BOOL	m_boolLNBPower;
	//}}AFX_DATA


// �berschreibungen
	// Vom Klassen-Assistenten generierte virtuelle Funktions�berschreibungen
	//{{AFX_VIRTUAL(CLnbDlg)
	public:
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV-Unterst�tzung
	//}}AFX_VIRTUAL

// Implementierung
protected:

	// Generierte Nachrichtenzuordnungsfunktionen
	//{{AFX_MSG(CLnbDlg)
	virtual BOOL OnInitDialog();
	virtual void OnOK();
	virtual void OnCancel();
	afx_msg void OnDiseqcNone();
	afx_msg void OnDiseqcSimple();
	afx_msg void OnDiseqcMulti();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

private:

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ f�gt unmittelbar vor der vorhergehenden Zeile zus�tzliche Deklarationen ein.

#endif // AFX_LNBDLG_H__66849562_8178_11D3_A2D9_00D05CFFFF04__INCLUDED_
