#ifndef _CI_DATA_IF_H
#define	_CI_DATA_IF_H

#ifndef __cplusplus
short	SYS_OutputCiMessage(BYTE nSlot,char* pMessage,unsigned short nLength);
#endif


typedef struct{
	BYTE	nStatus;
	char	*pMenuTitleString;
	WORD	*pCaSystemIDs;
	WORD	wNoOfCaSystemIDs;
}typ_SlotInfo;

typedef enum
{
	CI_DEBUG_STRING,
	CI_MESSAGE,
	CI_OUTPUT_MSG,
	CI_PSI
}typ_CiMsgHandlerTag;

typedef struct{
	DWORD	UTC_Time;
	DWORD	MJD;
}typ_CiTimeDate;


//SendCIMessage Tags
#define	CI_MSG_NONE							0
#define	CI_MSG_CI_INFO					1
#define	CI_MSG_MENU							2
#define	CI_MSG_LIST							3
#define	CI_MSG_TEXT							4
#define	CI_MSG_REQUEST_INPUT		5
#define	CI_MSG_INPUT_COMPLETE		6
#define	CI_MSG_LIST_MORE				7
#define	CI_MSG_MENU_MORE				8
#define	CI_MSG_CLOSE_MMI_IMM		9
#define	CI_MSG_SECTION_REQUEST	0xA
#define	CI_MSG_CLOSE_FILTER			0xB
#define	CI_PSI_COMPLETE					0xC
#define	CI_MODULE_READY					0xD
#define	CI_SWITCH_PRG_REPLY			0xE
#define	CI_MSG_TEXT_MORE				0xF

#define	CI_HC_TUNE							0x20
#define	CI_HC_REPLACE						0x21
#define	CI_HC_CLEAR_REPLACE			0x22
#define	CI_HC_ASK_RELEASE				0x23

#define	CI_LSC_CMD							0x30
#define	CI_LSC_DESCRIPTOR				0x31
#define	CI_LSC_SEND_LAST				0x32
#define	CI_LSC_SEND_MORE				0x33

#define	CI_AMMI_REQ_START				0x40
#define	CI_AMMI_FILE_ACK				0x41
#define	CI_AMMI_APP_ABORT				0x42
#define	CI_AMMI_ABORT_ACK				0x43

#define	CI_MSG_CA_PMT						0xE0
#define	CI_MSG_ERROR						0xF0


//command interface subcommands
#define	CI_CMD_ERROR							0x0
#define	CI_CMD_ACK								0x1
#define	CI_CMD_SYSTEM_READY				0x2
#define	CI_CMD_MENU_ANSWER				0x3
#define	CI_CMD_ON_TUNED						0x4
#define	CI_CMD_ON_SWITCH_PROGRAM	0x5
#define	CI_CMD_SECTION_ARRIVED		0x6
#define	CI_CMD_SECTION_TIMEOUT		0x7
#define	CI_CMD_TIME								0x8
#define	CI_CMD_ENTER_MENU					0x9
#define	CI_CMD_FAST_PSI						0xA
#define	CI_CMD_GET_SLOT_INFO			0xB
#define	CI_CMD_CLOSE_MMI					0xC
#define	CI_CMD_ANSWER							0xD
#define	CI_CMD_SET_PMT_FILTER			0xE

#define	CI_CMD_LSC_REPLY					0x10
#define	CI_CMD_LSC_BUILD_BUFF			0x11
#define	CI_CMD_LSC_TRX_BUFF				0x12

#define	CI_CMD_OPEN								0x13
#define	CI_CMD_CLOSE							0x14
#define	CI_CMD_GET_VERSION				0x15

#define	CI_CMD_AMMI_START_ACK			0x16
#define	CI_CMD_AMMI_FILE_REQ			0x17
#define	CI_CMD_AMMI_ABORT_REQ			0x18
#define	CI_CMD_AMMI_ABORT_ACK			0x19

#define	CI_CMD_HALT_ARM						0xE0

//error codes
#define	ERR_NONE									0
#define	ERR_WRONG_FLT_INDEX				1
#define	ERR_SET_FLT								2
#define	ERR_CLOSE_FLT							3
#define	ERR_INVALID_DATA					4
#define	ERR_NO_CA_RESOURCE				5

//slot status
#define	CI_SLOT_EMPTY							0
#define	CI_SLOT_MODULE_INSERTED		1
#define	CI_SLOT_MODULE_OK					2
#define CI_SLOT_CA_OK							3
#define	CI_SLOT_DBG_MSG						4
#define	CI_SLOT_UNKNOWN_STATE			0xFF

//key code masks (see DVB document A017 page 44)
#define	CI_KEYMASK_MENU				0x1
#define	CI_KEYMASK_LIST				0x1
#define	CI_KEYMASK_ALL				0x3FFFF

//control codes contained in strings
#define	CI_CTRL_LF				0x8A


//commands for the low speed communication
#define	CI_LSC_CONNECT_ON_CHANNEL				0x1
#define	CI_LSC_DISCONNECT_ON_CHANNEL		0x2
#define	CI_LSC_SET_PARAMS								0x3
#define	CI_LSC_ENQUIRE_STATUS						0x4
#define	CI_LSC_GET_NEXT_BUFFER					0x5

//commands reply ID
#define	CI_LSC_CONNECT_ACK							0x1
#define	CI_LSC_DISCONNECT_ACK						0x2
#define	CI_LSC_SET_PARAMS_ACK						0x3
#define	CI_LSC_STATUS_REPLY							0x4
#define	CI_LSC_GET_NEXT_BUFFER_ACK			0x5
#define	CI_LSC_SEND_ACK									0x6

//commands reply return values
#define REPLY_NO_ERROR									0x0
#define	REPLY_ERROR											0xFF
#define	STATUS_REPLY_DISCONNECTED				0x0
#define	STATUS_REPLY_CONNECTED					0x1


#define	SI_TELEPHONE_DESCRIPTOR					0x1
#define	CABLE_RETURN_CAHNNEL_DESCRIPTOR	0x2
#define	INTERNET_DESCRIPTOR							0x3

#define	LSC_V42BIS				0x0001
#define	LSC_V42						0x0002
#define	LSC_V21						0x0004
#define LSC_V22						0x0008
#define	LSC_V22BIS				0x0010
#define LSC_V23						0x0020
#define LSC_V32						0x0040
#define LSC_V32BIS				0x0080
#define LSC_V34						0x0100
#define LSC_V27TER				0x0200
#define LSC_V29						0x0400

// application MMI

#define	AMMI_STARTACK_OK				1
#define	AMMI_STARTACK_WRONG_API	2
#define	AMMI_STARTACK_BUSY			3



/* Special commands for DRV_Ioctl */
#define DRV_ADDR		1						  /* Set I/O Base Address   */
#define DRV_READMEM		2						  /* Read memory			*/
#define DRV_WRITEMEM	3						  /* Write memory			*/
#define DRV_READIO		4						  /* Read a I/O Register	*/
#define DRV_WRITEIO		5						  /* Write a I/O Register	*/	
#define DRV_TSIGNAL		6						  /* Check a Signal			*/
#define DRV_SSIGNAL		7						  /* Set / Clear a Signal	*/

/* Signal number for DRV_TSIGNAL command */
#define DRV_CARD_DETECT	1
#define DRV_READY_BUSY	2

/* Signal number for DRV_SSIGNAL command */
#define DRV_EMSTREAM	0
#define DRV_ENSLOT		1
#define DRV_RSTSLOT		2
#define DRV_IOMEM		6
#define DRV_SLOTSEL		7

#define	CI_BASE	0x30000000
//#define	CI_BASE	0x32000000		//CS3
#define	CIMaxSA	0x80

/*--------------------------------------------------------------------------*/
/* Structures Definitions                                                   */
/*--------------------------------------------------------------------------*/

typedef struct {
	unsigned short addr;			/* I/O Base Address						*/
	} DRV_stAddr;  					/* structure for DRV_ADDR				*/

typedef struct {
	unsigned short addr;			/* address to read/write				*/
	unsigned short len;				/* number of bytes to read/write		*/
	unsigned char *pbytes;			/* pointer to bytes to read/write		*/
	unsigned short rlen;			/* number of bytes actually read/write	*/
	} DRV_stMem;  	 /* structure for DRV_READMEM and DRV_WRITEMEM commands */

typedef struct {
	unsigned short registr;			/* register addresse to read/write		*/
	unsigned char *pvalue;			/* pointer to the value to read/write	*/
	} DRV_stIO;  	   /* structure for DRV_READIO and DRV_WRITEIO commands */

typedef struct {
	unsigned char sig;				/* signal number						*/
	unsigned char value;			/* value(1 : signal present ; 0 missing)*/
	} DRV_stSignal;					/* structure for DRV_TSIGNAL command	*/


typedef struct {
	unsigned char pin;				/* pin code								*/
	unsigned char cs;				/* value(1 : Set ; 0 clear)				*/
	} DRV_ssSignal;					/* structure for DRV_SSIGNAL command	*/

#ifdef I2C
/* Specific I2C implementation with 2 slots 0 and 1 */
typedef struct {
	char Slot;						/* Slot number (0 or 1)					*/
	char Cd;						/* 1 if Card Detect assert for this slot*/
	} DRVst;	
#endif



#endif