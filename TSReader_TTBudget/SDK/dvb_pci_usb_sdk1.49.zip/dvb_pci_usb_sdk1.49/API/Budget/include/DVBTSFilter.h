// DVBTSFilter.h: Schnittstelle f�r die Klasse CDVBTSFilter.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_DVBTSFILTER_H__8DFBF32B_E897_4995_B11B_BF25DFC52D30__INCLUDED_)
#define AFX_DVBTSFILTER_H__8DFBF32B_E897_4995_B11B_BF25DFC52D30__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "DVBCommon.h"

// BlockSize beim Filtersetzen darf nicht gr��er sein!
#define MAX_BLOCK_SIZE 8192
// timeout in ms
#define STOP_THREAD_TIMEOUT 200

class AFX_EXT_CLASS CDVBTSFilter : public CDVBCommon
{
public:

	typedef enum
	{	NO_FILTER_TYPE,
		STREAMING_FILTER,
		PIPING_FILTER,
		PES_FILTER,
		ES_FILTER,
		SECTION_FILTER,
		MPE_SECTION_FILTER,
		PID_FILTER,
		MULTI_PID_FILTER,
		TS_FILTER,
		MULTI_MPE_FILTER
	} FILTERTYPE;

	CDVBTSFilter(); // 256 KByte interner Buffer
	CDVBTSFilter(DWORD BufferSize); // variabler interner Buffer
	virtual ~CDVBTSFilter();

	DVB_ERROR SetFilter(FILTERTYPE FilterType, WORD wPID, BYTE* pbFilterData = NULL, BYTE* pbFilterMask = NULL, BYTE bLength = 0);
	DVB_ERROR ResetFilter(void);
	DVB_ERROR SetMultiPIDFilter(WORD* pwPIDs, WORD wLength); // TS-Filter auf mehrere PIDs
	BYTE  GetFilterID(void); // f�r DVBWinSock und DVBFastSocket (SOpen)
	DWORD GetByteCount(void);
	DWORD GetScrambleFlags(void);
	void GetPIDCount(DWORD& dwTSPackets, DWORD& dwContErr); // per Filter PID

	DVB_ERROR SetMultiMultiFilter(WORD* pwPIDs, WORD wLength); // TS-Filter auf mehrere PIDs and MACs
	DVB_ERROR ResetMultiMultiFilter(void);

	static DVB_ERROR GetFiltersByteCount(DWORD* aCounts, BYTE NrOfCounts);

	// Dummy-Funktionen f�r Kompatibilit�t
	BOOL SOpen(BYTE FilterID, int* err = NULL) {if(err) *err=0; return TRUE;};
	void SClose() {return;};

	// f�r Data-Routing durch Windows-Sockets
	DVB_ERROR SetWinSockFilter(FILTERTYPE FilterType, WORD wPID, BYTE* pbFilterData = NULL, BYTE* pbFilterMask = NULL, BYTE bLength = 0);

protected:
	// in den abgeleiteten Klassen �berschreiben !
	virtual void OnDataArrival(BYTE* Buff, int len);

private:
	//BOOL SIOpen();
	//void SIClose();
	DVB_ERROR AddFilter(BYTE& bFilterID, FILTERTYPE FilterType, WORD wPID, BYTE* pbFilterData, BYTE* pbFilterMask, BYTE bLength);
	DVB_ERROR AddMultiPIDFilter(BYTE& bFilterID, WORD* pwPIDs, WORD wLength);
	DVB_ERROR AddMultiMultiPIDMACFilter(WORD& MasterID, WORD* pPIDs, WORD Length);
	DVB_ERROR DelMultiMultiPIDMACFilter(WORD wFilterID);
	DVB_ERROR DelFilter(BYTE bFilterID);
	BOOL GetFilterStatus(BYTE bFilterID, DWORD& ByteCnt, DWORD& ScrFlags);
	BOOL Run();

	CEvent m_Event;
	BOOL m_bSendToWinSock;

	BYTE m_bFilterID;
	WORD m_wMasterID;

	typedef const struct sockaddr* LPCSOCKADDR;
	
	BOOL SocketOpen(BYTE FilterID);
	BOOL SocketClose();
	int ReceiveDatagram(char* Buf, const int BufLen, LPSOCKADDR sourceadr, const int timeout_us);

	DVB_ERROR GetIPandPort(CString& strDestinationIP, WORD& wBasePort);
	void DoReceive();

	BOOL StartThread(int iPriority = THREAD_PRIORITY_NORMAL);
	BOOL StopThread(DWORD dwTimeout = STOP_THREAD_TIMEOUT); // in Millisekunden
	BOOL IsRunning();

	CCriticalSection m_CriticalSection;
	volatile long m_lRunThread;
	CWinThread* m_pThread;

	CString m_strDestinationIP;
	WORD m_wBasePort;
	BYTE m_Buffer[MAX_BLOCK_SIZE];

	SOCKET m_hSocket;
	SOCKADDR_IN m_localadr; // enth�lt die lokale, eigene Adresse
	SOCKADDR_IN m_sourceadr;// enth�lt die Absenderadresse nach Empfang

#ifdef _TTDVBLCD_CONT_TEST
	FILE* m_pFile;
	char m_Text[1024];
#endif
	static UINT WorkerThread(LPVOID pParam);
};

#endif // !defined(AFX_DVBTSFILTER_H__8DFBF32B_E897_4995_B11B_BF25DFC52D30__INCLUDED_)
