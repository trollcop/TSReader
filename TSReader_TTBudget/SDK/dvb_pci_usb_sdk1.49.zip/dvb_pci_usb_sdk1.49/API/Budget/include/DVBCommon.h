// DVBCommon.h: interface for the CDVBCommon class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_COMMON_H__0E929338_258F_11D4_B88E_00105A22770E__INCLUDED_)
#define AFX_COMMON_H__0E929338_258F_11D4_B88E_00105A22770E__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

//--- Common return value type
typedef enum
{
	DVB_ERR_NONE,		// kein Fehler
	DVB_ERR_DRIVER,		// Treiberzugriffsfehler
	DVB_ERR_HARDWARE,	// Hardware-Fehler
	DVB_ERR_PARAMETER,	// ung�ltiger Parameter
	DVB_ERR_TIMEOUT,	// Timeout
	DVB_ERR_STATE,		// Zustandsfehler
	DVB_ERR_RESOURCES,	// Mangel an Ressourcen
	DVB_ERR_GENERAL		// allgemeiner Fehler
} DVB_ERROR;

class AFX_EXT_CLASS CDVBCommon
{
public:
    //--- Device-Driver open and close --------------------
	static WORD   GetNumberOfDevices(void);
	static BOOL   GetDeviceInfo(WORD wDevIdx, CString& Name, CString& MAC, CString& IP);

	static BOOL   OpenDevice(WORD wDevIdx, LPCTSTR AppName = NULL, BOOL Dummy = FALSE);
	static void   CloseDevice(void);
	static BOOL   IsOpen(void);

	static WORD   GetActDeviceIdx(void);
	static HANDLE GetActDeviceHandle(void);

	// --- optional functions for handling several applications/devices
	static BOOL	   GetCurrentDevApp (WORD wDevIdx, LPCTSTR& AppPath, LPCTSTR& AppName);
	static BOOL	   CloseCurrentApp(WORD wDevIdx, DWORD dwTimeout = 5000); // 5 Seconds
	static LPCTSTR GetAppCloseMessage(void);

protected:
	static HANDLE	m_hDevice;
	static WORD		m_wDevIdx;
	static CString GetExePath(void);

private:
	static BOOL GetDeviceInfoEx(WORD wDevIdx, CString& Name, CString& DevName, CString& MAC, CString& IP, CString& SM, WORD& wBasePort, BOOL& bDHCPService);

	static BOOL GetNetInfo(const CString strNet, CString& strMAC, CString& strIP, CString& strSM, WORD& wBasePort, BOOL& bDHCPService);
	static BOOL GetNetInfo98(const CString strNet, CString& strMAC, CString& strIP, CString& strSM, WORD& wBasePort, BOOL& bDHCPService);
	static BOOL GetNetInfo2000(const CString strNet, CString& strMAC, CString& strIP, CString& strSM, WORD& wBasePort, BOOL& bDHCPService);

	static WORD GetNumberOfDevicesNT(void);
	static BOOL GetDeviceInfoNT(WORD wDevIdx, CString& Name, CString& MAC, CString& IP, CString& SM, WORD& wBasePort, BOOL& bDHCPService);
	static CString GetDeviceNameNT(WORD wDevIdx);

	static BOOL GetIP_SM_From_MAC(const CString strMAC, CString& strIP, CString& strSM, BOOL& bRegDHCP);

	static int GetWinSysVer(void);
	static BOOL OpenDriver(const char* csDriver);
	static DVB_ERROR SetIPAddress(CString strIP, CString strSM);
};

#endif // !defined(AFX_COMMON_H__0E929338_258F_11D4_B88E_00105A22770E__INCLUDED_)
