// DVBBoardControl.h: interface for the CDVBBoardControl class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_BOARDCONTROL_H__3191AE5F_2648_11D4_B88F_00105A22770E__INCLUDED_)
#define AFX_BOARDCONTROL_H__3191AE5F_2648_11D4_B88F_00105A22770E__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "DVBCommon.h"


#define DVB_PACKET_DIRECTED           0x0001
#define DVB_PACKET_MULTICAST          0x0002
#define DVB_PACKET_ALL_MULTICAST      0x0004
#define DVB_PACKET_BROADCAST          0x0008
#define DVB_PACKET_SOURCE_ROUTING     0x0010
#define DVB_PACKET_PROMISCUOUS        0x0020
#define DVB_PACKET_SMT                0x0040
#define DVB_PACKET_MAC_FRAME          0x8000
#define DVB_PACKET_FUNCTIONAL         0x4000
#define DVB_PACKET_ALL_FUNCTIONAL     0x2000
#define DVB_PACKET_GROUP              0x1000

#define MULTICASTLISTMAX 64
#define LENGTH_OF_ETH_ADDRESS 6

#define VER_VALID_DLL	0x1630
#define VER_VALID_DRV	0x2202
#define VER_VALID_NET	0x1802 //not use

class AFX_EXT_CLASS CDVBBoardControl : public CDVBCommon
{
public:

	typedef struct _MULTICAST_LIST
	{
		UINT MulticastListMax;
		UINT MulticastListInUse;
		UINT PacketFilter; // Flags (DVB_PACKET_...)
		BYTE AddressList[MULTICASTLISTMAX][LENGTH_OF_ETH_ADDRESS];
	} MULTICAST_LIST, *PMULTICAST_LIST;
	
	CDVBBoardControl();
	virtual ~CDVBBoardControl();

	DVB_ERROR ResetInit(void);
	DVB_ERROR EnableDataDMA(BOOL bEnable);

	DVB_ERROR GetMulticastList(MULTICAST_LIST& MCList);
	DVB_ERROR GetMACAddress(DWORD& dwEEPromOID, DWORD& dwEEPromLow3Bytes);
	DVB_ERROR Get_IP_SM_BP(DWORD& dwIP, DWORD& dwSM, WORD& wBasePort);

	DVB_ERROR GetSubDeviceIDs(WORD& wVendorID, WORD& wDeviceID);
	DVB_ERROR GetVersions(DWORD& dwDllVer, DWORD& dwDrvVer);
	DVB_ERROR CheckRegistration(const char* line);

	BOOL GetDriverStatus(DWORD* pdwArr, BYTE NrOfDWs); // up to 17 DWORDs

	void ResetAllSlaveFilters(void);
	
	BOOL TSRecordOnOff(BOOL on);
	int TSRecordRead(BYTE* Buf, int len); // len >= 96256 Byte !
};

#endif // !defined(AFX_BOARDCONTROL_H__3191AE5F_2648_11D4_B88F_00105A22770E__INCLUDED_)
