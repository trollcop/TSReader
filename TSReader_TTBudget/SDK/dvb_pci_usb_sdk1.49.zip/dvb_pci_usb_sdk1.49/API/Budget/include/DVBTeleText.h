// CDVBTeletext.h: interface for the CDVBTeleText class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_TELETEXT_H__0E92933A_258F_11D4_B88E_00105A22770E__INCLUDED_)
#define AFX_TELETEXT_H__0E92933A_258F_11D4_B88E_00105A22770E__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

//#include "DVBWinSock.h"
//#include "DVBFilter.h"
#include "DVBTSFilter.h"

//class __declspec(dllexport) CDVBTeletext : private CDVBWinSock, private CDVBFilter
class AFX_EXT_CLASS CDVBTeletext : private CDVBTSFilter
{
public:
	
	typedef enum
	{
		DISABLE_PAGE_CAPTURE = 0,
		CAPTURE_PAGE_PARITY_CORRECTED = 1,
		CAPTURE_PAGE_HAMMING_8_4_CORRECTED = 2,
		CAPTURE_PAGE_8BIT_DATA = 3
	} TTX_REQUEST;

	CDVBTeletext();
	virtual ~CDVBTeletext();

	DVB_ERROR TTXOn(WORD wPID);
	DVB_ERROR TTXOff();
	BOOL TTXModifySearchTable(WORD wMag, WORD wTens, WORD wUnits, TTX_REQUEST Request);
	BOOL TTXGetP29_P830(BOOL bPage29);

//protected:
public:
	// CDVBTeletext Overridable callback
	virtual void OnTTXPage(BYTE* TTXPage, int len);
	
private:
	void OnDataArrival(BYTE* Buff, int len);
	void* pTTX;

};

#endif // !defined(AFX_TELETEXT_H__0E92933A_258F_11D4_B88E_00105A22770E__INCLUDED_)
