// DVBComnIF.h: Schnittstelle f�r die Klasse CDVBComnIF.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_DVBCOMNIF_H__E1F3D5A3_A9E5_4F5A_AF2C_366056659A91__INCLUDED_)
#define AFX_DVBCOMNIF_H__E1F3D5A3_A9E5_4F5A_AF2C_366056659A91__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "DVBCommon.h"
#include "CiDataIF.h"

#define STOP_THREAD_TIMEOUT 200


class AFX_EXT_CLASS CDVBComnIF
{
public:
//	friend class CDriver;
	
	typedef enum _typ_ConnectionType
	{
		LscPhone		=1,
		LscCable		=2,
		LscInternet		=3,
		LscSerial
	} typ_ConnectionType;

	typedef struct _typ_ConnectionDesc
	{
		typ_ConnectionType	ConnectionType;
		CString				DialIn; //phone number / channel ID
		CString				ClientIP;
		CString				ServerIP;
		CString				TcpPort;
		CString				ConnectAutID;
		CString				LogonUsername;
		CString				LogonPassword;
		BYTE				RetryCount;
		BYTE				Timeout10Ms;
	} typ_ConnectionDesc;

	typedef struct _typ_SlotInfo
	{
		BYTE	nStatus;
		char*	pMenuTitleString;
		WORD*	pCaSystemIDs;
		WORD	wNoOfCaSystemIDs;
	} typ_SlotInfo;

	CDVBComnIF();
	virtual ~CDVBComnIF();

	DVB_ERROR Open(); // DVB_ERROR Init();
	DVB_ERROR Close();
	DVB_ERROR GetCIVersion(CString& strLabel, CString& strDate);
	
	DVB_ERROR ReadPSIFast(WORD PNR); // SID
	//DVB_ERROR SetProgram(WORD PNR); // SID
	//DVB_ERROR SendTime(void); // empty!
	DVB_ERROR EnterModuleMenu(BYTE nSlot);
	DVB_ERROR GetSlotStatus(BYTE nSlot);
	DVB_ERROR Answer(BYTE nSlot, char* pKeyBuffer, BYTE nLength);
	DVB_ERROR MenuAnswer(BYTE nSlot, BYTE Selection);
	DVB_ERROR CloseMMI(BYTE nSlot);
	//DVB_ERROR AskRelease(void);
	DVB_ERROR CommsReply(BYTE nSlot, BYTE CommsReplyId, BYTE ReturnValue);
	//DVB_ERROR DataReceived(BYTE nSlot, BYTE PhaseID, BYTE* pData, WORD nLength);
	int	ConvertCharBuf(CString &string, int len);

protected:
	virtual	void OnSlotStatus(BYTE nSlot, BYTE nStatus, typ_SlotInfo* csInfo);
	virtual void OnCAStatus(BYTE nSlot, BYTE nReplyTag, WORD wStatus);
	virtual void OnDisplayString(BYTE nSlot, char* pString, WORD wLength);
	virtual void OnDisplayMenu(BYTE nSlot, WORD wItems, char* pStringArray, WORD wLength);
	virtual void OnDisplayList(BYTE nSlot, WORD wItems, char* pStringArray, WORD wLength);
	virtual void OnSwitchOsdOff(BYTE nSlot);
	virtual void OnInputRequest(BYTE nSlot, BOOL bBlindAnswer, BYTE nExpectedLength, DWORD dwKeyMask);

	virtual	void OnTune(BYTE nSlot, WORD NID, WORD OrigNID, WORD TSID, WORD SID);
	virtual void OnReplace(BYTE nSlot, BYTE ReplacementRef, WORD ReplacedPID, WORD ReplacementPID);
	virtual void OnClearReplace(BYTE nSlot, BYTE ReplacementRef);

	virtual void OnLscSetDescriptor(BYTE nSlot, typ_ConnectionDesc* pDescriptor);
	virtual void OnLscConnect(BYTE nSlot);
	virtual void OnLscDisconnect(BYTE nSlot);
	virtual void OnLscSetParams(BYTE nSlot, BYTE BufferSize, BYTE Timeout10Ms);
	virtual void OnLscEnquireStatus(BYTE nSlot);
	virtual void OnLscGetNextBuffer(BYTE nSlot, BYTE PhaseID);
	virtual void OnLscTransmitBuffer(BYTE nSlot, BYTE PhaseID, BYTE* pData, WORD nLength);

private:
	void DecodeConnectionDesc(char* pSource, typ_ConnectionDesc* pConnectionDesc);
	short DecodeLengthField(BYTE* papdu, WORD* nLength);
	DVB_ERROR SwitchVideoPort(BOOL bCI_Mode);

//	SYSTEMTIME sysTime;
//	WORD	m_wActualKeyMask;
//	BYTE	m_nExpectedInputLength;
//	UINT	m_CITimer;
	
	void* m_pCiDriver; //CiDriver* m_pCiDriver;

private:
	// CI-Lib Callback Functions
	int	DRV_Open(int Slot);						
	int	DRV_Close(int Slot);
	int	DRV_Ioctl(int Slot, int command, void *parg);
	int	DRV_Write(int Slot,unsigned short Size_in,unsigned char *pData);
	int	DRV_Read(int Slot,int Size_out,unsigned char * pData);

	short CI_MessageHandler(BYTE nSlot, typ_CiMsgHandlerTag Tag, char* pMessage, unsigned short nLength);

	//DWORD m_dwAccessType;


private:
//public:
	typedef enum
	{	CI_ACCESS_TIME_600ns,
		CI_ACCESS_TIME_300ns,
		CI_ACCESS_TIME_250ns,
		CI_ACCESS_TIME_200ns,
		CI_ACCESS_TIME_150ns,
		CI_ACCESS_TIME_100ns,
		CI_ACCESS_TIME_FAST
	} CI_ACCESS_TIME;

	typedef enum
	{	CI_ATTRIBUTE_ACCESS,
		CI_IO_ACCESS,
		CI_MEMORY_ACCESS,
	} CI_ACCESS_TYPE;

	typedef enum
	{	CI_MODULE_1,
		CI_MODULE_2,
		CI_MODULE_3,
		CI_MODULE_4,
	} CI_MODULE_INDEX;

	// Low-Level Modul Access Functions
	int ciInit(void);
	
	int ciSetAccessTime(CI_ACCESS_TIME atime);
	int ciSetAccessType(CI_ACCESS_TYPE type);
	int ciSelectModule(CI_MODULE_INDEX index);

	int ciClearInterrupt(BYTE mask);
	int ciDisableInterrupt(BYTE mask);
	int ciEnableInterrupt(BYTE mask);
	int ciReadVersion(BYTE& version);
	int ciModuleEnableTS(bool enable);
	int ciReadState(BYTE& state);
	int ciWriteCtrl(BYTE ctrl);
	int ciModuleReset(bool reset);

	int ciReadSeq(WORD Addr, BYTE *pData, WORD Length);
	int ciWriteSeq(WORD Addr, BYTE* pData, WORD Length);
	int ciReadBlock(WORD Addr, BYTE* pData, WORD Length);
	int ciWriteBlock(WORD Addr, BYTE* pData, WORD Length);
	int ciRead(WORD Addr, BYTE& Data);
	int ciWrite(WORD Addr, BYTE Data);

private:
	CI_ACCESS_TIME m_ciAccessTime;
	BYTE m_ciCtrlShadow;
	WORD m_ciAddrOffset;

private:
	BOOL SetupCiEvent(BOOL bInstall);
	
	BOOL StartThread(int iPriority = THREAD_PRIORITY_NORMAL);
	BOOL StopThread(DWORD dwTimeout = STOP_THREAD_TIMEOUT); // in Millisekunden
	BOOL IsRunning();
	BOOL Run();

	CEvent m_Event;
	CCriticalSection m_CriticalSection;
	volatile long m_lRunThread;
	CWinThread* m_pThread;

	static UINT WorkerThread(LPVOID pParam);
};

#endif // !defined(AFX_DVBCOMNIF_H__E1F3D5A3_A9E5_4F5A_AF2C_366056659A91__INCLUDED_)
