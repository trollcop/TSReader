// DVBFilterToFile.h: interface for the CDVBFilterToFile class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_FILTERTOFILE_H__18B567D2_27F9_11D4_B892_00105A22770E__INCLUDED_)
#define AFX_FILTERTOFILE_H__18B567D2_27F9_11D4_B892_00105A22770E__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
  
#include "DVBTSFilter.h"

class __declspec(dllexport) CDVBFilterToFile : public CDVBTSFilter
{
public:
	CDVBFilterToFile();
	virtual ~CDVBFilterToFile();

	void SetFileParams(const CString& Name, UINT nOpenFlags = CFile::modeCreate | CFile::modeWrite);
	DVB_ERROR StartFilter(CDVBTSFilter::FILTERTYPE FilterType, WORD wPID, BYTE* pbFilterData = NULL, BYTE* pbFilterMask = NULL, BYTE bLength = 0);
	DVB_ERROR StartMultiPIDFilter(WORD* pwPIDs, WORD wLength);
	DVB_ERROR StopFilter(void);
	DWORD GetFileLen(void);

protected:
	virtual void OnDataArrival(BYTE* Buff, int len);

private:	
	CString m_FileName;
	CFile m_File;
	UINT m_OpenFlags;
};

#endif // !defined(AFX_FILTERTOFILE_H__18B567D2_27F9_11D4_B892_00105A22770E__INCLUDED_)
