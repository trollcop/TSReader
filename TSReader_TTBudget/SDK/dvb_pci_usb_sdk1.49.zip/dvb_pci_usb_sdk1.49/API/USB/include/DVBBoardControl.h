// DVBBoardControl.h: interface for the CDVBBoardControl class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_BOARDCONTROL_H__3191AE5F_2648_11D4_B88F_00105A22770E__INCLUDED_)
#define AFX_BOARDCONTROL_H__3191AE5F_2648_11D4_B88F_00105A22770E__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "DVBCommon.h"

#define DVB_PACKET_DIRECTED           0x0001
#define DVB_PACKET_MULTICAST          0x0002
#define DVB_PACKET_ALL_MULTICAST      0x0004
#define DVB_PACKET_BROADCAST          0x0008
#define DVB_PACKET_SOURCE_ROUTING     0x0010
#define DVB_PACKET_PROMISCUOUS        0x0020
#define DVB_PACKET_SMT                0x0040
#define DVB_PACKET_MAC_FRAME          0x8000
#define DVB_PACKET_FUNCTIONAL         0x4000
#define DVB_PACKET_ALL_FUNCTIONAL     0x2000
#define DVB_PACKET_GROUP              0x1000

#define MULTICASTLISTMAX 64
#define LENGTH_OF_ETH_ADDRESS 6

#define VER_VALID_DLL	0x1720
#define VER_VALID_DRV	0x1865
#define VER_VALID_NET	0x1806

class __declspec(dllexport) CDVBBoardControl// : public CDVBCommon
{
public:

	typedef struct _MULTICAST_LIST
	{
		UINT MulticastListMax;
		UINT MulticastListInUse;
		UINT PacketFilter; // Flags (DVB_PACKET_...)
		BYTE AddressList[MULTICASTLISTMAX][LENGTH_OF_ETH_ADDRESS];
	} MULTICAST_LIST, *PMULTICAST_LIST;

	typedef enum
	{                   // netto brutto       %ISO %USB  Size
		BANDWIDTH_NONE, // 0.00  0.00 MBit/s    0    0      0
		BANDWIDTH_FULL, // 7.30  8.60 MBit/s   89   71    912
		BANDWIDTH_6_91, // 6.91  8.15 MBit/s   84   67    864
		BANDWIDTH_6_59, // 6.59  7.77 MBit/s   80   64    824
		BANDWIDTH_5_82, // 5.82  6.88 MBit/s   71   57    728
		BANDWIDTH_5_06, // 5.06  5.98 MBit/s   61   49    632
		BANDWIDTH_4_35, // 4.35  5.16 MBit/s   53   42    544
		BANDWIDTH_3_59, // 3.59  4.26 MBit/s   43   35    448
		BANDWIDTH_2_82, // 2.82  3.37 MBit/s   34   27    352
		BANDWIDTH_2_05, // 2.05  2.47 MBit/s   25   20    256
		BANDWIDTH_1_54, // 1.54  1.88 MBit/s   18   15    192
		BANDWIDTH_1_02, // 1.02  1.28 MBit/s   12   10    128
		BANDWIDTH_0_51  // 0.51  0.68 MBit/s    6    5     64
	} BANDWIDTH;

	CDVBBoardControl();
	virtual ~CDVBBoardControl();

	DVB_ERROR ResetInit(void);
	//DVB_ERROR EnableIsoStream(BANDWIDTH bw); // BANDWIDTH_NONE == 'Off'
	// EnableIsoStream returns the bandwidth which was selected; requested = BANDWIDTH_NONE -> 'Off'
	DVB_ERROR EnableIsoStream(BANDWIDTH& selected, BANDWIDTH requested = BANDWIDTH_FULL, BANDWIDTH minimal = BANDWIDTH_2_82);
	DVB_ERROR GetUsbBandWidth(DWORD& dwTotalBW, DWORD& dwConsumedBW, BANDWIDTH& UsableBW);

	DVB_ERROR GetMulticastList(MULTICAST_LIST& MCList);
	DVB_ERROR GetMACAddress(DWORD& dwEEPromOID, DWORD& dwEEPromLow3Bytes);
	DVB_ERROR Get_IP_SM_BP(DWORD& dwIP, DWORD& dwSM, WORD& wBasePort);

	DVB_ERROR BootDSP(const CString& strBootFilePath);
	DVB_ERROR SetBusyLEDFreq(BYTE freq);
	DVB_ERROR SetVideoIFrame(WORD wPID); // 0 == Off

	BOOL GetDSPStatus(DWORD* pdwArr, BYTE NrOfDWs); // max. 7 DWORDs
	BOOL GetDriverStatus(DWORD* pdwArr, BYTE NrOfDWs);

	DVB_ERROR CheckRegistration(const char* line);
	DVB_ERROR GetUsbDeviceIDs(WORD& wVendorID, WORD& wDeviceID);
	DVB_ERROR GetVersions(DWORD& dwDllVer, DWORD& dwDrvVer, DWORD& dwNwDrvVer);

	void ResetAllSlaveFilters(void);
};

#endif // !defined(AFX_BOARDCONTROL_H__3191AE5F_2648_11D4_B88F_00105A22770E__INCLUDED_)

