// DVBTSFilter.h: Schnittstelle f�r die Klasse CDVBTSFilter.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_DVBTSFILTER_H__61B6C2F8_CA3D_4686_9119_70EC7D695581__INCLUDED_)
#define AFX_DVBTSFILTER_H__61B6C2F8_CA3D_4686_9119_70EC7D695581__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "DVBCommon.h"

// timeout in ms
#define STOP_THREAD_TIMEOUT 200

class __declspec(dllexport) CDVBTSFilter// : public CDVBCommon
{
public:

	typedef enum
	{	NO_FILTER_TYPE,
		STREAMING_FILTER,
		PIPING_FILTER,
		PES_FILTER,
		ES_FILTER,
		SECTION_FILTER,
		MPE_SECTION_FILTER,
		PID_FILTER,
		MULTI_PID_FILTER,
		TS_FILTER,
		MULTI_MPE_FILTER
	} FILTERTYPE;

	CDVBTSFilter(); // 256 KByte interner Buffer
	CDVBTSFilter(DWORD BufferSize); // variabler interner Buffer
	virtual ~CDVBTSFilter();

	DVB_ERROR SetFilter(FILTERTYPE FilterType, WORD wPID, BYTE* pbFilterData = NULL, BYTE* pbFilterMask = NULL, BYTE bLength = 0);
	DVB_ERROR ResetFilter(void);
	DVB_ERROR SetMultiPIDFilter(WORD* pwPIDs, WORD wLength); // TS-Filter auf mehrere PIDs

	DVB_ERROR SetMultiMultiFilter(WORD* pwPIDs, WORD wLength); // TS-Filter auf mehrere PIDs and MACs
	DVB_ERROR ResetMultiMultiFilter(void);

	BYTE  GetFilterID(void); // f�r DVBWinSock und DVBFastSocket (SOpen)
	DWORD GetByteCount(void);
	DWORD GetScrambleFlags(void);

	static DVB_ERROR GetFiltersByteCount(DWORD* aCounts, BYTE NrOfCounts);
	
	// Dummy-Funktionen f�r Kompatibilit�t
	BOOL SOpen(BYTE FilterID, int* err = NULL) {if(err) *err=0; return TRUE;};
	void SClose() {return;};

	// f�r Data-Routing durch Windows-Sockets
	DVB_ERROR SetWinSockFilter(FILTERTYPE FilterType, WORD wPID, BYTE* pbFilterData = NULL, BYTE* pbFilterMask = NULL, BYTE bLength = 0);

protected:
	// in den abgeleiteten Klassen �berschreiben !
	virtual void OnDataArrival(BYTE* Buff, int len);

private:
	DVB_ERROR AddFilter(BYTE& bFilterID, FILTERTYPE FilterType, WORD wPID, BYTE* pbFilterData, BYTE* pbFilterMask, BYTE bLength);
	DVB_ERROR AddMultiPIDFilter(BYTE& bFilterID, WORD* pwPIDs, WORD wLength);
	DVB_ERROR AddMultiMultiPIDMACFilter(WORD& MasterID, WORD* pPIDs, WORD Length);
	DVB_ERROR DelMultiMultiPIDMACFilter(WORD wFilterID);
	DVB_ERROR DelFilter(BYTE bFilterID);
	BOOL GetFilterStatus(BYTE bFilterID, DWORD& ByteCnt, DWORD& ScrFlags);
	BOOL Run();

	void* m_pAccu;
	CEvent m_Event;
	BOOL m_bSendToWinSock;

	BYTE m_bFilterID;
	WORD m_wMasterID;

	BOOL StartThread(int iPriority = THREAD_PRIORITY_NORMAL);
	BOOL StopThread(DWORD dwTimeout = STOP_THREAD_TIMEOUT); // in Millisekunden
	BOOL IsRunning();

	CCriticalSection m_CriticalSection;
	volatile long m_lRunThread;
	CWinThread* m_pThread;

	static UINT WorkerThread(LPVOID pParam);

public:
	// Eintrittsfunktion der Daten
	void TSCallback(int FilterType, BYTE FilterID, BYTE* pStart, DWORD Length, BYTE Flags);
};

#endif // !defined(AFX_DVBTSFILTER_H__61B6C2F8_CA3D_4686_9119_70EC7D695581__INCLUDED_)
