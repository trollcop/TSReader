del /s /f *.aps *.ncb *.opt *.plg *.obj *.sbr *.ilk *.pch *.pdb *.bsc *.cod *.exp
