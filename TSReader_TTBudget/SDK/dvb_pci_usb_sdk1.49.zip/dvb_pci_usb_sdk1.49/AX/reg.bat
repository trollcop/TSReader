regsvr32 ttdvbgui.ax
regsvr32 ttcapfilter.ax