TSReader 2.8 FutureTel source module

The FutureTel 320/325 are (now obsolete) MPEG-2 encoders which can generate a transport stream.

To use with TSReader, unzip all DLLs except TSReader_FutureTel.dll into the TSReader folder. The
source module (TSReader_FutureTel.dll) goes into TSReader\Sources.

When the encoder setup is shown make sure you select Transport Stream formatting.

