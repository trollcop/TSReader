#include <windows.h>
#include <commctrl.h>
#include "initguid.h"
#include "winioctl.h"
#include "setupapi.h"	// VC++ 5 one is out of date
#include <stdio.h>

#include "..\sources.h"

#include <ATDV_API.H>
#include <algorithm>

#include "resource.h"

CATBoard *pBoard;
CAtBoardManager *pMan;

PSOURCESTRUCT ss;

HINSTANCE hInstance;
int nInputSelect = 0;
int fDontAskMode = FALSE;
BOOL fNeedTuneDialog = TRUE;

char gszSourceName[] = {"Alitronika AT200/AT400"};
char gszAlitronikaKeyName[] = {"Software\\COOL.STF\\TSReader\\Alitronika"};

#define RECORD_BUFFERSIZE	(1 * 1024 * 1024)
#define STATUS_MS			50

void LoadAlitronikaSettings()
{
	DWORD dwDisposition;
	DWORD dwDataSize;
	DWORD dwType;
	LONG lKey;
	HKEY hkMainReg;

	lKey = RegCreateKeyEx(HKEY_CURRENT_USER,
		                  gszAlitronikaKeyName,
						  0,
						  gszSourceName,
					      REG_OPTION_NON_VOLATILE,
						  KEY_ALL_ACCESS,
						  NULL,
						  &hkMainReg,
						  &dwDisposition);
	if (lKey == ERROR_SUCCESS)
	{
		if (dwDisposition != REG_CREATED_NEW_KEY)
		{
			dwDataSize = sizeof(nInputSelect);
			RegQueryValueEx(hkMainReg, "InputSelect", NULL, &dwType, (BYTE *)&nInputSelect, &dwDataSize);
			dwDataSize = sizeof(fDontAskMode);
			RegQueryValueEx(hkMainReg, "DontAskMode", NULL, &dwType, (BYTE *)&fDontAskMode, &dwDataSize);
		}
		RegCloseKey(hkMainReg);
	}
}

void SaveAlitronikaSettings()
{
	LONG lKey;
	HKEY hkMainReg;
	DWORD dwDisposition;

	lKey = RegCreateKeyEx(HKEY_CURRENT_USER,
		                  gszAlitronikaKeyName,
						  0,
						  gszSourceName,
					      REG_OPTION_NON_VOLATILE,
						  KEY_ALL_ACCESS,
						  NULL,
						  &hkMainReg,
						  &dwDisposition);
	if (lKey == ERROR_SUCCESS)
	{
		RegSetValueEx(hkMainReg, "InputSelect", 0, REG_DWORD, (BYTE *)&nInputSelect, sizeof(DWORD));
		RegSetValueEx(hkMainReg, "DontAskMode", 0, REG_DWORD, (BYTE *)&fDontAskMode, sizeof(DWORD));
		RegCloseKey(hkMainReg);
	}
}

BOOL CALLBACK InputModeDlgProc(HWND hDlg, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	switch(uMsg)
	{
	case WM_INITDIALOG:
		switch(nInputSelect)
		{
		case 0:
			CheckDlgButton(hDlg, IDC_INPUT_DVB_ASI, BST_CHECKED);
			break;
		case 1:
			CheckDlgButton(hDlg, IDC_INPUT_DVB_SPI, BST_CHECKED);
			break;
		}
		SetFocus(GetDlgItem(hDlg, IDOK));
		break;
	case WM_CLOSE:
		EndDialog(hDlg, FALSE);
		break;
	case WM_COMMAND:
		switch(LOWORD(wParam))
		{
		case IDOK:
			if (IsDlgButtonChecked(hDlg, IDC_INPUT_DVB_ASI))
				nInputSelect = 0;
			else if (IsDlgButtonChecked(hDlg, IDC_INPUT_DVB_SPI))
				nInputSelect = 1;
			fDontAskMode = IsDlgButtonChecked(hDlg, IDC_DONT_ASK_AGAIN);
			EndDialog(hDlg, TRUE);
			break;
		case IDCANCEL:
			EndDialog(hDlg, FALSE);
			break;
		}
		break;
	}

	return FALSE;
}

DWORD WINAPI ReadThead(LPVOID lpv)
{
	DWORD dwBytes;
	BYTE * pBuffer = (BYTE *)LocalAlloc(LPTR, RECORD_BUFFERSIZE);

	SourceHelper_StartSyncThread(ss, FALSE);
	pBoard->StartRecording();
	while (!ss->fTerminateReadThread)
	{
		if (!pBoard->GetRecordPacketDirect(pBuffer, RECORD_BUFFERSIZE, &dwBytes))
			break;
		if (dwBytes)
			SourceHelper_SyncData(pBuffer, dwBytes);
		else
			Sleep(2);
	}
	pBoard->StopRecording();
	SourceHelper_StopSyncThread();

	LocalFree(pBuffer);
	ss->fReadThreadTerminated = TRUE;
	return 0;
}

BOOL TSReader_Start()
{
	DWORD dwThreadID;

	ss->hReadDataThread = CreateThread(NULL, 0, ReadThead, (LPVOID)0, CREATE_SUSPENDED, &dwThreadID);
	SourceHelper_SetWorkerThreadPriorities(FALSE);
	ResumeThread(ss->hReadDataThread);
	return TRUE;
}

BOOL TSReader_Stop()
{
	// Terminate our read thread
	ss->fTerminateReadThread = TRUE;
	while (ss->fReadThreadTerminated == FALSE)
		Sleep(50);

	// Tell the main TSReader input thread that's now terminated
	EnterCriticalSection(&ss->csTSBuffersInUse);
	ss->nTSBuffersInUse = -1000;
	LeaveCriticalSection(&ss->csTSBuffersInUse);

	return TRUE;
}

void PrintDev(char *pDevName)
{
	char szTemp[128];

	wsprintf(szTemp, "TSReader_ATxxx: device name %d\n", pDevName);
	OutputDebugString(szTemp);
}

BOOL TSReader_Init(PSOURCESTRUCT pss)
{
	ss = pss;
	
    CAtDeviceList devlist;
    ATDEVICEINFO iDevice;

    pMan = CAtBoardManager::Instance();
    pMan->GetDeviceList(devlist);

   	std::for_each(devlist.Names.begin(), devlist.Names.end(), PrintDev);

	pBoard = pMan->GetBoard(devlist.Names[0]);
	if (pBoard == NULL)
		return FALSE;

    pBoard->GetDeviceInfo(&iDevice);
    // pBoard is set to the first driver in the vector

	
	// Upload the correct FPGA file
	pBoard->ProgramFPGA(REC_DVB);
        
	pBoard->InitBitrateFilter(STATUS_MS);

	return TRUE;
}

BOOL TSReader_DeInit()
{
	if (pBoard != NULL)
		pMan->ReleaseBoard(pBoard);

	return TRUE;
}

BOOL TSReader_Tune()
{
	CAtRegisters RegAcc(pBoard);

	// Select DVB input	
	RegAcc.m_Registers.m_RecordConfig &= ~(AT_RCONF_DVB|AT_RCONF_SMP); 
	RegAcc.m_Registers.m_RecordConfig |= AT_RCONF_DVB; 
	
	RegAcc.m_Registers.m_DvbSmpte = 0; //SET
	
	RegAcc.m_Registers.m_RecordConfig &= ~(AT_RCONF_SER|AT_RCONF_PAR);
	switch(nInputSelect)
	{
	case 0:
		RegAcc.m_Registers.m_RecordConfig |= AT_RCONF_SER;
		break;
	case 1:
		RegAcc.m_Registers.m_RecordConfig |= AT_RCONF_PAR;
		break;
	}
    pBoard->UpdateRegisters();

	return TRUE;
}

BOOL TSReader_TuneDialog(HWND hWnd)
{
	if (fNeedTuneDialog)
	{
		LoadAlitronikaSettings();
		if (fDontAskMode == FALSE)
		{
			if (DialogBox((HINSTANCE)hInstance, MAKEINTRESOURCE(IDD_INPUT_SELECT), ss->hWndTSReader, InputModeDlgProc) == FALSE)
				return FALSE;
		}
		SaveAlitronikaSettings();
	}

	return TRUE;

}

BOOL TSReader_PIDManagement(BOOL fAdd, int nPID, BOOL fTemporary)
{
	return TRUE;
}

BOOL TSReader_GetDescription(char * szDescription, char * szCommandLineParameters, BOOL * fCanBeStopped, int * nMaxPIDs, DWORD * dwCapabilities)
{
	if (szDescription != NULL)
		lstrcpy(szDescription, gszSourceName);
	if (szCommandLineParameters != NULL)
		lstrcpy(szCommandLineParameters, "input");
	if (dwCapabilities != NULL)
		*dwCapabilities = 0;
	if (fCanBeStopped != NULL)
		*fCanBeStopped = FALSE;
	if (nMaxPIDs != NULL)
		*nMaxPIDs = 8192;

	return TRUE;
}

BOOL TSReader_ParseCommandLine(PSOURCESTRUCT ss, char * szCommandLine, BOOL fQuiet)
{
	fNeedTuneDialog = TRUE;
	if (lstrlen(szCommandLine))
	{
		int nConversionCount;

		nInputSelect = 0;
		nConversionCount = sscanf(szCommandLine,
								  "%d", 
								  &nInputSelect);
		if (nConversionCount < 1 || (nInputSelect < 0 || nInputSelect > 1) )
		{
			if (!fQuiet)
				MessageBox(NULL,
					   "Usage for this source: input\n"
					   "\n"
					   "input = 0 for DVB-ASI or 1 for DVB-SPI",
					   gszSourceName,
					   MB_OK | MB_ICONSTOP);
			return FALSE;
		}
		fNeedTuneDialog = FALSE;
	}
	return TRUE;
}

BOOL TSReader_IsPIDActive(int nPID)
{
	return TRUE;
}

BOOL TSReader_GetSignalString(char * szString)
{
	return TRUE;
}

BOOL TSReader_GetTunerString(char * szString)
{
	return TRUE;
}

BOOL TSReader_SendDiSEqC(BYTE * bCommand, int nLength)
{
	return TRUE;
}

BOOL TSReader_SetChannel(int nChannel)
{
	return TRUE;
}

BOOL APIENTRY DllMain(HANDLE hModule, DWORD ul_reason_for_call, LPVOID lpReserved)
{
    switch( ul_reason_for_call )
	{
    case DLL_PROCESS_ATTACH:
		hInstance = (HINSTANCE)hModule;
		break;
    case DLL_PROCESS_DETACH:
		break;
    }
    return TRUE;
}
