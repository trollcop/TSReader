/* (C) Vlinders, 2003 */

#ifndef _FENRIR_DYN_H_
#define _FENRIR_DYN_H_
#include <windows.h>
#include "FenrirTypes.h"
#include "FenrirIrdeto.h"
#include "FenrirSeca.h"


extern "C" 
{
	typedef EMM_ERRORS_t (FENEXP	*FenrirInitialize_Proc)(const char *path);
	typedef LPFENRIR	 (FENEXP	*FenrirOpen_Proc)();
	typedef EMM_ERRORS_t (FENEXP	*FenrirClose_Proc)(LPFENRIR lpfenrir);
	typedef EMM_ERRORS_t (FENEXP 	*FenrirCheckCA_Proc)(int ca, char *ca_name);
	typedef EMM_ERRORS_t (FENEXP	*FenrirGetProviderName_Proc)(int ca, int id, char *name);
	typedef EMM_ERRORS_t (FENEXP	*FenrirSet_Proc)(LPFENRIR lpfenrir,int pid, int caid, EMM_Notify_Proc _not_func, int _not_id);
	typedef EMM_ERRORS_t (FENEXP	*FenrirProcess_Proc)(LPFENRIR lpFenrir, const u8 *emmdata, int emmlen);

	typedef	EMM_ERRORS_t (FENEXP	*Fenrir_Irdeto_Initialize_Proc)(const char *path,const char *ird_beta_kid, const char *ird_beta_key, const char *ird_beta_prv);
	typedef	int			 (FENEXP	*Fenrir_Irdeto_GetCardsCount_Proc)();
	typedef	int			 (FENEXP	*Fenrir_Irdeto_GetProvidersCount_Proc)();
	typedef const tIrdeto_Provider* (FENEXP *Fenrir_Irdeto_Get_Proc)(int idx); 

// Nagra specifics
	typedef EMM_ERRORS_t (FENEXP	*Fenrir_Nagra_Initialize_Proc)(const char *path, const char *nagrapath, const char *nagrakid,const char *nagrakey);
// Viaccess specifics
	typedef EMM_ERRORS_t (FENEXP	*Fenrir_Viaccess_Initialize_Proc)(const char *path, const char *viaccess_sci, const char *viaccess_key, const char *viaccess_prv);
	typedef	int			 (FENEXP	*Fenrir_Viaccess_GetCardsCount_Proc)();

// Conax specifics
	typedef EMM_ERRORS_t (FENEXP	*Fenrir_Conax_Initialize_Proc)(const char *path, const char *conax_kid, const char *conax_key);
	typedef	int			 (FENEXP	*Fenrir_Conax_GetCardsCount_Proc)();

	// Seca specifics
	typedef EMM_ERRORS_t (FENEXP	*Fenrir_Seca_Initialize_Proc)(const char *path, const char *seca_kid, const char *seca_key, const char *seca_prv);
	typedef	int			 (FENEXP	*Fenrir_Seca_GetCardsCount_Proc)();
	typedef	int			 (FENEXP	*Fenrir_Seca_GetProvidersCount_Proc)();
	typedef const tSeca_Provider* (FENEXP *Fenrir_Seca_Get_Proc)(int idx); 
	typedef tSECA_Informs* (FENEXP	*Fenrir_Seca_Options_Proc)();


}

HMODULE LoadFenrirDyn(const char *fn);
void UnloadFenrirDyn();

extern "C" FenrirInitialize_Proc				FenrirInitialize;
extern "C" FenrirOpen_Proc						FenrirOpen;
extern "C" FenrirClose_Proc						FenrirClose;
extern "C" FenrirSet_Proc						FenrirSet;
extern "C" FenrirCheckCA_Proc					FenrirCheckCA;
extern "C" FenrirGetProviderName_Proc			FenrirGetProviderName;
extern "C" FenrirProcess_Proc					FenrirProcess;
extern "C" Fenrir_Irdeto_Initialize_Proc		Fenrir_Irdeto_Initialize;
extern "C" Fenrir_Irdeto_GetCardsCount_Proc		Fenrir_Irdeto_GetCardsCount;
extern "C" Fenrir_Irdeto_GetProvidersCount_Proc Fenrir_Irdeto_GetProvidersCount;
extern "C" Fenrir_Irdeto_Get_Proc				Fenrir_Irdeto_Get; 
extern "C" Fenrir_Nagra_Initialize_Proc			Fenrir_Nagra_Initialize;
extern "C" Fenrir_Viaccess_Initialize_Proc		Fenrir_Viaccess_Initialize;
extern "C" Fenrir_Viaccess_GetCardsCount_Proc	Fenrir_Viaccess_GetCardsCount;

extern "C" Fenrir_Conax_Initialize_Proc			Fenrir_Conax_Initialize;
extern "C" Fenrir_Conax_GetCardsCount_Proc		Fenrir_Conax_GetCardsCount;

extern "C" Fenrir_Seca_Initialize_Proc			Fenrir_Seca_Initialize;
extern "C" Fenrir_Seca_GetCardsCount_Proc		Fenrir_Seca_GetCardsCount;
extern "C" Fenrir_Seca_GetProvidersCount_Proc	Fenrir_Seca_GetProvidersCount;
extern "C" Fenrir_Seca_Get_Proc					Fenrir_Seca_Get;
extern "C" Fenrir_Seca_Options_Proc				Fenrir_Seca_Options;

extern HMODULE				hFenrirModule;

#ifdef FenrirDyn_IMPL
FenrirInitialize_Proc					FenrirInitialize=NULL;
FenrirOpen_Proc							FenrirOpen=NULL;
FenrirClose_Proc						FenrirClose=NULL;
FenrirSet_Proc							FenrirSet=NULL;
FenrirCheckCA_Proc						FenrirCheckCA=NULL;
FenrirGetProviderName_Proc				FenrirGetProviderName=NULL;
FenrirProcess_Proc						FenrirProcess=NULL;
Fenrir_Irdeto_Initialize_Proc			Fenrir_Irdeto_Initialize=NULL;
Fenrir_Irdeto_GetCardsCount_Proc		Fenrir_Irdeto_GetCardsCount=NULL;
Fenrir_Irdeto_GetProvidersCount_Proc	Fenrir_Irdeto_GetProvidersCount=NULL;
Fenrir_Irdeto_Get_Proc					Fenrir_Irdeto_Get=NULL; 
Fenrir_Nagra_Initialize_Proc			Fenrir_Nagra_Initialize=NULL;
Fenrir_Viaccess_Initialize_Proc			Fenrir_Viaccess_Initialize=NULL;
Fenrir_Viaccess_GetCardsCount_Proc		Fenrir_Viaccess_GetCardsCount=NULL;

Fenrir_Conax_Initialize_Proc			Fenrir_Conax_Initialize=NULL;
Fenrir_Conax_GetCardsCount_Proc			Fenrir_Conax_GetCardsCount=NULL;

Fenrir_Seca_Initialize_Proc				Fenrir_Seca_Initialize=NULL;
Fenrir_Seca_GetCardsCount_Proc			Fenrir_Seca_GetCardsCount=NULL;
Fenrir_Seca_GetProvidersCount_Proc		Fenrir_Seca_GetProvidersCount=NULL;
Fenrir_Seca_Get_Proc					Fenrir_Seca_Get=NULL;
Fenrir_Seca_Options_Proc				Fenrir_Seca_Options=NULL;

HMODULE				hFenrirModule=NULL;

#define GETP(x) x=(x##_Proc)GetProcAddress(hMod,#x);
HMODULE LoadFenrirDyn(const char *fn)
{
	HMODULE hMod=LoadLibraryA(fn);
	if((DWORD)hMod>16)
	{
		hFenrirModule=hMod;
		GETP(FenrirInitialize);
		GETP(FenrirOpen);
		GETP(FenrirClose);
		GETP(FenrirProcess);
		GETP(FenrirSet);
		GETP(FenrirCheckCA);
		GETP(FenrirGetProviderName);
		GETP(Fenrir_Irdeto_Initialize);
		GETP(Fenrir_Irdeto_GetCardsCount);
		GETP(Fenrir_Irdeto_GetProvidersCount);
		GETP(Fenrir_Irdeto_Get);
		GETP(Fenrir_Nagra_Initialize);
		GETP(Fenrir_Viaccess_Initialize);
		GETP(Fenrir_Viaccess_GetCardsCount);
		GETP(Fenrir_Conax_Initialize);
		GETP(Fenrir_Conax_GetCardsCount);
		GETP(Fenrir_Seca_Initialize);
		GETP(Fenrir_Seca_GetCardsCount);
		GETP(Fenrir_Seca_GetProvidersCount);
		GETP(Fenrir_Seca_Get);
		GETP(Fenrir_Seca_Options);
	}
	return hMod;
}
void UnloadFenrirDyn()
{
	FreeLibrary(hFenrirModule);
}
#endif


#endif