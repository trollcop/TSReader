/*---------------------------------------------------------------
*
*	Fenrir: Auto Update Library by Vlinders					V 1.0
*			Irdeto AU code inspired from MDLoggen 
 ----------------------------------------------------------------*/

#ifndef _FENRIR_H_
#define _FENRIR_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include "FenrirTypes.h"
#include "FenrirIrdeto.h"
#include "FenrirSeca.h"

EMM_ERRORS_t	FENEXP		FenrirInitialize(const char *path);
LPFENRIR		FENEXP		FenrirOpen();
EMM_ERRORS_t	FENEXP		FenrirClose(LPFENRIR lpFenrir);
EMM_ERRORS_t	FENEXP		FenrirCheckCA(int ca, char *ca_name);
EMM_ERRORS_t	FENEXP		FenrirGetProviderName(int ca, int id, char *name);

EMM_ERRORS_t	FENEXP		FenrirSet(LPFENRIR lpFenrir,int pid, int caid, EMM_Notify_Proc _not_func, int _not_id);
EMM_ERRORS_t	FENEXP		FenrirProcess(LPFENRIR lpFenrir, const u8 *emmdata, int emmlen);

// Irdeto specifics
EMM_ERRORS_t	FENEXP		Fenrir_Irdeto_Initialize(const char *path,const char *ird_beta_kid, const char *ird_beta_key, const char *ird_beta_prv);
int				FENEXP		Fenrir_Irdeto_GetCardsCount();
int				FENEXP		Fenrir_Irdeto_GetProvidersCount();
const tIrdeto_Provider* FENEXP Fenrir_Irdeto_Get(int idx); 

// Nagra specifics
EMM_ERRORS_t	FENEXP		Fenrir_Nagra_Initialize(const char *path, const char *nagrapath, const char *nagrakid,const char *nagrakey);
// Viaccess specifics
EMM_ERRORS_t	FENEXP		Fenrir_Viaccess_Initialize(const char *path, const char *viaccess_sci, const char *viaccess_key, const char *viaccess_prv);
int				FENEXP		Fenrir_Viaccess_GetCardsCount();

// Conax specifics
EMM_ERRORS_t	FENEXP		Fenrir_Conax_Initialize(const char *path, const char *conax_kid, const char *conax_key);
int				FENEXP		Fenrir_Conax_GetCardsCount();

// Seca specifics
EMM_ERRORS_t	FENEXP		Fenrir_Seca_Initialize(const char *path, const char *seca_kid, const char *seca_key, const char *seca_prv);
int				FENEXP		Fenrir_Seca_GetCardsCount();
int				FENEXP		Fenrir_Seca_GetProvidersCount();
const tSeca_Provider* FENEXP Fenrir_Seca_Get(int idx); 
tSECA_Informs*	FENEXP		Fenrir_Seca_Options();


#ifdef __cplusplus
}
#endif

#endif