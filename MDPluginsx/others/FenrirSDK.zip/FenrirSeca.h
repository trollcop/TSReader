#ifndef _FENRIR_SECA_H_
#define _FENRIR_SECA_H_

struct tSECA 
{
	int Seperator[2];
	int Cmd_Length;
	int Provider[2];
	unsigned int Shared_Address[4];
	int Key;
	int Super_Enc_Buffer[78];
};

  
struct tSECA_Informs 
{
	HWND     Handle;
	HWND     LogFile;
	HWND     KeyFile;
	int      FilterID;
	BOOL     RunVisible;
	BOOL     RunBackGroundLog;
	BOOL     TPLog;
	BOOL     All_Cards;
	BOOL     SIGERRORLOG;
	unsigned char Last_SA[4];
	unsigned char Last_Key01[8];
	unsigned int LogRecords;
	unsigned short Pid;
	unsigned int MinDif; 
};



struct tSecaCardInfo 
{
	unsigned int ProviderID[2];
	unsigned int SA[4];
	unsigned int Key01[16];
	char		 Comment[64];
	char		 LastUpdateComment[64];
};


struct tSeca_Provider 
{
	int Provider[2];
	char Name[128];
};


#endif