#ifndef _FENRIR_IRDETO_H_
#define _FENRIR_IRDETO_H_

typedef struct tIrdeto_Update
{
	int AnzahlKeys;
	unsigned int Key_Id[4];
	unsigned int Key[4][8];
	unsigned int KeyPos[4];
	unsigned int ChIdH;
	unsigned int ChIdL;
	unsigned int DateIdH;
	unsigned int DateIdL;
	unsigned int EraseChIdL;
	unsigned int EraseChIdH;
	unsigned int CB20;
	unsigned int ProviderUpdate;
} tIrdeto_Update;
typedef struct tIrdeto_Provider
{
	int  EMM;
	char Name[128];
} tIrdeto_Provider;

typedef struct tIrdeto_Informs 
{
	HWND     Handle;
	HWND     LogFile;
	HWND     KeyFile;
	int      FilterID;
	BOOL     All_Cards;
	BOOL     RunVisible;
	BOOL     RunBackGroundLog;
	BOOL     TPLog;
	BOOL     OWNPMKLOG;
	BOOL     KIDUPDATE;
	BOOL     OWNPKLOG;
	BOOL     OWNDELCHIDLOG;
	BOOL     OWNDATEUPDATELOG;
	BOOL     OWNSIGERRORLOG;
	BOOL     OWNCHIDUPDATELOG;
	BOOL     OWNCARDCMDLOG;
	BOOL     OTHERPMKLOG;
	BOOL     OTHERPKLOG;
	BOOL     OTHERDELCHIDLOG;
	BOOL     OTHERDATEUPDATELOG;
	BOOL     OTHERCHIDUPDATELOG;
	BOOL     OTHERCARDCMDLOG;
	unsigned char Last_Hex_Ser[3];
	unsigned char Last_Hex_MK[10];
	unsigned char Last_Prov_Ident[3];
	unsigned char Last_Plain_MK[8];
	unsigned int LogRecords;
	unsigned short Pid;
	unsigned int MinDif;
}tIrdeto_Informs;

typedef struct tIrdeto
{
	unsigned int Seperator[2];
	unsigned int Cmd_Length;
	unsigned int Class01Cmd;
	unsigned int Extend[4];
	unsigned int NanoLength;
	unsigned int CmdBuffer[256];
} tIrdeto;
typedef struct tIrdetoCardInfo
{
	unsigned int HexSerial[3];
	unsigned int HexMasterKey[10];
	unsigned char Provider;
	unsigned int ProviderId[3];
	unsigned int PlainMasterKey[8];
			 char Comment[64];
	         char LastUpdateComment[64];
			 char Indents[512];
} tIrdetoCardInfo;

#endif