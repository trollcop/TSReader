/*
Copyright (c) David R. Cattley (dcattley@msn.com). All rights reserved.

Module Name:

    ATSCSource.h

Abstract:

	ATSC BDA Source for TSReader (www.coolstf.com)

Author:

    David R. Cattley (dcattley@msn.com)

Revision History:

	01-Feb-2005 - Created
*/
#pragma	once
#include "BDAFilterGraph.h"

#define	_TSREADER_SOURCEHELPER_SYNC	1	// Define this if you have it!

extern HINSTANCE g_hInstance;

class CATSCSource
	: public ISampleGrabberCB
{
	// CTOR & DTOR
public:
	CATSCSource()
		: m_pSS(NULL)
		, m_pGraph(NULL)
		, m_nTSBufferIndex(0)
		, m_fNeedTuneDialog(TRUE)
		, m_nFrequency(0)
	{
		ZeroMemory(m_szLastTune, sizeof(m_szLastTune));
	}

	~CATSCSource()
	{
	}

	// TSReader Source Implementation
public:
	//
	// This is where you get a chance to parse the command-line and save the parameters which
	// can be used later in the TuneDialog function rather than presenting a tune dialog.
	// This function is only called with the full-version of TSReader.
	//
	BOOL ParseCommandLine(PSOURCESTRUCT pSS, LPCSTR lpszCommandLine, BOOL fQuiet)
	{
		m_fNeedTuneDialog = TRUE;

		if (lpszCommandLine && lstrlenA(lpszCommandLine))
		{
			int nConversionCount = sscanf(lpszCommandLine, "%d", &m_nFrequency);

			if (nConversionCount < 1)
			{
				if (!fQuiet)
				{
					CHAR szSourceName[256];
					LoadStringA(
						g_hInstance, 
						IDS_SOURCE_DESCRIPTION, 
						szSourceName, 
						sizeof(szSourceName)
						);

					MessageBoxA(
						NULL,
						"Usage for this source: freq\n"
						"\n"
						"freq = frequency to tune in MHz or prefix with 0 for channel number, e.g. 022 for channel 22",
						szSourceName,
						MB_OK | MB_ICONSTOP
						);
				}

				return FALSE;
			}

			if (*lpszCommandLine == '0')
			{
#ifndef QAM
				m_nFrequency = SourceHelper_GetFrequencyFromATSCChannel(m_nFrequency);
#else QAM
				m_nFrequency = SourceHelper_GetFrequencyFromQAMChannel(m_nFrequency);
#endif QAM
			}

			m_fNeedTuneDialog = FALSE;
		}
		else
		{
			m_fNeedTuneDialog = TRUE;
		}

		return TRUE;
	}

	//
	// This function is called when TSReader first loads up the source. Use it to find and initialize
	// your hardware. Return FALSE if your hardware didn't initialize.
	//
	BOOL Init(PSOURCESTRUCT pSS)
	{
		//
		// Save the SOURCESTRUCT
		//
		m_pSS = pSS;

		//
		// Initialize COM
		//
	    HRESULT hr = CoInitialize(NULL);
		if (SUCCEEDED(hr))
		{
			//
			// Create and initialize the graph.
			//
			m_pGraph = new CBDAFilterGraph();

			if (m_pGraph)
			{
				DWORD dwNetworkType = NT_ATSC;
#ifdef QAM
				LONG lKey;
				HKEY hkMainReg;
				static char szKeyName[] = "Software\\COOL.STF\\TSReader\\ATSCSource";
				static char szSourceName[] = {"ATSCSource"};

				lKey = RegOpenKeyEx(HKEY_CURRENT_USER, 
								 szKeyName,
								 0,
								 KEY_QUERY_VALUE,
								 &hkMainReg);
				if (lKey == ERROR_SUCCESS)
				{
					DWORD dwDataSize = sizeof(DWORD);
					DWORD dwType;

					RegQueryValueEx(hkMainReg, "NetworkType", NULL, &dwType, (BYTE *)&dwNetworkType, &dwDataSize);
					RegCloseKey(hkMainReg);
				}
#endif QAM
				hr = m_pGraph->BuildGraph((NETWORK_TYPE)dwNetworkType);

				if (FAILED(hr))
				{
					delete m_pGraph;
					m_pGraph = NULL;
				}
			}

			if (FAILED(hr))
			{
				CoUninitialize();
			}
		}

		return SUCCEEDED(hr) && SourceHelper_StartSyncThread(pSS, FALSE);
	}

	//
	// Opposite of the Init() function
	//
	BOOL DeInit(void)
	{
		if (m_pGraph)
		{
			HRESULT hr = m_pGraph->TearDownGraph();
			delete m_pGraph;
			m_pGraph = NULL;
			CoUninitialize();
		}

		return SourceHelper_StopSyncThread();
	}

	//
	// This is where you setup the tuner to receive the transport stream
	// If you're a source with CAPABILITIES_SERIAL_CONTROL you should
	// call into the SourceHelper_TuneSerialControl() function to have it
	// tune the serially controlled receiver.
	//
	// Return TRUE if you locked, FALSE if no lock and -1 if you're a terrestrial tuner that detects analog signals
	BOOL Tune(void)
	{
		//
		// Calculate the physial channel.
		//
#ifndef QAM
		LONG physicalChannel = SourceHelper_GetATSCChannelFromFrequency(m_pSS->nFrequency);
#else QAM
		LONG physicalChannel = SourceHelper_GetQAMChannelFromFrequency(m_pSS->nFrequency);
#endif QAM

		//
		// Format and save a tune string.
		//
		wsprintfA(m_szLastTune, "Channel %d (%d Mhz)", physicalChannel, m_pSS->nFrequency);

		//
		// Tell the graph to change channels.
		//
		HRESULT hr = m_pGraph->ChangeChannel(physicalChannel, -1, -1);
		if (FAILED(hr))
			return FALSE;

 		//
		// Get the IBDA_SignalStatistics interface on the graph control node.
		//
		CComPtr<IBDA_SignalStatistics> pSignalStatistics;
		hr = m_pGraph->GetControlNode(&pSignalStatistics);
		if (FAILED(hr))
			return FALSE;

		//
		// Start the graph.
		//
		hr = m_pGraph->RunGraph();
		if (FAILED(hr))
			return FALSE;

		//
		// Check if the tuner locked or not.
		//
		BOOLEAN signalLocked = FALSE;
		DWORD dwCurrentTime = GetTickCount();
		while ((GetTickCount() < dwCurrentTime + 3000) && SUCCEEDED(hr) && !signalLocked)
		{
			hr = pSignalStatistics->get_SignalLocked(&signalLocked);
			//
			// Give the tuner a chance to actually tune.
			//
			Sleep(100);
		}

		if (!(SUCCEEDED(hr) && signalLocked))
		{
			if (m_pSS->fQuietMode == FALSE)
			{
				CHAR szSourceName[256];
				LoadStringA(
					g_hInstance, 
					IDS_SOURCE_DESCRIPTION, 
					szSourceName, 
					sizeof(szSourceName)
					);

#ifndef NOSTATUS
				MessageBoxA(m_pSS->hWndTSReader, "Failed to lock signal.\n\nIf this happens on all channels and you know there's an ATSC station that's\nreceiveable your BDA source might not return it's status correctly.\n\nLaunch TSReader with Ctrl pressed down and choose the ATSCBDASourceNS.dll\nsource from the list.", szSourceName, MB_ICONWARNING);
#else NOSTATUS
				MessageBoxA(m_pSS->hWndTSReader, "Failed to lock signal", szSourceName, MB_ICONWARNING);
#endif NOSTATUS
			}
			return FALSE;
		}
		
		return TRUE;
	}

	//
	// This function is called by TSReader when it wants to start the source so it can receive
	// data. This gives you a chance to setup a thread to move the data
	BOOL Start(void)
	{
		if (!m_pGraph)
			return FALSE;

		m_pSS->hReadDataThread = NULL; /* don't need this*/
		m_pSS->fTerminateReadThread = FALSE;
		
		//
		// Setup the Sample Grabber callback.
		//
		CComPtr<ISampleGrabber> sampleGrabber;
		HRESULT hr = m_pGraph->GetSampleGrabber(&sampleGrabber);

		AM_MEDIA_TYPE mediaType = {0};
		hr = FAILED(hr) ? hr : sampleGrabber->GetConnectedMediaType(&mediaType);

		hr = FAILED(hr) ? hr : sampleGrabber->SetBufferSamples(false);
		hr = FAILED(hr) ? hr : sampleGrabber->SetCallback(this, 1 /* Call BufferCB */);

		hr = FAILED(hr) ? hr : m_pGraph->RunGraph();

		return SUCCEEDED(hr);
	}

	//
	// Opposite of the start function - close down the thread before returning
	//
	BOOL Stop(void)
	{
		m_pSS->fTerminateReadThread = TRUE;

		if (m_pGraph)
		{
			//
			// Stop the graph.
			//
			HRESULT hr = m_pGraph->StopGraph();

			//
			// Shutdown the Sample Grabber callback.
			//
			CComPtr<ISampleGrabber> sampleGrabber;

			hr = FAILED(hr) ? hr : m_pGraph->GetSampleGrabber(&sampleGrabber);
			hr = FAILED(hr) ? hr : sampleGrabber->SetCallback(NULL, 1 /* Call BufferCB */);
		}

		m_pSS->fReadThreadTerminated = TRUE;
		m_pSS->fTerminateReadThread = FALSE;

		EnterCriticalSection(&m_pSS->csTSBuffersInUse);
		m_pSS->nTSBuffersInUse = -1000;
		LeaveCriticalSection(&m_pSS->csTSBuffersInUse);

		return TRUE;
	}


	//
	// TSReader calls this function to get the tuner parameters. You can build your own dialog
	// or use one of the TSReader standard ones exported in TSReader_SourceHelper.dll
	//
	BOOL TuneDialog(HWND hWndParent)
	{
		if (m_pSS->fDontTune == TRUE)
		{
			m_fNeedTuneDialog = FALSE;
		}

		if (m_fNeedTuneDialog)
		{
			m_pSS->fQuietMode = FALSE;

#ifndef QAM
			return SourceHelper_ATSCTuneDialog(hWndParent);
#else QAM
			return SourceHelper_QAMTuneDialog(hWndParent);
#endif QAM
		}
		else
		{
			m_pSS->nFrequency = m_nFrequency;
			m_fNeedTuneDialog = TRUE;
		}

		return TRUE;
	}

	//
	// This function is used for sources that have demuxes. TSReader will call this function as 
	// it needs access to a PID. For devices that return the entire transport stream, this function
	// can be ignored.
	//
	BOOL PIDManagement(BOOL fAdd, int nPID, BOOL fTemporary)
	{
		return TRUE;
	}

	//
	// If using an interface with a demux, this function tells TSReader if the PID is currently
	// active (turned on in the demux) or not.
	//
	BOOL IsPIDActive(int nPID)
	{
		/* No DeMux */
		return TRUE;
	}

	//
	// This function will be used in the future for CI-CAMs
	//
	BOOL SetChannel(int nChannel)
	{
		/* not supported */
		return TRUE;
	}

	//
	// This function is called at a 1Hz rate and returns a signal report string which
	// TSReader then displays in it's main window
	//
	BOOL GetSignalString(LPSTR lpszSignalString)
	{
#ifndef NOSTATUS
		if (!m_pGraph)
			return FALSE;

		lstrcpyA(lpszSignalString, "n/a");

		CComPtr<IBDA_SignalStatistics> signalStatistics;
		HRESULT hr = m_pGraph->GetControlNode(&signalStatistics);

		BOOLEAN present = FALSE;
		BOOLEAN locked = FALSE;
		LONG quality = 0;
		LONG strength = 0;

		hr = FAILED(hr) ? hr : signalStatistics->get_SignalPresent(&present);
		hr = FAILED(hr) ? hr : signalStatistics->get_SignalLocked(&locked);
		hr = FAILED(hr) ? hr : signalStatistics->get_SignalQuality(&quality);
		hr = FAILED(hr) ? hr : signalStatistics->get_SignalStrength(&strength);

		if (FAILED(hr))
			return FALSE;

		wsprintfA(lpszSignalString,  "%3d%% (%2d.%0.3d dbm)", quality, (strength / 1000), (strength % 1000));

		if (present && locked)
		{
			lstrcatA(lpszSignalString, " [Locked]");
		}
		else if (present)
		{
			lstrcatA(lpszSignalString, " [Present]");
		}
		else
		{
			lstrcatA(lpszSignalString, " [Absent]");
		}
#else NOSTATUS
		lstrcpyA(lpszSignalString, "n/a");
#endif NOSTATUS

		return TRUE;
	}

	//
	// This function is called at a 1Hz rate and returns a tune report string which
	// TSReader then displays in it's main window
	//
	BOOL GetTunerString(LPSTR lpszTunerString)
	{
		lstrcpyA(lpszTunerString, m_szLastTune);
		return TRUE;
	}

	//
	// This function is called by TSReader when it needs to send a DiSEqC command.
	// Only sources that have CAPABILITIES_DISEQC_POSITIONER will get called.
	//
	BOOL SendDiSEqC(BYTE * bCommand, int nLength)
	{
		/* not supported */
		return TRUE;
	}

	//
	// ISampleGrabberCB implementation.
	//
public:
	STDMETHODIMP_(ULONG) AddRef() { return 1; }
    STDMETHODIMP_(ULONG) Release() { return 2; }

    STDMETHODIMP QueryInterface(REFIID riid, void **ppvObject)
    {
        if (NULL == ppvObject) return E_POINTER;
        if (riid == __uuidof(IUnknown))
        {
            *ppvObject = static_cast<IUnknown*>(this);
             return S_OK;
        }
        if (riid == __uuidof(ISampleGrabberCB))
        {
            *ppvObject = static_cast<ISampleGrabberCB*>(this);
             return S_OK;
        }
        return E_NOTIMPL;
    }

    STDMETHODIMP SampleCB(double Time, IMediaSample *pSample)
    {
        return E_NOTIMPL;
    }

    STDMETHODIMP BufferCB(double Time, LPBYTE lpBuffer, long BufferLen)
    {
#ifdef	_TSREADER_SOURCEHELPER_SYNC
		BOOL fSuccess = SourceHelper_SyncData(lpBuffer, BufferLen);
#else
		long remaining = BufferLen;
		LPBYTE buffer = lpBuffer;

		while(remaining && !m_pSS->fTerminateReadThread)
		{
			long chunk = min(remaining, TS_BUFFER_SIZE);

			EnterCriticalSection(&m_pSS->csPIDCounter);
			m_pSS->nLastSecondByteCounter += chunk;
			LeaveCriticalSection(&m_pSS->csPIDCounter);

			CopyMemory(m_pSS->tsb[m_nTSBufferIndex].pData, buffer, chunk);
			m_pSS->tsb[m_nTSBufferIndex++].nSize = chunk;
			m_nTSBufferIndex %= MAX_TS_BUFFERS;

			EnterCriticalSection(&m_pSS->csTSBuffersInUse);
			m_pSS->nTSBuffersInUse++;
			LeaveCriticalSection(&m_pSS->csTSBuffersInUse);
			
			remaining -= chunk;
		}
#endif

        return S_OK;
    }


protected:
	PSOURCESTRUCT m_pSS;
	CBDAFilterGraph* m_pGraph;
	int m_nTSBufferIndex;
    
	bool m_fNeedTuneDialog;
	int m_nFrequency;

	CHAR m_szLastTune[128];
};
